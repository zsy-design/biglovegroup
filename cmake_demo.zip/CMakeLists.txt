cmake_minimum_required(VERSION 3.16)

project(cmake_demo LANGUAGES CXX)

# ---- 全局设置 ----
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

# 单配置生成器（Makefile / Ninja）才认 CMAKE_BUILD_TYPE
if(NOT CMAKE_BUILD_TYPE AND NOT CMAKE_CONFIGURATION_TYPES)
  set(CMAKE_BUILD_TYPE Debug CACHE STRING "Build type" FORCE)
  set_property(CACHE CMAKE_BUILD_TYPE PROPERTY STRINGS Debug Release RelWithDebInfo MinSizeRel)
endif()

# 输出到构建目录的 bin/ 子目录，避免和源码混在一起
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}/bin)

# ---- 头文件搜索路径 ----
include_directories(${CMAKE_CURRENT_SOURCE_DIR}/include)

# ---- 源文件 ----
set(SOURCES
  src/main.cpp
  src/calculator.cpp
)

# ---- 可执行目标 ----
add_executable(demo ${SOURCES})

# 链接头文件里用到的库（这里只用标准库，不需要额外链接）

# ---- 安装规则（可选，但推荐写）----
install(TARGETS demo RUNTIME DESTINATION bin)
