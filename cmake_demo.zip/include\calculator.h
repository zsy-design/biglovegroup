#pragma once

namespace demo {

// 两个整数相加
int add(int a, int b);

// 计算数组平均值，数组为空时返回 0.0
double average(const int* values, int count);

}  // namespace demo
