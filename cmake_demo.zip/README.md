# CMake 编写实践报告

**项目**：`cmake_demo` —— 最小可用的 CMake + C++ 工程
**环境**：CMake 4.5.0、MinGW-w64 g++ 16.2.0（Ninja 生成器）、Windows

---

## 一、工程结构

```
cmake_demo/
├── CMakeLists.txt          # 构建脚本（核心）
├── include/
│   └── calculator.h        # 头文件（对外接口声明）
├── src/
│   ├── calculator.cpp      # 源文件（接口实现）
│   └── main.cpp            # 程序入口
├── build-debug/            # Debug 构建目录（由 cmake 生成）
├── build-release/          # Release 构建目录（由 cmake 生成）
└── README.md
```

设计要点：**头文件与源文件分离**，头文件放 `include/`，源文件放 `src/`。这是最基本也最容易被忽视的工程规范。

---

## 二、CMakeLists.txt 逐段解析

```cmake
cmake_minimum_required(VERSION 3.16)
```
声明最低 CMake 版本。CMake 4.x 已移除对 3.5 以下版本的支持，写 3.16 是当前较安全的选择（Ubuntu 22.04 自带的 CMake 3.22 也能满足）。

```cmake
project(cmake_demo LANGUAGES CXX)
```
定义工程名，并指定使用的语言为 C++。

```cmake
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
```
统一 C++ 标准：C++17，不允许编译器降级，不使用 GNU 特有扩展（保证可移植性）。CMake 3.8 以后推荐用 `target_compile_features` 做更细粒度控制，此处为了直观用全局 `set`。

```cmake
if(NOT CMAKE_BUILD_TYPE AND NOT CMAKE_CONFIGURATION_TYPES)
  set(CMAKE_BUILD_TYPE Debug CACHE STRING "Build type" FORCE)
  set_property(CACHE CMAKE_BUILD_TYPE PROPERTY STRINGS Debug Release RelWithDebInfo MinSizeRel)
endif()
```
设置默认构建类型为 Debug。
- `CMAKE_BUILD_TYPE`：**单配置生成器**（Ninja / Unix Makefiles）使用的变量。
- `CMAKE_CONFIGURATION_TYPES`：**多配置生成器**（Visual Studio、MSVC 的 Xcode）使用的变量，此时 Debug/Release 通过 `--config Debug` 选择。

所以这段 `if` 的意义是：两种生成器都兼容，且没指定时默认 Debug。

```cmake
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}/bin)
```
可执行文件统一输出到 `<构建目录>/bin/`。好处是源码目录保持干净，且 Debug 和 Release 的产物天然分离在各自的构建目录里，不会互相覆盖。

```cmake
include_directories(${CMAKE_CURRENT_SOURCE_DIR}/include)
```
添加头文件搜索路径，使 `#include "calculator.h"` 能找到 `include/calculator.h`。

> 更好的写法是目标级的 `target_include_directories(demo PRIVATE include)`，作用域更小，不会污染其他目标。

```cmake
set(SOURCES
  src/main.cpp
  src/calculator.cpp
)
add_executable(demo ${SOURCES})
```
把 `main.cpp` 和 `calculator.cpp` 一起编译成可执行目标 `demo`。用 `set()` 收集源文件列表，文件多时更易维护。

```cmake
target_include_directories(demo PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
```
（可选，与上面的 `include_directories` 二选一即可，此处保留全局写法便于初学者理解。）

```cmake
install(TARGETS demo RUNTIME DESTINATION bin)
```
安装规则。`install` 不是必须的，但**强烈建议写**——ROS2 功能的 `colcon build` 会调用 `install` 把可执行文件放到 `install/<包名>/lib/<包名>/`，`ros2 run` 才能找到它。

---

## 三、源文件

**include/calculator.h**
```cpp
#pragma once
namespace demo {
int add(int a, int b);
double average(const int* values, int count);
}
```
头文件只放**声明**，用 `#pragma once` 防止重复包含（也可换成 include guard 宏）。

**src/calculator.cpp**
实现对应的两个函数，编译时和头文件声明做一致性检查。

**src/main.cpp**
调用库函数，并用 `#ifdef NDEBUG` 打印当前构建类型 —— `NDEBUG` 在 Release 下由 CMake 自动定义，这是验证构建类型是否生效的常用小技巧。

---

## 四、Debug / Release 构建

### 4.1 命令

```bash
# 配置 + 编译 Debug
cmake -S . -B build-debug -G Ninja -DCMAKE_BUILD_TYPE=Debug
cmake --build build-debug

# 配置 + 编译 Release
cmake -S . -B build-release -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build-release

# 运行
./build-debug/bin/demo.exe
./build-release/bin/demo.exe
```

等价的一步式写法（仅 Ninja/Makefiles 这类单配置生成器）：
```bash
cmake -S . -B build-debug -DCMAKE_BUILD_TYPE=Debug && cmake --build build-debug
```

**关键点**：`CMAKE_BUILD_TYPE` 必须在 **configure 阶段**指定，只写 `cmake --build` 是改不掉的。已配置过的目录想换类型，需要改 CMakeLists 里的 `set(... CACHE ... FORCE)` 或直接换个构建目录。

### 4.2 两种模式的差别

| 项目 | Debug | Release |
|---|---|---|
| 默认优化等级 | `-g`（无优化） | `-O3 -DNDEBUG` |
| 编译期断言 `assert()` | 启用 | 被禁用（NDEBUG） |
| 调试信息 | 完整 | 默认也保留，可加 `-s` 剥离 |
| 编译速度 | 快 | 慢 |
| 运行速度 | 慢 | 快 |

排查崩溃、内存问题用 Debug；跑比赛、测性能用 Release。

### 4.3 实测输出

Debug：
```
=== cmake_demo ===
add(3, 4) = 7
average = 5
build type: Debug (assert active)
```

Release：
```
=== cmake_demo ===
add(3, 4) = 7
average = 5
build type: Release (NDEBUG defined)
```

---

## 五、常见坑

1. **改 CMakeLists 后不生效** —— 多数情况不需要重新 configure，CMake 会自动重新配置；只有改了 `project()` 名字或生成器才需要删掉 `build-*` 目录重来。
2. **`include_directories` 路径写错** —— 建议用相对工程根目录的相对路径，配合 `cmake -S . -B build` 使用，不要写绝对路径，否则换机器就崩。
3. **多配置生成器下 `CMAKE_BUILD_TYPE` 无效** —— Visual Studio 生成器要用 `--config Debug`，`CMAKE_BUILD_TYPE` 只对 Ninja/Makefiles 生效。
4. **源文件没加进 `add_executable`** —— 表现是链接期报 `undefined reference`。
5. **忘了写 `install`** —— 本地手动编译能跑，但 `colcon build` 出的包 `ros2 run` 找不到可执行文件。

---

## 六、迁移到 ROS2

本例与 ROS2 功能包差别只在两点：

1. `project()` 后加 `find_package(rclcpp REQUIRED)`、`find_package(std_msgs REQUIRED)`。
2. 可执行目标用 `ament_target_dependencies(demo rclcpp std_msgs)` 代替手写 `target_link_libraries`。
3. 增加 `install(TARGETS demo DESTINATION lib/${PROJECT_NAME})`（注意是 `lib` 而不是 `bin`）。
4. `package.xml` 中要声明对应依赖，与 CMakeLists 保持一致。

两者思想完全一致：**CMakeLists.txt 负责"怎么编"，package.xml 负责"依赖谁"，两者必须对齐。**
