#include <cstdio>
#include <iostream>
#include <vector>

#include "calculator.h"

int main() {
  std::cout << "=== cmake_demo ===" << std::endl;
  std::cout << "add(3, 4) = " << demo::add(3, 4) << std::endl;

  std::vector<int> data{2, 4, 6, 8};
  std::cout << "average = " << demo::average(data.data(), static_cast<int>(data.size()))
            << std::endl;

#ifdef NDEBUG
  std::cout << "build type: Release (NDEBUG defined)" << std::endl;
#else
  std::cout << "build type: Debug (assert active)" << std::endl;
#endif

  return 0;
}
