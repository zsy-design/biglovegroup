#include "calculator.h"

#include <numeric>

namespace demo {

int add(int a, int b) { return a + b; }

double average(const int* values, int count) {
  if (values == nullptr || count <= 0) {
    return 0.0;
  }
  long long sum = std::accumulate(values, values + count, 0LL);
  return static_cast<double>(sum) / count;
}

}  // namespace demo
