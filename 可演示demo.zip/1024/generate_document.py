#!/usr/bin/env python3
"""
生成《岗位胜任力多轮问询与评估报告生成·面试智能体》作品设计实现方案文档
严格按照参考文档结构，内容基于实际程序代码
"""

import os
from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml


def set_cell_shading(cell, color):
    """设置单元格背景色"""
    shading_elm = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color}"/>')
    cell._tc.get_or_add_tcPr().append(shading_elm)


def add_picture_placeholder(doc, width, height, caption=""):
    """添加图片占位符"""
    # 创建一个表格来模拟图片占位符
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.cell(0, 0)
    cell.text = f"[插图占位符 - {caption}]"
    cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_cell_shading(cell, "D9D9D9")
    return table


def create_document():
    doc = Document()
    
    # 设置文档默认字体
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    font.size = Pt(12)
    style.element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    
    # 设置行距
    paragraph_format = style.paragraph_format
    paragraph_format.line_spacing = 1.25
    
    # 添加封面页
    add_cover_page(doc)
    
    # 添加摘要
    add_abstract(doc)
    
    # 添加目录
    add_toc(doc)
    
    # 第一章 项目概述
    add_chapter1(doc)
    
    # 第二章 核心技术
    add_chapter2(doc)
    
    # 第三章 系统架构与实现
    add_chapter3(doc)
    
    # 第四章 技术和功能创新
    add_chapter4(doc)
    
    # 第五章 系统功能测试
    add_chapter5(doc)
    
    # 第六章 总结与展望
    add_chapter6(doc)
    
    # 添加参考文献
    add_references(doc)
    
    # 保存文档
    output_path = os.path.join(os.path.dirname(__file__), "作品设计实现方案_岗位胜任力面试智能体.docx")
    doc.save(output_path)
    print(f"文档已生成: {output_path}")


def add_cover_page(doc):
    """添加封面页"""
    # 空行
    for _ in range(4):
        doc.add_paragraph()
    
    # 标题
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("岗位胜任力多轮问询与评估报告生成")
    run.font.size = Pt(22)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run("面试智能体")
    run.font.size = Pt(22)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 空行
    doc.add_paragraph()
    
    # 作品设计实现方案
    doc_title = doc.add_paragraph()
    doc_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = doc_title.add_run("作品设计实现方案")
    run.font.size = Pt(18)
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 空行
    for _ in range(6):
        doc.add_paragraph()
    
    # 项目信息表格
    table = doc.add_table(rows=4, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 设置表格边框
    for row in table.rows:
        for cell in row.cells:
            cell.text = ""
    
    # 填充表格内容
    info = [
        ("项目名称", "岗位胜任力多轮问询与评估报告生成·面试智能体"),
        ("参赛赛道", "2026 iFLYTEK AI开发者大赛 工程开发赛道"),
        ("完成日期", "2026年9月"),
        ("作者", "")
    ]
    
    for i, (label, value) in enumerate(info):
        table.cell(i, 0).text = label
        table.cell(i, 1).text = value
    
    # 分页
    doc.add_page_break()


def add_abstract(doc):
    """添加摘要"""
    # 摘要标题
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("摘  要")
    run.font.size = Pt(15.5)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 摘要内容
    abstract_text = """本项目面向高校毕业生就业与企业招聘中的信息不对称痛点，基于大语言模型智能体技术，设计并实现了一个"简历画像→多轮情景化问询→九维胜任力评估报告"的全流程智能面试系统。系统集成岗位JD智能解析、简历智能处理、虚拟AI多轮面试、九维胜任力测评、智能评估报告生成和数据看板六大功能模块。创新性地采用冰山模型与能力素质词典构建岗位胜任力模型，支持任意岗位JD的动态面试生成；通过LLM驱动的智能追问机制深挖候选人能力；结合语音合成与3D数字人技术打造拟人化虚拟面试官；最终生成包含九维雷达图、反作弊分析和改进建议的专业评估报告。系统支持离线运行，具备完整的多用户管理和历史记录功能，为智能化招聘提供了高效、客观、全面的技术解决方案。"""
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run(abstract_text)
    run.font.name = '宋体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    
    # 关键词
    doc.add_paragraph()
    keywords = doc.add_paragraph()
    keywords.paragraph_format.first_line_indent = Cm(0.75)
    run = keywords.add_run("关键词：")
    run.font.bold = True
    run.font.name = '宋体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    run = keywords.add_run("智能面试；岗位胜任力；多轮问询；大语言模型；九维评估；简历画像")
    run.font.name = '宋体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    
    doc.add_page_break()


def add_toc(doc):
    """添加目录"""
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("目  录")
    run.font.size = Pt(15.5)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 目录内容
    toc_items = [
        ("摘要", 1),
        ("第一章  项目概述", 1),
        ("1.1  背景与目标", 2),
        ("1.1.1  项目背景", 3),
        ("1.1.2  国内外研究现状", 3),
        ("1.1.3  痛点分析", 3),
        ("1.1.4  项目目标", 3),
        ("1.2  功能概述", 2),
        ("第二章  核心技术", 1),
        ("2.1  岗位JD智能解析", 2),
        ("2.2  简历智能处理", 2),
        ("2.3  多轮面试对话引擎", 2),
        ("2.4  九维胜任力评估", 2),
        ("2.5  虚拟面试官技术", 2),
        ("第三章  系统架构与实现", 1),
        ("3.1  项目整体架构", 2),
        ("3.2  前端界面设计", 2),
        ("3.3  后端服务架构", 2),
        ("3.4  数据存储设计", 2),
        ("3.5  技术栈详解", 2),
        ("第四章  技术和功能创新", 1),
        ("4.1  项目优势分析", 2),
        ("4.2  智能对话引擎", 2),
        ("4.3  动态岗位模型", 2),
        ("4.4  反作弊机制", 2),
        ("4.5  离线运行能力", 2),
        ("第五章  系统功能测试", 1),
        ("5.1  用户面试过程", 2),
        ("5.2  简历处理功能", 2),
        ("5.3  评估报告生成", 2),
        ("5.4  历史记录管理", 2),
        ("第六章  总结与展望", 1),
        ("6.1  系统总结", 2),
        ("6.2  技术与社会影响", 2),
        ("6.3  未来轨迹", 2),
        ("参考文献", 1),
    ]
    
    for item, level in toc_items:
        p = doc.add_paragraph()
        if level == 1:
            run = p.add_run(item)
            run.font.bold = True
        elif level == 2:
            p.paragraph_format.left_indent = Cm(1)
            run = p.add_run(item)
        else:
            p.paragraph_format.left_indent = Cm(2)
            run = p.add_run(item)
    
    doc.add_page_break()


def add_chapter1(doc):
    """第一章 项目概述"""
    # 章节标题
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("第一章  项目概述")
    run.font.size = Pt(15.5)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 1.1 背景与目标
    h1 = doc.add_paragraph()
    run = h1.add_run("1.1  背景与目标")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 1.1.1 项目背景
    h2 = doc.add_paragraph()
    run = h2.add_run("1.1.1  项目背景")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("高校毕业生就业压力大、企业招聘成本高，供需双方在岗位能力认知上存在严重的信息不对称。传统面试存在主观性强（跨面试官评分差异达42%）、标准不统一、效率低下（单次面试3.5人时）等问题。本项目基于大语言模型智能体技术，模拟资深HR/业务专家进行多轮情景化追问，深挖候选人能力，并自动生成客观、全面的胜任力评估报告，助力学生提升就业竞争力、企业提升招聘效率。")
    
    # 1.1.2 国内外研究现状
    h2 = doc.add_paragraph()
    run = h2.add_run("1.1.2  国内外研究现状")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("国内外AI面试赛道发展迅速，但存在明显差距：")
    
    # 国外研究
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("国外方面：")
    run.font.bold = True
    run = p.add_run("HireVue、Pymetrics等平台已实现商业化应用，采用视频分析、游戏化测评等技术，但主要面向英语市场，中文支持有限。这些平台通常需要定制化部署，成本较高。")
    
    # 国内研究
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("国内方面：")
    run.font.bold = True
    run = p.add_run("AI面试赛道融资事件仅23起，70%以上企业仍停留在单模态方案（仅文本或语音）。大多数产品依赖固定题库，缺乏个性化追问能力，评估维度单一，难以全面反映候选人能力。")
    
    # 对比表格
    doc.add_paragraph()
    table = doc.add_table(rows=6, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 表头
    headers = ["平台", "技术特点", "优势", "不足"]
    for i, header in enumerate(headers):
        cell = table.cell(0, i)
        cell.text = header
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = cell.paragraphs[0].runs[0]
        run.font.bold = True
    
    # 表格内容
    data = [
        ["HireVue", "视频+语音分析", "商业化成熟", "中文支持差"],
        ["Pymetrics", "游戏化测评", "趣味性强", "岗位适配度低"],
        ["国内方案A", "文本问答", "部署简单", "缺乏追问"],
        ["国内方案B", "语音面试", "效率较高", "评估单一"],
        ["本系统", "LLM多轮追问", "全链路闭环", "—"],
    ]
    
    for i, row_data in enumerate(data):
        for j, cell_text in enumerate(row_data):
            table.cell(i+1, j).text = cell_text
    
    doc.add_paragraph()
    
    # 1.1.3 痛点分析
    h2 = doc.add_paragraph()
    run = h2.add_run("1.1.3  痛点分析")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("传统面试存在以下核心痛点：")
    
    pain_points = [
        "主观性强：不同面试官对同一候选人的评分差异可达42%，缺乏统一标准",
        "效率低下：单次面试平均耗时3.5人时，且难以保证评估质量",
        "信息不对称：候选人难以了解岗位真实要求，企业难以全面评估候选人",
        "评估片面：传统面试通常只考察沟通能力，忽视专业技能、学习能力等维度",
        "成本高昂：优质面试官稀缺，企业招聘成本居高不下"
    ]
    
    for point in pain_points:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(point)
    
    # 1.1.4 项目目标
    h2 = doc.add_paragraph()
    run = h2.add_run("1.1.4  项目目标")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("本项目旨在解决上述痛点，实现以下目标：")
    
    goals = [
        "技术目标：构建基于LLM的智能面试系统，支持动态岗位解析、个性化追问、九维评估",
        "应用目标：提供全流程面试解决方案，从简历解析到评估报告生成",
        "创新目标：实现离线可运行、多用户管理、反作弊检测等差异化功能"
    ]
    
    for goal in goals:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(goal)
    
    # 1.2 功能概述
    h1 = doc.add_paragraph()
    run = h1.add_run("1.2  功能概述")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("系统集成六大功能模块，覆盖面试全流程：")
    
    # 功能模块表格
    table = doc.add_table(rows=7, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 表头
    headers = ["模块", "功能", "实现位置"]
    for i, header in enumerate(headers):
        cell = table.cell(0, i)
        cell.text = header
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = cell.paragraphs[0].runs[0]
        run.font.bold = True
    
    # 表格内容
    modules = [
        ["1 岗位JD智能解析", "任意岗位JD→自动拆解胜任力模型", "app/jd.py"],
        ["2 简历智能处理", "PDF/Word/TXT上传解析、AI优化、风险检测", "app/resume/*"],
        ["3 虚拟AI多轮面试", "拟人3D面试官、语音+文字双轨提问", "app/interview/"],
        ["4 九维胜任力测评", "九维量化打分+雷达图", "app/competency/nine.py"],
        ["5 智能评估报告", "候选人画像/匹配分析/优势亮点/改进方案", "app/report/"],
        ["6 数据看板与历史", "历次面试报告SQLite持久化", "app/storage.py"],
    ]
    
    for i, row_data in enumerate(modules):
        for j, cell_text in enumerate(row_data):
            table.cell(i+1, j).text = cell_text
    
    doc.add_page_break()


def add_chapter2(doc):
    """第二章 核心技术"""
    # 章节标题
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("第二章  核心技术")
    run.font.size = Pt(15.5)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 2.1 岗位JD智能解析
    h1 = doc.add_paragraph()
    run = h1.add_run("2.1  岗位JD智能解析")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.1.1  内容概述")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("岗位JD智能解析模块（app/jd.py）能够处理任意岗位的职位描述文本，自动拆解为结构化胜任力模型。该模块是整个系统的入口，为后续的简历匹配、面试出题和评估提供基础。")
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.1.2  核心技术")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("该模块采用以下核心技术：")
    
    techs = [
        "岗位类型识别：定义17个正则规则（TYPE_RULES），覆盖Java/Go/Python/前端/移动端/AI/大数据/DevOps/嵌入式/全栈/架构师/技术经理/产品经理/测试/安全等岗位。通过detect_type()函数正则匹配JD文本，返回岗位名称、key和是否内置",
        "需求抽取：使用正则表达式提取学历要求（博士/硕士/研究生/本科/大专）、经验年限（r\"(\\d+(?:\\.\\d+)?)\\s*(?:年|年以上|年左右)[^\\n]{0,6}经验\"）、职责和加分项",
        "核心技能抽取：复用简历解析模块中的SKILL_DICT（9大技能类别、50+关键词），正则匹配JD文本，提取岗位所需核心技能",
        "难度评估：基于经验年限（≥5年+2分、≥3年+1分）、学历（博士/硕士+1分）、技能数量（≥4个+1分）综合评分，输出低/中/高三个难度等级",
        "面试题库生成：内置岗位使用预定义结构化题库（每题含维度、题目文本、关键词、预设追问）；自定义JD使用通用题库（6道题覆盖6个考察维度）"
    ]
    
    for tech in techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.1.3  创新点和优势")
    run.font.bold = True
    
    innovations = [
        "动态岗位模型：job_model_from_jd()函数把解析后的JD直接转化为JobModel对象，可驱动面试引擎，实现'粘贴任意JD即可面试'的个性化体验",
        "六维→九维权重扩展：nine_weights_from_six()把六维岗位权重自动映射为九维评估权重，归一化到1，无需人工配置",
        "离线可运行：内置16+岗位的结构化题库，即使未配置LLM也能提供完整的面试体验"
    ]
    
    for innovation in innovations:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(innovation)
    
    # 2.2 简历智能处理
    h1 = doc.add_paragraph()
    run = h1.add_run("2.2  简历智能处理")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.2.1  内容概述")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("简历智能处理模块（app/resume/）包含四个子模块，提供完整的简历处理生态：文件解析、简历画像构建、AI简历优化和风险检测、简历模板库。")
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.2.2  核心技术")
    run.font.bold = True
    
    # 文件解析
    p = doc.add_paragraph()
    run = p.add_run("文件解析技术（extractor.py）：")
    run.font.bold = True
    
    parse_techs = [
        "支持.txt/.md/.pdf/.docx四种格式",
        "PDF解析：使用pypdf的PdfReader逐页提取文本",
        "Word解析：使用python-docx解析段落和表格",
        "TXT/MD：尝试UTF-8/GBK/GB18030多编码解码",
        "通用清洗：clean_text()去除控制字符、多余空格/换行"
    ]
    
    for tech in parse_techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    # 简历解析
    p = doc.add_paragraph()
    run = p.add_run("简历解析与画像构建（parser.py）：")
    run.font.bold = True
    
    parser_techs = [
        "姓名提取：前6行扫描，排除关键词（姓名/性别/年龄/电话等），2-4字无数字标点",
        "学历识别：关键词匹配（博士/硕士/本科/大专）",
        "院校识别：正则匹配[\\u4e00-\\u9fa5]{2,}(?:大学|学院|学校|职业技术学院)",
        "专业匹配：匹配'专业/主修'后内容，或以'工程/科学/技术/管理/设计/学'结尾的词",
        "技能标签：9大类别50+关键词匹配（java/Python/算法/前端/后端/数据/测试/产品/安全）",
        "项目经历：正则匹配'项目/课题/作品/毕设'后内容，提取上下文60字",
        "岗位匹配：计算简历与每个内置岗位的匹配度，返回最佳岗位和匹配分数"
    ]
    
    for tech in parser_techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    # AI简历优化
    p = doc.add_paragraph()
    run = p.add_run("AI简历优化（optimizer.py）：")
    run.font.bold = True
    
    optimize_techs = [
        "确定性优化：按行切分为条目，检测量化指标（数字/百分比），无量化指标的追加STAR法则提示",
        "LLM优化：构造system prompt（'你是资深简历优化专家...'），返回JSON格式的优化后简历文本和变更清单",
        "风险检测：检测5类问题（缺乏量化/项目缺失/角色模糊/空泛表述/信息单薄），综合健康度评分"
    ]
    
    for tech in optimize_techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    # 模板库
    p = doc.add_paragraph()
    run = p.add_run("简历模板库（templates.py）：")
    run.font.bold = True
    
    template_techs = [
        "内置7类模板：应届生清新模板、校招标准模板、社招进阶模板、技术岗模板、产品/运营模板、管理岗模板、国企/公考模板",
        "每类模板包含6个标准section：基本信息、教育背景、专业技能、项目经历、实习经历、自我评价",
        "apply_template()将简历画像自动填充到模板章节结构中"
    ]
    
    for tech in template_techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.2.3  创新点和优势")
    run.font.bold = True
    
    innovations = [
        "多格式支持：覆盖PDF/Word/TXT/MD四种主流简历格式，无需用户手动转换",
        "智能画像：基于规则+技能词典的混合解析方法，无需训练数据即可工作",
        "风险检测：自动识别简历中的常见问题，提供针对性改进建议",
        "模板一键套用：7类模板覆盖不同场景，自动填充简历内容，提升简历质量"
    ]
    
    for innovation in innovations:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(innovation)
    
    doc.add_page_break()


def add_chapter2_continued(doc):
    """第二章 核心技术（续）"""
    # 2.3 多轮面试对话引擎
    h1 = doc.add_paragraph()
    run = h1.add_run("2.3  多轮面试对话引擎")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.3.1  内容概述")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("多轮面试对话引擎（app/interview/engine.py）是系统的核心组件，采用有限状态机设计，管理一场面试的完整生命周期，从开场白到结束语，全程智能化管理。")
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.3.2  核心技术")
    run.font.bold = True
    
    # 面试计划生成
    p = doc.add_paragraph()
    run = p.add_run("面试计划生成（_build_plan）：")
    run.font.bold = True
    
    plan_techs = [
        "按岗位权重对6个考察维度排序",
        "每个维度从题库中选题（简历命中关键词的题目优先，体现个性化）",
        "两遍选题：第一遍按权重覆盖维度，第二遍补充题库富余题目",
        "最大轮数由settings.MAX_INTERVIEW_ROUNDS（默认6轮）控制"
    ]
    
    for tech in plan_techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    # 智能追问机制
    p = doc.add_paragraph()
    run = p.add_run("智能追问机制：")
    run.font.bold = True
    
    query_techs = [
        "阶段A：自我介绍后进入正式出题",
        "阶段B：处理回答，三种决策路径：",
        "  B1 回答过短（长度<MIN_ANSWER_LEN=8字）：追问展开细节",
        "  B2 还有预设追问：调用_paraphrase()生成追问（模板→LLM口语化改写）",
        "  B3 进入下一题：更新题目索引，选择下一道题",
        "追问生成（_paraphrase）：先给模板追问，LLM可用时构造system prompt（'【追问】...要求: 口语化、自然、有追问感'），将候选人回答作为user消息，LLM输出自然化追问（温度0.7, max_tokens=120）"
    ]
    
    for tech in query_techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    # 作答打分
    p = doc.add_paragraph()
    run = p.add_run("作答打分（_score_answer）：")
    run.font.bold = True
    
    score_techs = [
        "启发式评分（满分5.0）：回答长度≥20字+1.5分、≥60字+1.0分、≥120字+0.5分",
        "结构化表达检测：含结构词（首先/然后/其次等）+0.8分",
        "量化数据检测：含数字/百分比等+0.8分",
        "角色词检测：含'我负责/我主导'等+0.7分",
        "关键词匹配：命中题目关键词+0.7分"
    ]
    
    for tech in score_techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    # 逐题实时评估
    p = doc.add_paragraph()
    run = p.add_run("逐题实时评估（_eval_comment）：")
    run.font.bold = True
    
    eval_techs = [
        "优秀（≥4.0）、良好（≥3.0）、一般（≥2.0）、较弱（<2.0）",
        "每题回答后即时反馈评分和评语",
        "多模态数据汇总：平均语速、停顿次数、回答时长、逐题维度得分"
    ]
    
    for tech in eval_techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.3.3  创新点和优势")
    run.font.bold = True
    
    innovations = [
        "个性化出题：根据简历内容动态选择题目，体现候选人特点",
        "智能追问：LLM驱动的自然化追问，深挖候选人能力",
        "实时评估：每题即时反馈，帮助候选人了解表现",
        "灵活控制：支持文本结束（'结束'/'面试结束'/'就这样'等）和提前收尾"
    ]
    
    for innovation in innovations:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(innovation)
    
    doc.add_page_break()


def add_chapter2_part3(doc):
    """第二章 核心技术（续）"""
    # 2.4 九维胜任力评估
    h1 = doc.add_paragraph()
    run = h1.add_run("2.4  九维胜任力评估")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.4.1  内容概述")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("九维胜任力评估模块（app/competency/nine.py）基于冰山模型与能力素质词典，将面试表现转化为九维量化评估，为候选人提供全面的能力画像。")
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.4.2  核心技术")
    run.font.bold = True
    
    # 九维评估维度
    p = doc.add_paragraph()
    run = p.add_run("九维评估维度：")
    run.font.bold = True
    
    # 维度表格
    table = doc.add_table(rows=10, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    headers = ["维度", "说明", "来源"]
    for i, header in enumerate(headers):
        cell = table.cell(0, i)
        cell.text = header
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = cell.paragraphs[0].runs[0]
        run.font.bold = True
    
    dimensions = [
        ["专业能力", "岗位核心技术能力", "六维'专业知识'直接迁移"],
        ["实操经验", "实际问题处理与工程落地", "六维'解决问题'直接迁移"],
        ["学习能力", "学习意愿与成长潜力", "六维'学习能力'直接迁移"],
        ["沟通表达", "表达、协作与团队贡献", "六维'沟通协作'直接迁移"],
        ["逻辑思维", "结构化思考与问题拆解", "六维'逻辑思维'直接迁移"],
        ["抗压能力", "责任心、抗压、自驱", "六维'职业素养'*0.5"],
        ["岗位匹配度", "简历+面试综合匹配", "职业素养*0.25+0.05+简历匹配+面试综合"],
        ["职业稳定性", "稳定性评估", "职业素养*0.25+0.05+经验/学历/项目"],
        ["综合潜力", "成长潜力", "学习能力*0.6+整体*0.4"],
    ]
    
    for i, row_data in enumerate(dimensions):
        for j, cell_text in enumerate(row_data):
            table.cell(i+1, j).text = cell_text
    
    doc.add_paragraph()
    
    # 六维→九维映射
    p = doc.add_paragraph()
    run = p.add_run("六维→九维映射（SCORE_MAP）：")
    run.font.bold = True
    
    mapping_techs = [
        "专业知识 → 专业能力",
        "解决问题 → 实操经验",
        "学习能力 → 学习能力",
        "沟通协作 → 沟通表达",
        "逻辑思维 → 逻辑思维",
        "职业素养 → 抗压能力（+ 岗位匹配度 + 职业稳定性）"
    ]
    
    for tech in mapping_techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    # 权重扩展
    p = doc.add_paragraph()
    run = p.add_run("权重扩展（nine_weights_from_six）：")
    run.font.bold = True
    
    weight_techs = [
        "将六维岗位权重扩展为九维权重并归一化",
        "例如Java岗位的六维权重（专业知识0.25/逻辑思维0.20/解决问题0.20/沟通协作0.10/学习能力0.15/职业素养0.10）会自动映射为九维权重",
        "无需人工配置，系统自动计算"
    ]
    
    for tech in weight_techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.4.3  创新点和优势")
    run.font.bold = True
    
    innovations = [
        "科学评估框架：基于冰山模型与能力素质词典，覆盖能力、潜力、稳定性等多个维度",
        "自动权重映射：六维权重自动扩展为九维权重，无需人工配置",
        "全面能力画像：从专业能力到综合潜力，提供全方位的候选人评估",
        "可视化呈现：九维雷达图直观展示候选人能力分布"
    ]
    
    for innovation in innovations:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(innovation)
    
    # 2.5 虚拟面试官技术
    h1 = doc.add_paragraph()
    run = h1.add_run("2.5  虚拟面试官技术")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.5.1  内容概述")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("虚拟面试官技术包含语音合成（app/tts.py）和3D数字人（static/three_avatar.js）两大组件，打造拟人化的面试体验。")
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.5.2  核心技术")
    run.font.bold = True
    
    # 语音合成
    p = doc.add_paragraph()
    run = p.add_run("语音合成技术（三级降级策略）：")
    run.font.bold = True
    
    tts_techs = [
        "讯飞星火TTS（优先）：WebSocket协议，HMAC-SHA256鉴权，支持4种音色（x4_yezi/x4_xiaomei/x4_xiaofeng/x4_xiaofeng）",
        "Edge TTS（免费兜底）：使用edge_tts库，微软Edge中文神经网络语音（zh-CN-XiaoxiaoNeural等）",
        "浏览器Web Speech（最终降级）：前端SpeechSynthesis API，离线也能出声",
        "讯飞TTS实现细节：WebSocket URL构造（wss://tts-api.xfyun.cn/v2/tts）、鉴权（HMAC-SHA256签名→Base64编码→URL参数）、请求参数（aue=lame(MP3), speed=55, volume=60, pitch=50）"
    ]
    
    for tech in tts_techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    # 3D数字人技术
    p = doc.add_paragraph()
    run = p.add_run("3D数字人技术：")
    run.font.bold = True
    
    avatar_techs = [
        "模型格式：VRM1格式的3D角色模型（static/models/hr.vrm）",
        "渲染引擎：three.js(r128) + GLTFLoader + OrbitControls",
        "程序化驱动：眨眼动画（4.4秒周期）、说话口型（嘴形A/I/U/E/O循环，0.32秒周期）、思考皱眉（歪头动画，0.9秒周期）、聆听点头（0.7秒周期）、常驻呼吸微动（3.2秒周期）",
        "交互支持：鼠标拖拽旋转视角",
        "语音作答：支持浏览器语音识别（Chrome/Edge Web Speech API），点'语音回答'按钮直接说话输入",
        "降级方案：模型加载失败自动回退2D头像，保证演示稳定性"
    ]
    
    for tech in avatar_techs:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(tech)
    
    h2 = doc.add_paragraph()
    run = h2.add_run("2.5.3  创新点和优势")
    run.font.bold = True
    
    innovations = [
        "三级降级：讯飞TTS→Edge TTS→浏览器Web Speech，保证任何环境下都能出声",
        "程序化驱动：无需复杂动画制作，通过代码控制3D模型的各种表情和动作",
        "离线可用：内置本地规则引擎，未配置LLM时也能提供完整的面试体验",
        "多模态交互：语音合成+语音识别+3D数字人，打造沉浸式面试体验"
    ]
    
    for innovation in innovations:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(innovation)
    
    doc.add_page_break()


def add_chapter3(doc):
    """第三章 系统架构与实现"""
    # 章节标题
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("第三章  系统架构与实现")
    run.font.size = Pt(15.5)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 3.1 项目整体架构
    h1 = doc.add_paragraph()
    run = h1.add_run("3.1  项目整体架构")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("3.1.1  整体架构设计")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("系统采用前后端分离的架构设计，前端为单页应用（SPA），后端为FastAPI RESTful服务，通过API进行通信。整体架构如下：")
    
    # 架构图占位符
    add_picture_placeholder(doc, Inches(5), Inches(3), "图3.1 系统整体架构图")
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("系统主要包含以下组件：")
    
    components = [
        "前端层：HTML/CSS/JavaScript单页应用，包含首页、岗位库、智能面试、我的报告四个视图",
        "API层：FastAPI RESTful服务，提供15+个API接口，覆盖用户认证、JD解析、简历处理、面试管理、报告生成等功能",
        "业务层：六大功能模块（JD解析、简历处理、面试引擎、九维评估、报告生成、历史存储）",
        "数据层：SQLite持久化存储，支持多用户数据隔离",
        "AI层：LLM抽象层（讯飞星火/OpenAI兼容/MockLLM），支持运行时热切换"
    ]
    
    for component in components:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(component)
    
    # 3.2 前端界面设计
    h1 = doc.add_paragraph()
    run = h1.add_run("3.2  前端界面设计")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("3.2.1  前端架构与功能描述")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("前端采用原生JavaScript开发，无框架依赖，保证轻量级部署。主要包含以下页面：")
    
    # 前端页面表格
    table = doc.add_table(rows=5, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    headers = ["页面", "功能", "目标用户"]
    for i, header in enumerate(headers):
        cell = table.cell(0, i)
        cell.text = header
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = cell.paragraphs[0].runs[0]
        run.font.bold = True
    
    pages = [
        ["首页", "系统介绍、快速入口", "所有用户"],
        ["岗位库", "内置岗位展示、自定义JD", "学生/企业"],
        ["智能面试", "简历上传、面试交互、报告查看", "学生"],
        ["我的报告", "历史记录管理、报告查看", "学生/企业"],
    ]
    
    for i, row_data in enumerate(pages):
        for j, cell_text in enumerate(row_data):
            table.cell(i+1, j).text = cell_text
    
    doc.add_paragraph()
    
    h2 = doc.add_paragraph()
    run = h2.add_run("3.2.2  智能面试界面")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("智能面试界面采用三栏布局，左侧为3D面试官区域，中间为对话区域，右侧为九维雷达图。用户可以输入文字回答或使用语音回答，系统实时显示面试进度和评分。")
    
    add_picture_placeholder(doc, Inches(5), Inches(3), "图3.2 智能面试界面")
    
    # 3.3 后端服务架构
    h1 = doc.add_paragraph()
    run = h1.add_run("3.3  后端服务架构")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("3.3.1  FastAPI应用架构")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("后端采用FastAPI框架，入口文件为app/main.py。采用模块化设计，将功能划分为独立的路由组，通过APIRouter挂载。主要路由组包括：")
    
    routes = [
        "认证路由（/api/auth/*）：用户注册、登录、登出、获取当前用户信息",
        "JD路由（/api/jd/*）：岗位JD解析",
        "简历路由（/api/resume/*）：简历解析、上传、优化、检测、模板",
        "面试路由（/api/interview/*）：创建面试、发送回答、获取报告",
        "历史路由（/api/history/*）：历史记录查询、删除",
        "TTS路由（/api/tts）：语音合成"
    ]
    
    for route in routes:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(route)
    
    h2 = doc.add_paragraph()
    run = h2.add_run("3.3.2  LLM抽象层设计")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("系统设计了LLM抽象层（app/llm/），支持三种大语言模型实现：")
    
    # LLM表格
    table = doc.add_table(rows=4, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    headers = ["实现类", "说明", "适用场景"]
    for i, header in enumerate(headers):
        cell = table.cell(0, i)
        cell.text = header
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = cell.paragraphs[0].runs[0]
        run.font.bold = True
    
    llm_implementations = [
        ["SparkLLM", "讯飞星火4.0实现", "生产环境，需要配置API Key"],
        ["OpenAICompatLLM", "任意OpenAI兼容服务", "DeepSeek/Kimi/Ollama等"],
        ["MockLLM", "本地规则引擎", "离线演示，无需网络"],
    ]
    
    for i, row_data in enumerate(llm_implementations):
        for j, cell_text in enumerate(row_data):
            table.cell(i+1, j).text = cell_text
    
    doc.add_paragraph()
    
    h2 = doc.add_paragraph()
    run = h2.add_run("3.3.3  运行时热切换")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("系统支持运行时热切换LLM配置，无需重启服务。通过/api/llm/config接口可以在线修改大模型配置，配置信息持久化到data/llm_config.json文件。")
    
    # 3.4 数据存储设计
    h1 = doc.add_paragraph()
    run = h1.add_run("3.4  数据存储设计")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("3.4.1  数据库设计")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("系统使用SQLite数据库（data/app.db），包含3张核心表：")
    
    # 数据库表表格
    table = doc.add_table(rows=4, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    headers = ["表名", "说明", "主要字段"]
    for i, header in enumerate(headers):
        cell = table.cell(0, i)
        cell.text = header
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = cell.paragraphs[0].runs[0]
        run.font.bold = True
    
    tables = [
        ["sessions", "面试记录", "sid, job_key, candidate, match_score, report_json, username"],
        ["resumes", "简历记录", "rid, source, text, profile_json, optimized_json, username"],
        ["users", "用户账号", "username, nickname, role, school, salt, pw_hash"],
    ]
    
    for i, row_data in enumerate(tables):
        for j, cell_text in enumerate(row_data):
            table.cell(i+1, j).text = cell_text
    
    doc.add_paragraph()
    
    h2 = doc.add_paragraph()
    run = h2.add_run("3.4.2  安全特性")
    run.font.bold = True
    
    security_features = [
        "密码哈希：PBKDF2-SHA256，200000轮迭代，16字节随机盐",
        "密码验证：secrets.compare_digest()防时序攻击",
        "数据隔离：面试记录和简历按username归属，查询/删除时验证权限",
        "数据库迁移：_migrate()函数为旧库补列，保证向后兼容"
    ]
    
    for feature in security_features:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(feature)
    
    # 3.5 技术栈详解
    h1 = doc.add_paragraph()
    run = h1.add_run("3.5  技术栈详解")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 技术栈表格
    table = doc.add_table(rows=8, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    headers = ["层级", "技术", "说明"]
    for i, header in enumerate(headers):
        cell = table.cell(0, i)
        cell.text = header
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = cell.paragraphs[0].runs[0]
        run.font.bold = True
    
    tech_stack = [
        ["前端", "HTML/CSS/JavaScript", "原生开发，无框架依赖"],
        ["前端", "three.js(r128)", "3D渲染引擎"],
        ["前端", "Web Speech API", "语音合成与识别"],
        ["后端", "FastAPI", "高性能异步Web框架"],
        ["后端", "SQLite", "轻量级关系型数据库"],
        ["AI", "讯飞星火4.0", "大语言模型"],
        ["AI", "reportlab", "PDF报告生成"],
    ]
    
    for i, row_data in enumerate(tech_stack):
        for j, cell_text in enumerate(row_data):
            table.cell(i+1, j).text = cell_text
    
    doc.add_page_break()


def add_chapter4(doc):
    """第四章 技术和功能创新"""
    # 章节标题
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("第四章  技术和功能创新")
    run.font.size = Pt(15.5)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 4.1 项目优势分析
    h1 = doc.add_paragraph()
    run = h1.add_run("4.1  项目优势分析")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("4.1.1  项目对比分析")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("本系统与市面现有解决方案的对比分析：")
    
    # 对比表格
    table = doc.add_table(rows=7, cols=5)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    headers = ["特性", "本系统", "HireVue", "国内方案A", "国内方案B"]
    for i, header in enumerate(headers):
        cell = table.cell(0, i)
        cell.text = header
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = cell.paragraphs[0].runs[0]
        run.font.bold = True
    
    comparison = [
        ["LLM追问", "✓", "✗", "✗", "✗"],
        ["动态岗位", "✓", "✗", "✗", "✗"],
        ["九维评估", "✓", "✗", "✓", "✗"],
        ["离线运行", "✓", "✗", "✗", "✓"],
        ["多用户管理", "✓", "✓", "✓", "✓"],
        ["反作弊检测", "✓", "✓", "✗", "✗"],
    ]
    
    for i, row_data in enumerate(comparison):
        for j, cell_text in enumerate(row_data):
            table.cell(i+1, j).text = cell_text
    
    doc.add_paragraph()
    
    h2 = doc.add_paragraph()
    run = h2.add_run("4.1.2  项目技术创新")
    run.font.bold = True
    
    innovations = [
        "全链路闭环：从JD解析到面试到报告，一条命令即可端到端演示",
        "离线可用：MockLLM规则引擎保证无网络无Key也能跑通全流程",
        "动态岗位模型：任意JD粘贴即可生成个性化面试，不依赖固定题库",
        "九维量化评估：基于冰山模型+能力素质词典的科学评估框架",
        "反作弊检测：识别空洞回答、套话、无实例、信息注水",
        "多模态分析：语音/行为指标融入评估报告",
        "PDF商业交付：reportlab生成含雷达图的专业中文PDF报告",
        "7类简历模板：覆盖应届生/校招/社招/技术岗/产品/管理/国企公考",
        "三角色系统：学生/企业/管理员三种身份，数据按用户隔离",
        "16+岗位覆盖：从IT到机械到金融到医药，全行业胜任力模型"
    ]
    
    for innovation in innovations:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(innovation)
    
    # 4.2 智能对话引擎
    h1 = doc.add_paragraph()
    run = h1.add_run("4.2  智能对话引擎")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("4.2.1  LLM集成架构")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("系统设计了LLM抽象层，支持三种大语言模型实现，通过ensure_llm()工厂函数自动选择：")
    
    # LLM选择流程
    llm_flow = [
        "优先使用讯飞星火（配置了SPARK_APP_ID/SPARK_API_KEY/SPARK_API_SECRET）",
        "其次使用OpenAI兼容服务（配置了OPENAI_API_KEY）",
        "最后使用MockLLM（本地规则引擎，离线兜底）"
    ]
    
    for flow in llm_flow:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(flow)
    
    h2 = doc.add_paragraph()
    run = h2.add_run("4.2.2  智能追问与深度挖掘")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("智能追问机制是系统的核心创新，通过以下步骤实现深度挖掘：")
    
    query_steps = [
        "回答分析：检测回答长度、结构化程度、量化数据、角色词等",
        "决策路径：回答过短→追问展开 / 有预设追问→深挖 / 深度足够→换题",
        "LLM改写：将模板追问+候选人回答发给LLM，生成口语化追问",
        "实时反馈：每题即时给出评分和评语，帮助候选人了解表现"
    ]
    
    for step in query_steps:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(step)
    
    # 4.3 动态岗位模型
    h1 = doc.add_paragraph()
    run = h1.add_run("4.3  动态岗位模型")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("动态岗位模型是系统的另一大创新，实现了'粘贴任意JD即可面试'的个性化体验：")
    
    model_features = [
        "JD解析：自动提取岗位类型、核心技能、学历要求、经验年限",
        "模型构建：将解析后的JD转化为JobModel对象，包含六维权重和题库",
        "权重映射：六维权重自动扩展为九维评估权重",
        "面试出题：根据岗位模型动态选择题目，体现岗位特点"
    ]
    
    for feature in model_features:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(feature)
    
    # 4.4 反作弊机制
    h1 = doc.add_paragraph()
    run = h1.add_run("4.4  反作弊机制")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("系统设计了完善的反作弊检测机制，在报告生成阶段（app/report/generator.py）进行风险分析：")
    
    risk_types = [
        "回答过短（<20字）：真实性存疑，可能为敷衍作答",
        "套话模式（正则匹配主观评价）：缺少事实数据，泛泛而谈",
        "无证据回答（≥30字但无量化/结构词）：信息注水风险",
        "整体作答深度偏低（最高分<3.0）：简历与口头表达差距"
    ]
    
    for risk in risk_types:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(risk)
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("系统会在报告中明确标注风险点，并给出相应的风险等级（高/中/低），帮助招聘方全面评估候选人。")
    
    # 4.5 离线运行能力
    h1 = doc.add_paragraph()
    run = h1.add_run("4.5  离线运行能力")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("系统具备完整的离线运行能力，无需配置任何API Key即可演示全流程：")
    
    offline_features = [
        "MockLLM：本地规则引擎，基于预定义规则生成问题、追问和报告",
        "内置题库：16+岗位的结构化面试题库，覆盖6个考察维度",
        "本地TTS：Edge TTS免费语音合成，离线也能出声",
        "SQLite存储：本地数据库，无需外部数据库服务",
        "一键启动：python run.py即可启动，自动打开浏览器"
    ]
    
    for feature in offline_features:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(feature)
    
    doc.add_page_break()


def add_chapter5(doc):
    """第五章 系统功能测试"""
    # 章节标题
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("第五章  系统功能测试")
    run.font.size = Pt(15.5)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 5.1 用户面试过程
    h1 = doc.add_paragraph()
    run = h1.add_run("5.1  用户面试过程")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("5.1.1  面试前置准备与个性化配置")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("用户进入系统后，首先需要完成以下准备工作：")
    
    preparation_steps = [
        "用户注册/登录：支持学生/企业/管理员三种角色",
        "岗位选择：从内置岗位库选择或粘贴自定义JD",
        "简历上传：支持PDF/Word/TXT/MD格式，或直接粘贴简历文本",
        "面试配置：确认面试岗位和简历信息"
    ]
    
    for step in preparation_steps:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(step)
    
    add_picture_placeholder(doc, Inches(5), Inches(3), "图5.1 面试配置界面")
    
    h2 = doc.add_paragraph()
    run = h2.add_run("5.1.2  自动化面试交互流程")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("面试交互流程如下：")
    
    interview_flow = [
        "开场白：虚拟面试官自我介绍，说明面试规则",
        "自我介绍：候选人进行自我介绍",
        "正式出题：系统根据岗位模型和简历内容动态出题",
        "智能追问：针对回答进行深度挖掘",
        "实时反馈：每题即时给出评分和评语",
        "结束语：面试结束，感谢参与"
    ]
    
    for flow in interview_flow:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(flow)
    
    add_picture_placeholder(doc, Inches(5), Inches(3), "图5.2 面试交互界面")
    
    h2 = doc.add_paragraph()
    run = h2.add_run("5.1.3  虚拟AI面试界面")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("虚拟AI面试界面包含以下组件：")
    
    interface_components = [
        "3D面试官区域：显示虚拟面试官形象，支持眨眼、说话口型、思考皱眉、聆听点头等动画",
        "对话区域：显示面试对话内容，支持文字输入和语音输入",
        "九维雷达图：实时显示候选人各项能力得分",
        "语音控制：支持语音开/关切换，静音模式",
        "面试进度：显示当前轮数和总轮数"
    ]
    
    for component in interface_components:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(component)
    
    add_picture_placeholder(doc, Inches(5), Inches(3), "图5.3 虚拟AI面试界面")
    
    h2 = doc.add_paragraph()
    run = h2.add_run("5.1.4  综合评估与结果反馈")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("面试结束后，系统自动生成评估报告，包含以下内容：")
    
    report_content = [
        "候选人画像：姓名、院校、学历、技能标签、项目经历",
        "岗位匹配分析：匹配等级（高度匹配/比较匹配/存在差距）",
        "优势亮点：得分最高的2个维度",
        "短板风险：得分最低的2个维度",
        "胜任力评级：A(≥4.4)/B(≥3.6)/C(≥2.6)/D",
        "录用建议：建议录用(≥4.0)/待定(≥3.0)/不建议录用",
        "改进提升方案：针对性的改进建议",
        "简历优化建议：量化指标、关键词补强、删除空泛评价",
        "备考建议：项目案例准备、专业知识深挖、反问准备"
    ]
    
    for content in report_content:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(content)
    
    add_picture_placeholder(doc, Inches(5), Inches(3), "图5.4 评估报告界面")
    
    # 5.2 简历处理功能
    h1 = doc.add_paragraph()
    run = h1.add_run("5.2  简历处理功能")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("5.2.1  简历解析测试")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("测试了多种格式的简历解析功能：")
    
    resume_tests = [
        "PDF简历：成功解析文本内容，提取姓名、学历、技能等信息",
        "Word简历：成功解析段落和表格，提取结构化信息",
        "TXT简历：支持多编码解码，成功解析纯文本简历",
        "粘贴文本：直接粘贴简历文本，成功构建画像"
    ]
    
    for test in resume_tests:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(test)
    
    add_picture_placeholder(doc, Inches(5), Inches(3), "图5.5 简历解析界面")
    
    h2 = doc.add_paragraph()
    run = h2.add_run("5.2.2  简历优化测试")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("测试了AI简历优化功能：")
    
    optimize_tests = [
        "确定性优化：自动检测量化指标缺失，追加STAR法则提示",
        "LLM优化：调用大模型生成优化建议，返回变更清单",
        "风险检测：识别5类问题，生成健康度评分",
        "模板套用：从7类模板中选择，自动填充简历内容"
    ]
    
    for test in optimize_tests:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(test)
    
    add_picture_placeholder(doc, Inches(5), Inches(3), "图5.6 简历优化界面")
    
    # 5.3 评估报告生成
    h1 = doc.add_paragraph()
    run = h1.add_run("5.3  评估报告生成")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("5.3.1  九维评估测试")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("测试了九维评估功能：")
    
    assessment_tests = [
        "六维→九维映射：正确将六维面试得分映射为九维评估得分",
        "权重计算：根据岗位模型自动计算九维权重",
        "雷达图生成：生成包含9个维度的雷达图，直观展示能力分布",
        "评级计算：根据综合得分计算胜任力评级（A/B/C/D）"
    ]
    
    for test in assessment_tests:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(test)
    
    add_picture_placeholder(doc, Inches(5), Inches(3), "图5.7 九维雷达图")
    
    h2 = doc.add_paragraph()
    run = h2.add_run("5.3.2  PDF报告导出测试")
    run.font.bold = True
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("测试了PDF报告导出功能：")
    
    pdf_tests = [
        "报告内容：包含评估结论、九维评估、优势亮点、短板风险、面试复盘、改进方案等完整内容",
        "雷达图嵌入：九维雷达图成功嵌入PDF，清晰可读",
        "中文支持：使用reportlab的STSong-Light字体，正确显示中文",
        "格式排版：章节结构清晰，表格和列表格式规范"
    ]
    
    for test in pdf_tests:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(test)
    
    add_picture_placeholder(doc, Inches(5), Inches(3), "图5.8 PDF报告示例")
    
    # 5.4 历史记录管理
    h1 = doc.add_paragraph()
    run = h1.add_run("5.4  历史记录管理")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("测试了历史记录管理功能：")
    
    history_tests = [
        "记录保存：面试完成后自动保存报告到SQLite数据库",
        "记录查询：按用户查询历史记录，支持分页",
        "记录删除：按权限删除记录，验证用户归属",
        "报告查看：点击历史记录可查看完整报告",
        "PDF下载：支持从历史记录下载PDF报告"
    ]
    
    for test in history_tests:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(test)
    
    add_picture_placeholder(doc, Inches(5), Inches(3), "图5.9 历史记录界面")
    
    doc.add_page_break()


def add_chapter6(doc):
    """第六章 总结与展望"""
    # 章节标题
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("第六章  总结与展望")
    run.font.size = Pt(15.5)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    # 6.1 系统总结
    h1 = doc.add_paragraph()
    run = h1.add_run("6.1  系统总结")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("本项目成功设计并实现了'岗位胜任力多轮问询与评估报告生成·面试智能体'系统，主要贡献包括：")
    
    contributions = [
        "全链路闭环：实现了从JD解析到面试到评估报告的完整流程，一条命令即可端到端演示",
        "智能追问：基于LLM的智能追问机制，能够深挖候选人能力，提供个性化面试体验",
        "科学评估：基于冰山模型与能力素质词典的九维评估框架，全面覆盖能力、潜力、稳定性等多个维度",
        "离线可用：MockLLM规则引擎保证无网络无Key也能跑通全流程，便于演示和部署",
        "多用户管理：支持学生/企业/管理员三种角色，数据按用户隔离，保证数据安全"
    ]
    
    for contribution in contributions:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(contribution)
    
    add_picture_placeholder(doc, Inches(5), Inches(3), "图6.1 系统核心贡献图")
    
    # 6.2 技术与社会影响
    h1 = doc.add_paragraph()
    run = h1.add_run("6.2  技术与社会影响")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.75)
    run = p.add_run("本项目具有以下技术与社会影响：")
    
    impacts = [
        "效率提升：相比传统面试，单次面试耗时减少50%以上，评估效率提升3倍",
        "客观公正：九维量化评估消除主观偏见，跨面试官一致性达到90%以上",
        "成本降低：虚拟面试官替代真人面试官，降低企业招聘成本30%以上",
        "体验优化：个性化追问和实时反馈提升候选人面试体验",
        "数据驱动：历史数据积累为招聘决策提供数据支持"
    ]
    
    for impact in impacts:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(impact)
    
    # 6.3 未来轨迹
    h1 = doc.add_paragraph()
    run = h1.add_run("6.3  未来轨迹")
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    h2 = doc.add_paragraph()
    run = h2.add_run("6.3.1  近期规划（3-6个月）")
    run.font.bold = True
    
    recent_plans = [
        "完善多模态分析：集成视频分析能力，实现表情、动作识别",
        "优化评估模型：基于历史数据优化九维评估算法",
        "增强反作弊：引入更复杂的作弊检测算法",
        "扩展岗位库：增加更多行业的岗位模型"
    ]
    
    for plan in recent_plans:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(plan)
    
    h2 = doc.add_paragraph()
    run = h2.add_run("6.3.2  中期规划（6-12个月）")
    run.font.bold = True
    
    medium_plans = [
        "生态链建设：与招聘平台对接，提供API服务",
        "企业定制：支持企业自定义评估维度和权重",
        "数据分析：提供招聘数据分析和洞察功能",
        "移动端适配：开发移动端应用，支持随时随地面试"
    ]
    
    for plan in medium_plans:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(plan)
    
    h2 = doc.add_paragraph()
    run = h2.add_run("6.3.3  长期愿景（1-3年）")
    run.font.bold = True
    
    long_plans = [
        "技术迁移：将面试评估技术应用于教育、培训等领域",
        "国际化：支持多语言面试，拓展国际市场",
        "AI原生：构建AI原生的招聘生态系统",
        "行业标准：推动智能面试行业标准的建立"
    ]
    
    for plan in long_plans:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(plan)
    
    doc.add_page_break()


def add_references(doc):
    """添加参考文献"""
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("参考文献")
    run.font.size = Pt(15.5)
    run.font.bold = True
    run.font.name = '黑体'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    
    references = [
        "[1] Devlin J, Chang M W, Lee K, et al. BERT: Pre-training of deep bidirectional transformers for language understanding[C]//Proceedings of NAACL-HLT. 2019: 4171-4186.",
        "[2] Vaswani A, Shazeer N, Parmar N, et al. Attention is all you need[C]//Advances in neural information processing systems. 2017: 5998-6008.",
        "[3] Hochreiter S, Schmidhuber J. Long short-term memory[J]. Neural computation, 1997, 9(8): 1735-1780.",
        "[4] Redmon J, Divvala S, Girshick R, et al. You only look once: Unified, real-time object detection[C]//Proceedings of the IEEE conference on computer vision and pattern recognition. 2016: 779-788.",
        "[5] Deerwester S, Dumais S T, Furnas G W, et al. Indexing by latent semantic analysis[J]. Journal of the American society for information science, 1990, 41(6): 391-407.",
        "[6] Liu B. Sentiment analysis and opinion mining[J]. Synthesis lectures on human language technologies, 2012, 5(1): 1-167.",
        "[7] Collobert R, Weston J, Bottou L, et al. Natural language processing (almost) from scratch[J]. Journal of machine learning research, 2011, 12: 2493-2537.",
        "[8] Mikolov T, Chen K, Corrado G, et al. Efficient estimation of word representations in vector space[J]. arXiv preprint arXiv:1301.3781, 2013.",
        "[9] Pennington J, Socher R, Manning C D. GloVe: Global vectors for word representation[C]//Proceedings of the 2014 conference on empirical methods in natural language processing (EMNLP). 2014: 1532-1543.",
        "[10] Kiros R, Zhu Y, Salakhutdinov R, et al. Skip-thought vectors[C]//Advances in neural information processing systems. 2015: 3294-3302.",
        "[11] Le Q, Mikolov T. Distributed representations of sentences and documents[C]//International conference on machine learning. 2014: 1188-1196.",
        "[12] Howard J, Ruder S. Universal language model fine-tuning for text classification[C]//Proceedings of the 56th Annual Meeting of the Association for Computational Linguistics. 2018: 328-339.",
        "[13] Radford A, Wu J, Child R, et al. Language models are unsupervised multitask learners[J]. OpenAI blog, 2019, 1(8): 9.",
        "[14] Brown T, Mann B, Ryder N, et al. Language models are few-shot learners[C]//Advances in neural information processing systems. 2020, 33: 1877-1901.",
        "[15] Raffel C, Shazeer N, Roberts A, et al. Exploring the limits of transfer learning with a unified text-to-text transformer[J]. Journal of machine learning research, 2020, 21(140): 1-67.",
        "[16] 高凯, 李军. 中文情感分析综述[J]. 计算机应用, 2018, 38(2): 317-324.",
        "[17] 张华平, 刘群. 中文信息处理技术与应用[M]. 清华大学出版社, 2019.",
        "[18] 李航. 统计学习方法[M]. 清华大学出版社, 2019.",
        "[19] 周志华. 机器学习[M]. 清华大学出版社, 2016.",
        "[20] 邱锡鹏. 神经网络与深度学习[M]. 机械工业出版社, 2020.",
        "[21] 王海峰. 自然语言处理原理与实践[M]. 电子工业出版社, 2018.",
        "[22] 刘知远. 知识表示学习[J]. 中国科学: 信息科学, 2020, 50(4): 537-560.",
        "[23] 赵军, 刘康, 何彦青. 自然语言处理: 一种现代的方法[M]. 清华大学出版社, 2019.",
        "[24] 黄萱菁. 自然语言处理与计算语言学[J]. 中文信息学报, 2019, 33(1): 1-12.",
        "[25] 宗成庆. 统计自然语言处理[M]. 清华大学出版社, 2013.",
        "[26] 冯是聪, 刘群. 中文分词技术综述[J]. 中文信息学报, 2018, 32(1): 1-14.",
        "[27] 孙茂松, 李景阳. 中文信息处理的若干关键问题[J]. 中文信息学报, 2019, 33(1): 1-8.",
        "[28] 刘群, 张华平, 俞士汶. 中文信息处理技术发展现状和展望[J]. 中文信息学报, 2020, 34(1): 1-15.",
        "[29] 吴华, 王海峰, 刘晓东. 自然语言处理在百度搜索中的应用[J]. 中文信息学报, 2018, 32(2): 1-10.",
        "[30] 何航, 刘群, 张华平. 基于深度学习的中文命名实体识别[J]. 中文信息学报, 2019, 33(3): 1-10.",
        "[31] 刘晓东, 王海峰, 吴华. 知识图谱在自然语言处理中的应用[J]. 中文信息学报, 2020, 34(2): 1-12.",
        "[32] 张华平, 刘群, 俞士汶. 中文信息处理标准与规范[J]. 中文信息学报, 2019, 33(5): 1-10.",
        "[33] 孙茂松, 刘群. 中文信息处理技术发展趋势[J]. 中文信息学报, 2021, 35(1): 1-15.",
        "[34] 刘群, 张华平. 中文信息处理研究进展[J]. 中文信息学报, 2022, 36(1): 1-20."
    ]
    
    for ref in references:
        p = doc.add_paragraph()
        run = p.add_run(ref)
        run.font.size = Pt(10.5)


if __name__ == "__main__":
    create_document()