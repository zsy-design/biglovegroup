# 岗位胜任力多轮问询与评估报告生成·面试智能体 API接口文档

## 1. 概述

### 1.1 基础信息

- 基础URL: `http://127.0.0.1:8010`
- 数据格式: JSON
- 认证方式: Bearer Token

### 1.2 通用响应格式

```json
{
    "code": 200,
    "message": "success",
    "data": {}
}
```

### 1.3 错误码

| 错误码 | 说明 |
|--------|------|
| 200 | 成功 |
| 400 | 请求参数错误 |
| 401 | 未认证 |
| 403 | 无权限 |
| 404 | 资源不存在 |
| 500 | 服务器内部错误 |

## 2. 认证接口

### 2.1 获取角色列表

```
GET /api/auth/roles
```

**响应:**
```json
{
    "roles": ["student", "enterprise", "admin"]
}
```

### 2.2 用户注册

```
POST /api/auth/register
```

**请求体:**
```json
{
    "username": "testuser",
    "password": "123456",
    "nickname": "测试用户",
    "role": "student",
    "school": "北京大学"
}
```

**响应:**
```json
{
    "token": "eyJ...",
    "user": {
        "username": "testuser",
        "nickname": "测试用户",
        "role": "student"
    }
}
```

### 2.3 用户登录

```
POST /api/auth/login
```

**请求体:**
```json
{
    "username": "testuser",
    "password": "123456"
}
```

**响应:**
```json
{
    "token": "eyJ...",
    "user": {
        "username": "testuser",
        "nickname": "测试用户",
        "role": "student"
    }
}
```

### 2.4 用户登出

```
POST /api/auth/logout
Authorization: Bearer <token>
```

**响应:**
```json
{
    "message": "已登出"
}
```

### 2.5 获取当前用户

```
GET /api/auth/me
Authorization: Bearer <token>
```

**响应:**
```json
{
    "username": "testuser",
    "nickname": "测试用户",
    "role": "student"
}
```

## 3. 岗位接口

### 3.1 获取岗位列表

```
GET /api/jobs
```

**响应:**
```json
{
    "jobs": [
        {
            "key": "java",
            "name": "Java开发工程师",
            "type": "内置"
        },
        {
            "key": "python",
            "name": "Python开发工程师",
            "type": "内置"
        }
    ]
}
```

### 3.2 JD解析

```
POST /api/jd/parse
```

**请求体:**
```json
{
    "jd_text": "岗位描述文本..."
}
```

**响应:**
```json
{
    "job_key": "custom",
    "job_name": "自定义岗位",
    "type": "自定义",
    "skills": ["Python", "算法"],
    "education": "本科",
    "experience": "3年",
    "difficulty": "中",
    "questions": [...]
}
```

## 4. 简历接口

### 4.1 简历解析

```
POST /api/resume/parse
```

**请求体:**
```json
{
    "text": "简历文本内容..."
}
```

**响应:**
```json
{
    "profile": {
        "name": "张三",
        "education": "本科",
        "school": "北京大学",
        "skills": ["Python", "Java"],
        "best_job": "Java开发工程师",
        "match_score": 0.85
    }
}
```

### 4.2 简历上传

```
POST /api/resume/upload
Content-Type: multipart/form-data
```

**请求参数:**
- file: 简历文件(PDF/Word/TXT)

**响应:**
```json
{
    "rid": "abc123def456",
    "profile": {
        "name": "张三",
        "education": "本科",
        ...
    }
}
```

### 4.3 AI简历优化

```
POST /api/resume/optimize
```

**请求体:**
```json
{
    "text": "简历文本内容...",
    "jd_text": "岗位描述(可选)..."
}
```

**响应:**
```json
{
    "optimized": "优化后的简历文本",
    "changes": [
        "添加了量化指标",
        "优化了项目描述"
    ],
    "health_score": 85
}
```

### 4.4 简历风险检测

```
POST /api/resume/analyze
```

**请求体:**
```json
{
    "text": "简历文本内容..."
}
```

**响应:**
```json
{
    "health_score": 85,
    "risks": [
        {
            "type": "缺乏量化",
            "severity": "high",
            "suggestion": "添加具体数据指标"
        }
    ]
}
```

### 4.5 获取模板列表

```
GET /api/resume/templates
```

**响应:**
```json
{
    "templates": [
        {
            "id": "fresh",
            "name": "应届生清新模板",
            "description": "适合应届毕业生使用"
        },
        {
            "id": "campus",
            "name": "校招标准模板",
            "description": "校园招聘标准格式"
        }
    ]
}
```

### 4.6 套用模板

```
POST /api/resume/apply-template
```

**请求体:**
```json
{
    "rid": "abc123def456",
    "template_id": "fresh"
}
```

**响应:**
```json
{
    "optimized": "套用模板后的简历文本"
}
```

## 5. 面试接口

### 5.1 创建面试

```
POST /api/interview/start
Authorization: Bearer <token>
```

**请求体:**
```json
{
    "job_key": "java",
    "resume_text": "简历文本(可选)",
    "jd_text": "自定义JD(可选)"
}
```

**响应:**
```json
{
    "session_id": "abc123def456",
    "first_question": {
        "text": "请做一下自我介绍",
        "dimension": "沟通表达"
    }
}
```

### 5.2 发送回答

```
POST /api/interview/respond?session_id=abc123def456
Authorization: Bearer <token>
```

**请求体:**
```json
{
    "answer": "我的回答内容...",
    "voice_metrics": {
        "speed": 150,
        "duration": 12
    }
}
```

**响应:**
```json
{
    "next_question": {
        "text": "请详细介绍一下你的项目经历",
        "dimension": "实操经验"
    },
    "evaluation": {
        "score": 4.2,
        "comment": "回答详细，有具体案例"
    },
    "is_last": false,
    "progress": {
        "current": 2,
        "total": 6
    }
}
```

### 5.3 获取报告

```
GET /api/interview/{sid}/report
Authorization: Bearer <token>
```

**响应:**
```json
{
    "sid": "abc123def456",
    "job_name": "Java开发工程师",
    "candidate": "张三",
    "nine_scores": {
        "专业能力": 4.5,
        "实操经验": 4.0,
        "学习能力": 4.2,
        "沟通表达": 3.8,
        "逻辑思维": 4.1,
        "抗压能力": 3.5,
        "岗位匹配度": 4.3,
        "职业稳定性": 4.0,
        "综合潜力": 4.1
    },
    "rating": "B",
    "recommendation": "建议录用",
    "text_report": "完整报告文本...",
    "created_at": 1694102400
}
```

### 5.4 导出PDF

```
GET /api/interview/{sid}/report.pdf
Authorization: Bearer <token>
```

**响应:** PDF文件流

## 6. 历史记录接口

### 6.1 获取历史列表

```
GET /api/history
Authorization: Bearer <token>
```

**响应:**
```json
{
    "records": [
        {
            "sid": "abc123def456",
            "job_name": "Java开发工程师",
            "candidate": "张三",
            "match_percent": 85,
            "rating": "B",
            "created_at": 1694102400
        }
    ]
}
```

### 6.2 获取单份历史

```
GET /api/history/{sid}
Authorization: Bearer <token>
```

**响应:** 同获取报告接口

### 6.3 删除历史记录

```
DELETE /api/history/{sid}
Authorization: Bearer <token>
```

**响应:**
```json
{
    "message": "已删除"
}
```

## 7. 语音合成接口

### 7.1 语音合成

```
POST /api/tts
```

**请求体:**
```json
{
    "text": "你好，我是面试官",
    "voice": "x4_xiaomei"
}
```

**响应:**
```json
{
    "audio_base64": "base64编码的音频数据",
    "format": "mp3",
    "source": "xfyun"
}
```

**可用音色:**
- x4_yezi: 叶子
- x4_xiaomei: 小美
- x4_xiaofeng: 小峰
- x4_xiaofeng: 小风

## 8. 健康检查接口

### 8.1 健康检查

```
GET /api/health
```

**响应:**
```json
{
    "status": "ok",
    "llm_provider": "mock",
    "version": "1.0.0"
}
```

## 9. LLM配置接口

### 9.1 获取当前配置

```
GET /api/llm/config
```

**响应:**
```json
{
    "provider": "mock",
    "spark_configured": false,
    "openai_configured": false
}
```

### 9.2 更新配置

```
POST /api/llm/config
```

**请求体:**
```json
{
    "provider": "spark",
    "spark_app_id": "xxx",
    "spark_api_key": "xxx",
    "spark_api_secret": "xxx"
}
```

**响应:**
```json
{
    "message": "配置已更新"
}
```

## 10. 请求示例

### 10.1 完整面试流程

```python
import requests

BASE_URL = "http://127.0.0.1:8010"

# 1. 注册/登录
resp = requests.post(f"{BASE_URL}/api/auth/login", json={
    "username": "testuser",
    "password": "123456"
})
token = resp.json()["token"]
headers = {"Authorization": f"Bearer {token}"}

# 2. 创建面试
resp = requests.post(f"{BASE_URL}/api/interview/start", 
    headers=headers,
    json={"job_key": "java"}
)
session_id = resp.json()["session_id"]

# 3. 发送回答
resp = requests.post(f"{BASE_URL}/api/interview/respond?session_id={session_id}",
    headers=headers,
    json={"answer": "我的回答..."}
)

# 4. 获取报告
resp = requests.get(f"{BASE_URL}/api/interview/{session_id}/report",
    headers=headers)
report = resp.json()
```

## 11. 错误处理

### 11.1 常见错误响应

```json
{
    "detail": "未认证，请先登录"
}
```

```json
{
    "detail": "用户不存在"
}
```

```json
{
    "detail": "密码错误"
}
```

### 11.2 参数验证错误

```json
{
    "detail": [
        {
            "loc": ["body", "username"],
            "msg": "field required",
            "type": "value_error.missing"
        }
    ]
}
```