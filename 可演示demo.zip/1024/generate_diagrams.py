#!/usr/bin/env python3
"""
使用Pillow生成系统架构图和ER图
"""
import os
from PIL import Image, ImageDraw, ImageFont


def get_font(size=16):
    """获取中文字体"""
    # Windows系统中文字体路径
    font_paths = [
        "C:/Windows/Fonts/simsun.ttc",  # 宋体
        "C:/Windows/Fonts/simhei.ttf",  # 黑体
        "C:/Windows/Fonts/msyh.ttc",    # 微软雅黑
    ]
    
    for font_path in font_paths:
        if os.path.exists(font_path):
            try:
                return ImageFont.truetype(font_path, size)
            except:
                continue
    
    # 如果找不到中文字体，使用默认字体
    return ImageFont.load_default()


def draw_rounded_rect(draw, xy, radius, fill, outline=None, width=1):
    """绘制圆角矩形"""
    x1, y1, x2, y2 = xy
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=width)


def draw_arrow(draw, start, end, color="#333333", width=2):
    """绘制箭头"""
    draw.line([start, end], fill=color, width=width)
    # 简单的箭头
    dx = end[0] - start[0]
    dy = end[1] - start[1]
    length = (dx**2 + dy**2) ** 0.5
    if length == 0:
        return
    dx, dy = dx/length, dy/length
    arrow_size = 10
    arrow_x = end[0] - dx * arrow_size
    arrow_y = end[1] - dy * arrow_size
    draw.polygon([
        end,
        (arrow_x - dy * arrow_size/2, arrow_y + dx * arrow_size/2),
        (arrow_x + dy * arrow_size/2, arrow_y - dx * arrow_size/2),
    ], fill=color)


def generate_architecture_diagram():
    """生成系统架构图"""
    width, height = 1200, 900
    img = Image.new('RGB', (width, height), '#FFFFFF')
    draw = ImageDraw.Draw(img)
    
    title_font = get_font(20)
    label_font = get_font(14)
    small_font = get_font(11)
    
    # 标题
    draw.text((width//2 - 150, 20), "图3.1 系统整体架构图", fill='#000000', font=title_font)
    
    # === 第一层：前端展示层 ===
    y1 = 70
    draw_rounded_rect(draw, (50, y1, 1150, y1+120), 10, fill='#E3F2FD', outline='#1565C0', width=2)
    draw.text((70, y1+5), "前端展示层 (HTML/CSS/JavaScript)", fill='#1565C0', font=label_font)
    
    frontend_items = ["首页", "岗位库", "智能面试", "我的报告"]
    for i, item in enumerate(frontend_items):
        x = 100 + i * 260
        draw_rounded_rect(draw, (x, y1+35, x+220, y1+100), 8, fill='#BBDEFB', outline='#1976D2')
        draw.text((x+60, y1+55), item, fill='#0D47A1', font=label_font)
    
    # 箭头向下
    draw_arrow(draw, (600, y1+120), (600, y1+150), '#1565C0', 2)
    
    # === 第二层：API网关层 ===
    y2 = 155
    draw_rounded_rect(draw, (50, y2, 1150, y2+100), 10, fill='#E8F5E9', outline='#2E7D32', width=2)
    draw.text((70, y2+5), "API网关层 (FastAPI RESTful Service)", fill='#2E7D32', font=label_font)
    
    api_items = ["/api/auth/*", "/api/jd/*", "/api/resume/*", "/api/interview/*", "/api/history/*", "/api/tts"]
    for i, item in enumerate(api_items):
        x = 70 + i * 185
        draw_rounded_rect(draw, (x, y2+30, x+170, y2+80), 6, fill='#C8E6C9', outline='#388E3C')
        draw.text((x+15, y2+48), item, fill='#1B5E20', font=small_font)
    
    # 箭头向下
    draw_arrow(draw, (600, y2+100), (600, y2+130), '#2E7D32', 2)
    
    # === 第三层：业务逻辑层 ===
    y3 = 290
    draw_rounded_rect(draw, (50, y3, 1150, y3+200), 10, fill='#FFF3E0', outline='#E65100', width=2)
    draw.text((70, y3+5), "业务逻辑层 (六大功能模块)", fill='#E65100', font=label_font)
    
    # 第一行模块
    modules_row1 = [
        ("岗位JD智能解析", "app/jd.py"),
        ("简历智能处理", "app/resume/*"),
        ("虚拟AI多轮面试", "app/interview/"),
    ]
    for i, (name, path) in enumerate(modules_row1):
        x = 80 + i * 370
        draw_rounded_rect(draw, (x, y3+35, x+340, y3+100), 8, fill='#FFE0B2', outline='#F57C00')
        draw.text((x+80, y3+48), name, fill='#E65100', font=label_font)
        draw.text((x+60, y3+72), path, fill='#BF360C', font=small_font)
    
    # 第二行模块
    modules_row2 = [
        ("九维胜任力评估", "app/competency/"),
        ("智能评估报告", "app/report/"),
        ("数据看板与历史", "app/storage.py"),
    ]
    for i, (name, path) in enumerate(modules_row2):
        x = 80 + i * 370
        draw_rounded_rect(draw, (x, y3+110, x+340, y3+175), 8, fill='#FFE0B2', outline='#F57C00')
        draw.text((x+80, y3+123), name, fill='#E65100', font=label_font)
        draw.text((x+60, y3+147), path, fill='#BF360C', font=small_font)
    
    # 箭头向下
    draw_arrow(draw, (600, y3+200), (600, y3+230), '#E65100', 2)
    
    # === 第四层：AI服务层 ===
    y4 = 525
    draw_rounded_rect(draw, (50, y4, 750, y4+120), 10, fill='#F3E5F5', outline='#6A1B9A', width=2)
    draw.text((70, y4+5), "AI服务层 (LLM抽象层)", fill='#6A1B9A', font=label_font)
    
    ai_items = ["讯飞星火4.0", "OpenAI兼容", "MockLLM(离线)"]
    for i, item in enumerate(ai_items):
        x = 80 + i * 220
        draw_rounded_rect(draw, (x, y4+35, x+200, y4+95), 6, fill='#E1BEE7', outline='#9C27B0')
        draw.text((x+25, y4+60), item, fill='#4A148C', font=label_font)
    
    # 语音合成模块
    draw_rounded_rect(draw, (780, y4, 1150, y4+120), 10, fill='#FCE4EC', outline='#AD1457', width=2)
    draw.text((800, y4+5), "语音合成 (TTS)", fill='#AD1457', font=label_font)
    
    tts_items = ["讯飞TTS", "Edge TTS", "Web Speech"]
    for i, item in enumerate(tts_items):
        x = 800 + i * 115
        draw_rounded_rect(draw, (x, y4+35, x+105, y4+95), 6, fill='#F8BBD0', outline='#E91E63')
        draw.text((x+10, y4+60), item, fill='#880E4F', font=small_font)
    
    # 箭头向下
    draw_arrow(draw, (400, y4+120), (400, y4+150), '#6A1B9A', 2)
    
    # === 第五层：数据存储层 ===
    y5 = 695
    draw_rounded_rect(draw, (50, y5, 750, y5+100), 10, fill='#ECEFF1', outline='#37474F', width=2)
    draw.text((70, y5+5), "数据存储层 (SQLite)", fill='#37474F', font=label_font)
    
    db_items = ["users表", "sessions表", "resumes表", "llm_config.json"]
    for i, item in enumerate(db_items):
        x = 80 + i * 165
        draw_rounded_rect(draw, (x, y5+35, x+150, y5+80), 6, fill='#CFD8DC', outline='#607D8B')
        draw.text((x+15, y5+50), item, fill='#263238', font=small_font)
    
    # 3D模型存储
    draw_rounded_rect(draw, (780, y5, 1150, y5+100), 10, fill='#E0F7FA', outline='#00695C', width=2)
    draw.text((800, y5+5), "静态资源", fill='#00695C', font=label_font)
    
    static_items = ["VRM模型", "Three.js", "前端页面"]
    for i, item in enumerate(static_items):
        x = 800 + i * 115
        draw_rounded_rect(draw, (x, y5+35, x+105, y5+80), 6, fill='#B2DFDB', outline='#009688')
        draw.text((x+10, y5+50), item, fill='#004D40', font=small_font)
    
    # === 第六层：用户层 ===
    y6 = 845
    user_items = ["学生用户", "企业用户", "管理员"]
    colors = ['#1565C0', '#2E7D32', '#E65100']
    for i, (item, color) in enumerate(zip(user_items, colors)):
        x = 300 + i * 220
        draw_rounded_rect(draw, (x, y6, x+180, y6+45), 8, fill=color, outline=color)
        draw.text((x+30, y6+12), item, fill='#FFFFFF', font=label_font)
    
    # 箭头向上
    draw_arrow(draw, (400, y6), (400, y6-20), '#333333', 2)
    
    img.save('images/architecture.png', quality=95)
    print("架构图已生成: images/architecture.png")


def generate_er_diagram():
    """生成数据库ER图"""
    width, height = 1200, 700
    img = Image.new('RGB', (width, height), '#FFFFFF')
    draw = ImageDraw.Draw(img)
    
    title_font = get_font(20)
    header_font = get_font(14)
    field_font = get_font(12)
    
    # 标题
    draw.text((width//2 - 120, 20), "图3.2 数据库ER关系图", fill='#000000', font=title_font)
    
    # === users表 ===
    x1, y1 = 50, 80
    draw_rounded_rect(draw, (x1, y1, x1+280, y1+250), 10, fill='#E3F2FD', outline='#1565C0', width=2)
    draw.text((x1+90, y1+10), "users", fill='#0D47A1', font=header_font)
    draw.line([(x1, y1+35), (x1+280, y1+35)], fill='#1565C0', width=2)
    
    users_fields = [
        ("id", "INTEGER", "PK"),
        ("username", "TEXT", "UNIQUE"),
        ("nickname", "TEXT", ""),
        ("role", "TEXT", "DEFAULT 'student'"),
        ("school", "TEXT", ""),
        ("salt", "TEXT", "PBKDF2盐"),
        ("pw_hash", "TEXT", "密码哈希"),
        ("created_at", "REAL", "时间戳"),
    ]
    for i, (name, dtype, desc) in enumerate(users_fields):
        y = y1 + 45 + i * 25
        pk = "🔑 " if "PK" in desc else "   "
        draw.text((x1+10, y), f"{pk}{name}", fill='#000000', font=field_font)
        draw.text((x1+130, y), dtype, fill='#666666', font=field_font)
        draw.text((x1+200, y), desc, fill='#999999', font=field_font)
    
    # === sessions表 ===
    x2, y2 = 450, 80
    draw_rounded_rect(draw, (x2, y2, x2+350, y2+250), 10, fill='#E8F5E9', outline='#2E7D32', width=2)
    draw.text((x2+130, y2+10), "sessions", fill='#1B5E20', font=header_font)
    draw.line([(x2, y2+35), (x2+350, y2+35)], fill='#2E7D32', width=2)
    
    sessions_fields = [
        ("sid", "TEXT", "PK"),
        ("created_at", "REAL", "时间戳"),
        ("job_key", "TEXT", "FK→岗位"),
        ("job_name", "TEXT", "岗位名称"),
        ("candidate", "TEXT", "候选人"),
        ("match_score", "REAL", "匹配分数"),
        ("match_percent", "INTEGER", "匹配百分比"),
        ("status", "TEXT", "状态"),
        ("report_json", "TEXT", "报告JSON"),
        ("username", "TEXT", "FK→users"),
    ]
    for i, (name, dtype, desc) in enumerate(sessions_fields):
        y = y2 + 45 + i * 22
        pk = "🔑 " if "PK" in desc else "   "
        fk = "🔗 " if "FK" in desc else "   "
        draw.text((x2+10, y), f"{pk}{fk}{name}", fill='#000000', font=field_font)
        draw.text((x2+160, y), dtype, fill='#666666', font=field_font)
        draw.text((x2+230, y), desc, fill='#999999', font=field_font)
    
    # === resumes表 ===
    x3, y3 = 880, 80
    draw_rounded_rect(draw, (x3, y3, x3+290, y3+220), 10, fill='#FFF3E0', outline='#E65100', width=2)
    draw.text((x3+100, y3+10), "resumes", fill='#BF360C', font=header_font)
    draw.line([(x3, y3+35), (x3+290, y3+35)], fill='#E65100', width=2)
    
    resumes_fields = [
        ("rid", "TEXT", "PK"),
        ("created_at", "REAL", "时间戳"),
        ("source", "TEXT", "来源"),
        ("text", "TEXT", "简历原文"),
        ("profile_json", "TEXT", "画像JSON"),
        ("optimized_json", "TEXT", "优化JSON"),
        ("username", "TEXT", "FK→users"),
    ]
    for i, (name, dtype, desc) in enumerate(resumes_fields):
        y = y3 + 45 + i * 25
        pk = "🔑 " if "PK" in desc else "   "
        fk = "🔗 " if "FK" in desc else "   "
        draw.text((x3+10, y), f"{pk}{fk}{name}", fill='#000000', font=field_font)
        draw.text((x3+120, y), dtype, fill='#666666', font=field_font)
        draw.text((x3+180, y), desc, fill='#999999', font=field_font)
    
    # === 关系线 ===
    # users.username → sessions.username
    draw_arrow(draw, (x1+280, y1+100), (x2, y2+100), '#1565C0', 2)
    draw.text((x1+300, y1+90), "1:N", fill='#1565C0', font=field_font)
    
    # users.username → resumes.username
    draw_arrow(draw, (x1+280, y1+160), (x3, y3+160), '#E65100', 2)
    draw.text((x1+350, y1+150), "1:N", fill='#E65100', font=field_font)
    
    # === LLM配置区域 ===
    x4, y4 = 50, 400
    draw_rounded_rect(draw, (x4, y4, x4+350, y4+150), 10, fill='#F3E5F5', outline='#6A1B9A', width=2)
    draw.text((x4+80, y4+10), "llm_config.json", fill='#4A148C', font=header_font)
    draw.line([(x4, y4+35), (x4+350, y4+35)], fill='#6A1B9A', width=2)
    
    config_fields = [
        ("provider", "STRING", "spark/openai/mock"),
        ("spark_app_id", "STRING", "讯飞AppID"),
        ("spark_api_key", "STRING", "讯飞APIKey"),
        ("spark_api_secret", "STRING", "讯飞APISecret"),
        ("openai_api_key", "STRING", "OpenAI Key"),
    ]
    for i, (name, dtype, desc) in enumerate(config_fields):
        y = y4 + 45 + i * 20
        draw.text((x4+10, y), name, fill='#000000', font=field_font)
        draw.text((x4+140, y), dtype, fill='#666666', font=field_font)
        draw.text((x4+210, y), desc, fill='#999999', font=field_font)
    
    # === 面试记录详情 ===
    x5, y5 = 450, 400
    draw_rounded_rect(draw, (x5, y5, x5+350, y5+280), 10, fill='#E0F7FA', outline='#00695C', width=2)
    draw.text((x5+80, y5+10), "面试记录结构", fill='#004D40', font=header_font)
    draw.line([(x5, y5+35), (x5+350, y5+35)], fill='#00695C', width=2)
    
    record_fields = [
        ("job_key", "TEXT", "岗位标识"),
        ("job_name", "TEXT", "岗位名称"),
        ("candidate", "TEXT", "候选人姓名"),
        ("match_score", "REAL", "匹配分数"),
        ("match_percent", "INTEGER", "匹配百分比"),
        ("report_json", "TEXT", "完整报告JSON"),
        ("  ├ nine_scores", "JSON", "九维得分"),
        ("  ├ six_scores", "JSON", "六维得分"),
        ("  ├ risk_analysis", "JSON", "风险分析"),
        ("  ├ text_report", "TEXT", "文本报告"),
        ("  └ multimodal", "JSON", "多模态分析"),
    ]
    for i, (name, dtype, desc) in enumerate(record_fields):
        y = y5 + 45 + i * 22
        draw.text((x5+10, y), name, fill='#000000', font=field_font)
        draw.text((x5+150, y), dtype, fill='#666666', font=field_font)
        draw.text((x5+200, y), desc, fill='#999999', font=field_font)
    
    # === 数据流说明 ===
    x6, y6 = 880, 400
    draw_rounded_rect(draw, (x6, y6, x6+290, y4+150), 10, fill='#FFFDE7', outline='#F9A825', width=2)
    draw.text((x6+70, y6+10), "数据流说明", fill='#F57F17', font=header_font)
    draw.line([(x6, y6+35), (x6+290, y6+35)], fill='#F9A825', width=2)
    
    flow_items = [
        "1. 用户注册/登录",
        "2. 选择/上传JD",
        "3. 上传简历",
        "4. 开始面试",
        "5. 生成评估报告",
        "6. 保存到数据库",
        "7. 导出PDF",
    ]
    for i, item in enumerate(flow_items):
        y = y6 + 45 + i * 22
        draw.text((x6+10, y), item, fill='#000000', font=field_font)
    
    img.save('images/er_diagram.png', quality=95)
    print("ER图已生成: images/er_diagram.png")


def generate_module_diagram():
    """生成模块依赖图"""
    width, height = 1000, 800
    img = Image.new('RGB', (width, height), '#FFFFFF')
    draw = ImageDraw.Draw(img)
    
    title_font = get_font(20)
    label_font = get_font(14)
    small_font = get_font(11)
    
    # 标题
    draw.text((width//2 - 130, 20), "图3.3 模块依赖关系图", fill='#000000', font=title_font)
    
    # 中心：FastAPI主入口
    cx, cy = 500, 400
    draw_rounded_rect(draw, (cx-100, cy-40, cx+100, cy+40), 10, fill='#1565C0', outline='#0D47A1', width=3)
    draw.text((cx-60, cy-12), "FastAPI", fill='#FFFFFF', font=label_font)
    draw.text((cx-55, cy+8), "app/main.py", fill='#BBDEFB', font=small_font)
    
    # 左侧模块
    left_modules = [
        ("JD解析", "app/jd.py", "#E65100", 150, 200),
        ("简历处理", "app/resume/", "#2E7D32", 150, 350),
        ("面试引擎", "app/interview/", "#6A1B9A", 150, 500),
    ]
    
    for name, path, color, x, y in left_modules:
        draw_rounded_rect(draw, (x, y, x+180, y+50), 8, fill=color, outline=color)
        draw.text((x+20, y+8), name, fill='#FFFFFF', font=label_font)
        draw.text((x+20, y+28), path, fill='#FFFFFF', font=small_font)
        draw_arrow(draw, (x+180, y+25), (cx-100, cy), '#333333', 2)
    
    # 右侧模块
    right_modules = [
        ("九维评估", "app/competency/", "#E65100", 670, 200),
        ("报告生成", "app/report/", "#2E7D32", 670, 350),
        ("历史存储", "app/storage.py", "#6A1B9A", 670, 500),
    ]
    
    for name, path, color, x, y in right_modules:
        draw_rounded_rect(draw, (x, y, x+180, y+50), 8, fill=color, outline=color)
        draw.text((x+20, y+8), name, fill='#FFFFFF', font=label_font)
        draw.text((x+20, y+28), path, fill='#FFFFFF', font=small_font)
        draw_arrow(draw, (cx+100, cy), (x, y+25), '#333333', 2)
    
    # 上方模块
    top_modules = [
        ("LLM抽象层", "app/llm/", "#AD1457", 300, 100),
        ("TTS语音合成", "app/tts.py", "#00695C", 550, 100),
    ]
    
    for name, path, color, x, y in top_modules:
        draw_rounded_rect(draw, (x, y, x+160, y+50), 8, fill=color, outline=color)
        draw.text((x+15, y+8), name, fill='#FFFFFF', font=label_font)
        draw.text((x+15, y+28), path, fill='#FFFFFF', font=small_font)
        draw_arrow(draw, (x+80, y+50), (cx, cy-40), '#333333', 2)
    
    # 下方：前端
    draw_rounded_rect(draw, (250, 650, 750, 720), 10, fill='#37474F', outline='#263238', width=2)
    draw.text((370, 660), "前端 (HTML/CSS/JavaScript)", fill='#FFFFFF', font=label_font)
    draw.text((330, 685), "static/ | three.js | Web Speech API", fill='#B0BEC5', font=small_font)
    draw_arrow(draw, (cx, cy+40), (500, 650), '#333333', 2)
    
    img.save('images/module_diagram.png', quality=95)
    print("模块依赖图已生成: images/module_diagram.png")


if __name__ == "__main__":
    os.makedirs('images', exist_ok=True)
    generate_architecture_diagram()
    generate_er_diagram()
    generate_module_diagram()
    print("\n所有图片已生成完成！")