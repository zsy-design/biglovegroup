"""语音合成 (TTS) 模块 - 多提供商支持。

为 AI 虚拟面试官提供语音播报。
支持的TTS提供商:
1. Edge TTS (推荐) - 微软免费语音，中文效果好，无需Key
2. 讯飞星火 TTS - 需要配置Key，音质更专业
3. 浏览器 Web Speech - 最终降级方案
"""
from __future__ import annotations

import base64
import datetime
import hashlib
import hmac
import json
import urllib.parse
import threading
from typing import Optional

from .config import settings


# Edge TTS 音色映射
EDGE_VOICE_MAP = {
    "x4_yezi": "zh-CN-XiaoxiaoNeural",      # 晓晓 - 温柔女声
    "x4_xiaomei": "zh-CN-XiaoyiNeural",     # 晓依 - 活力女声
    "x4_xiaofeng": "zh-CN-YunjianNeural",   # 云健 - 稳重男声
    "x4_chaozhuo": "zh-CN-YunxiNeural",     # 云希 - 阳光男声
    # 更多Edge TTS音色
    "xiaoxiao": "zh-CN-XiaoxiaoNeural",     # 晓晓
    "xiaoyi": "zh-CN-XiaoyiNeural",         # 晓依
    "yunjian": "zh-CN-YunjianNeural",       # 云健
    "yunxi": "zh-CN-YunxiNeural",           # 云希
    "yunxia": "zh-CN-YunxiaNeural",         # 云夏
    "yunyang": "zh-CN-YunyangNeural",       # 云扬 - 新闻播报
}


def _get_credentials() -> tuple:
    """获取讯飞API凭证"""
    app_id = settings.SPARK_APP_ID
    api_key = settings.SPARK_API_KEY
    api_secret = settings.SPARK_API_SECRET
    if api_key and api_secret:
        return app_id, api_key, api_secret
    try:
        from .llm.store import load_config
        store = load_config()
        return (
            store.get("app_id") or app_id,
            store.get("api_key") or api_key,
            store.get("api_secret") or api_secret,
        )
    except Exception:
        return app_id, api_key, api_secret


def tts_available() -> bool:
    """检查TTS是否可用"""
    # 如果配置使用edge，总是可用
    if settings.TTS_PROVIDER == "edge":
        return True
    if settings.llm_enabled:
        return True
    _, api_key, api_secret = _get_credentials()
    return bool(api_key and api_secret)


def _create_ws_url(api_key: str, api_secret: str) -> str:
    """创建讯飞TTS WebSocket URL"""
    host = "tts-api.xfyun.cn"
    path = "/v2/tts"
    url = f"wss://{host}{path}"
    now = datetime.datetime.now()
    date = now.strftime("%a, %d %b %Y %H:%M:%S GMT")
    signature_origin = f"host: {host}\ndate: {date}\nGET {path} HTTP/1.1"
    signature_sha = hmac.new(
        api_secret.encode("utf-8"),
        signature_origin.encode("utf-8"),
        digestmod=hashlib.sha256
    ).digest()
    signature = base64.b64encode(signature_sha).decode("utf-8")
    authorization_origin = (
        f'api_key="{api_key}", algorithm="hmac-sha256", '
        f'headers="host date request-line", signature="{signature}"'
    )
    authorization = base64.b64encode(authorization_origin.encode("utf-8")).decode("utf-8")
    v = urllib.parse.urlencode({"authorization": authorization, "date": date, "host": host})
    return f"{url}?{v}"


async def _synthesize_edge_async(text: str, voice: str = "x4_yezi") -> Optional[bytes]:
    """Edge TTS 异步合成（免费、无需 Key）"""
    try:
        import edge_tts
    except ImportError:
        print("[TTS] 请安装 edge_tts: pip install edge-tts")
        return None
    
    # 获取音色
    vcn = EDGE_VOICE_MAP.get(voice, settings.EDGE_TTS_VOICE)
    
    try:
        communicate = edge_tts.Communicate(text, vcn)
        audio_chunks = []
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                audio_chunks.append(chunk["data"])
        if audio_chunks:
            return b"".join(audio_chunks)
    except Exception as e:
        print(f"[TTS] Edge TTS 错误: {e}")
    return None


def _run_async_in_thread(coro):
    """在新线程中运行异步协程，避免事件循环冲突"""
    result = [None]
    exception = [None]
    
    def target():
        try:
            # 创建新的事件循环
            import asyncio
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                result[0] = loop.run_until_complete(coro)
            finally:
                loop.close()
        except Exception as e:
            exception[0] = e
    
    thread = threading.Thread(target=target)
    thread.start()
    thread.join(timeout=30)  # 30秒超时
    
    if exception[0]:
        print(f"[TTS] 异步执行错误: {exception[0]}")
        return None
    return result[0]


def _synthesize_edge_sync(text: str, voice: str = "x4_yezi") -> Optional[bytes]:
    """Edge TTS 同步封装（线程安全）"""
    try:
        return _run_async_in_thread(_synthesize_edge_async(text, voice))
    except Exception as e:
        print(f"[TTS] Edge TTS 同步调用失败: {e}")
        return None


def _synthesize_xfyun(text: str, voice: str = "x4_yezi") -> Optional[bytes]:
    """讯飞星火 TTS 合成"""
    app_id, api_key, api_secret = _get_credentials()
    if not (api_key and api_secret):
        return None
    
    valid_voices = {"x4_yezi", "x4_xiaomei", "x4_xiaofeng", "x4_chaozhuo"}
    vcn = voice if voice in valid_voices else settings.TTS_VOICE
    ws_url = _create_ws_url(api_key, api_secret)
    
    try:
        import websocket
    except ImportError:
        print("[TTS] 请安装 websocket-client: pip install websocket-client")
        return None
    
    audio_chunks = []
    error_holder = [None]
    
    def on_message(ws, message):
        try:
            data = json.loads(message)
            code = data.get("code", -1)
            if code != 0:
                error_holder[0] = f"code={code}: {data.get('message')}"
                ws.close()
                return
            audio_data = data.get("data", {}).get("audio", "")
            status = data.get("data", {}).get("status", 2)
            if audio_data:
                audio_chunks.append(base64.b64decode(audio_data))
            if status == 2:
                ws.close()
        except Exception as e:
            error_holder[0] = str(e)
            ws.close()
    
    def on_error(ws, error):
        error_holder[0] = str(error)
    
    def on_close(ws, code, msg):
        pass
    
    def on_open(ws):
        payload = {
            "common": {"app_id": app_id},
            "business": {
                "aue": "lame",
                "vcn": vcn,
                "speed": settings.TTS_SPEED,
                "volume": settings.TTS_VOLUME,
                "pitch": 50,
            },
            "data": {
                "status": 2,
                "text": base64.b64encode(text.encode("utf-8")).decode("utf-8"),
            },
        }
        ws.send(json.dumps(payload))
    
    try:
        ws = websocket.WebSocketApp(
            ws_url,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close,
            on_open=on_open,
        )
        ws.run_forever(ping_timeout=30)
    except Exception as e:
        print(f"[TTS] 讯飞TTS异常: {e}")
        return None
    
    if error_holder[0]:
        print(f"[TTS] 讯飞TTS错误: {error_holder[0]}")
    
    return b"".join(audio_chunks) if audio_chunks else None


def synthesize(text: str, voice: str = "x4_yezi") -> Optional[bytes]:
    """语音合成入口函数。
    
    合成优先级（可通过TTS_PROVIDER配置）:
    1. 如果TTS_PROVIDER=edge: 直接使用Edge TTS（推荐，免费稳定）
    2. 如果TTS_PROVIDER=xfyun: 使用讯飞星火TTS（需要Key）
    3. 自动降级: 讯飞 > Edge > None（前端降级浏览器Web Speech）
    
    Args:
        text: 要合成的文本
        voice: 音色选择
    
    Returns:
        MP3音频数据，失败返回None（前端会降级使用浏览器Web Speech）
    """
    if not text.strip():
        return None
    
    provider = settings.TTS_PROVIDER
    
    # 如果明确指定使用Edge TTS
    if provider == "edge":
        result = _synthesize_edge_sync(text, voice)
        if result:
            return result
        print("[TTS] Edge TTS失败，尝试其他方式")
    
    # 如果明确指定使用讯飞TTS
    if provider == "xfyun":
        result = _synthesize_xfyun(text, voice)
        if result:
            return result
        print("[TTS] 讯飞TTS失败，尝试Edge TTS")
        # 讯飞失败时降级到Edge
        return _synthesize_edge_sync(text, voice)
    
    # 自动模式：讯飞 > Edge
    if tts_available():
        app_id, api_key, api_secret = _get_credentials()
        if api_key and api_secret:
            result = _synthesize_xfyun(text, voice)
            if result:
                return result
    
    # 降级到Edge TTS
    return _synthesize_edge_sync(text, voice)


def get_available_voices() -> dict:
    """获取可用的音色列表"""
    voices = {
        "edge": {
            "x4_yezi": "晓晓 - 温柔女声（推荐）",
            "x4_xiaomei": "晓依 - 活力女声",
            "x4_xiaofeng": "云健 - 稳重男声",
            "x4_chaozhuo": "云希 - 阳光男声",
        },
        "xfyun": {
            "x4_yezi": "叶子 - 温柔女声",
            "x4_xiaomei": "小美 - 活力女声",
            "x4_xiaofeng": "小峰 - 稳重男声",
            "x4_chaozhuo": "小卓 - 阳光男声",
        }
    }
    return voices