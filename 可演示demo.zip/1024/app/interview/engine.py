"""多轮情景化面试引擎。

职责:
  1. 依据岗位胜任力模型 + 候选人画像生成个性化面试计划;
  2. 逐题发问, 依据回答质量与岗位模型进行"追问/换题/收尾"的智能决策;
  3. 全程记录作答, 为评估报告提供结构化证据。

确定性逻辑(题库+追问规则)与 LLM(可选)结合:
  无 Key 时走本地规则, 有 Key 时用星火生成更自然的问题与追问。
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

from ..competency.model import COMPETENCY_DIMENSIONS, Question, get_job_model
from ..config import settings
from ..llm import BaseLLM, Message, ensure_llm
from ..resume.parser import parse_resume_text

END_HINTS = ("结束", "面试结束", "就这样", "没有问题", "没有了", "退出")


def _build_system(task: str, **kwargs) -> str:
    """组装带任务标记的 system prompt, 便于 MockLLM/星火识别任务"""
    parts = [task, f"岗位: {kwargs.get('job_name', '')}",
             f"考察维度: {kwargs.get('dimension', '')}"]
    extra = kwargs.get("extra", "")
    if extra:
        parts.append(extra)
    return "\n".join(parts)


class InterviewSession:
    """一场面试的会话状态机"""

    def __init__(
        self,
        job_key: Optional[str] = None,
        job: Optional[JobModel] = None,
        profile: Optional[dict] = None,
        llm: Optional[BaseLLM] = None,
        max_rounds: Optional[int] = None,
    ) -> None:
        if job is None:
            if job_key is None:
                raise ValueError("必须提供 job_key 或 job 岗位模型")
            job = get_job_model(job_key)
        self.job: JobModel = job
        self.profile = profile or {}
        self.llm = llm or ensure_llm()
        self.max_rounds = max_rounds or settings.MAX_INTERVIEW_ROUNDS
        self.question_plan: List[Question] = self._build_plan()
        self.transcript: List[dict] = []          # {role, text, dimension}
        self.answer_records: List[dict] = []      # {question, answer, score, dimension, metrics, eval}
        self._last_eval: Optional[dict] = None    # 上一题实时评估(参考程序: 逐题实时评估反馈)
        self._qidx = 0
        self._followup_idx = 0
        self._asked_questions = 0
        self._started_questions = False
        self.finished = False
        self.closing_msg = ""

    # ------------------------------------------------------------------
    # 面试计划
    # ------------------------------------------------------------------
    def _build_plan(self) -> List[Question]:
        """按岗位权重排序维度, 选取题目; 简历命中关键词的题目优先。"""
        ranked_dims = sorted(
            COMPETENCY_DIMENSIONS,
            key=lambda d: self.job.weight(d),
            reverse=True,
        )
        plan: List[Question] = []
        used_dims: set = set()
        # 第一遍: 按权重覆盖尽量多维度
        for dim in ranked_dims:
            if len(plan) >= self.max_rounds:
                break
            pool = self.job.questions_by_dim(dim)
            if not pool:
                continue
            q = self._pick(pool, dim)
            plan.append(q)
            used_dims.add(dim)
        # 第二遍: 补充题库富余题目
        for q in self.job.questions:
            if len(plan) >= self.max_rounds:
                break
            if q in plan:
                continue
            plan.append(q)
        return plan

    def _pick(self, pool: List[Question], dim: str) -> Question:
        """简历中出现的技能/项目相关题目优先, 体现个性化"""
        resume_text = (self.profile.get("raw") or "") + " ".join(
            self.profile.get("skills", [])
        )
        for q in pool:
            if any(k.lower() in resume_text.lower() for k in q.keywords):
                return q
        return pool[0]

    # ------------------------------------------------------------------
    # 开场
    # ------------------------------------------------------------------
    def start(self) -> dict:
        name = self.profile.get("name") or "同学"
        welcome = (
            f"你好，{name}！我是本次面试官，针对「{self.job.name}」岗位进行胜任力评估。"
            f"我已阅读你的简历，下面进行多轮情景化问答，结束后会自动生成评估报告。\n\n"
            f"请先简要介绍一下你自己，重点说说与{self.job.name}相关的经历。"
        )
        self.transcript.append({"role": "assistant", "text": welcome, "dimension": "开场"})
        return {"type": "intro", "content": welcome, "round": 1, "finished": False}

    # ------------------------------------------------------------------
    # 对话回合
    # ------------------------------------------------------------------
    def respond(self, user_text: str, metrics: Optional[dict] = None) -> dict:
        user_text = (user_text or "").strip()
        if self.finished:
            return {"type": "end", "content": self.closing_msg, "finished": True}

        # 结束信号
        if any(h in user_text for h in END_HINTS) and len(user_text) <= 6:
            return self._finish()

        self.transcript.append({
            "role": "user",
            "text": user_text,
            "dimension": self._current_dimension(),
        })

        # 阶段 A: 自我介绍后开始正式出题
        if not self._started_questions:
            self._started_questions = True
            return self._ask_question(self.question_plan[0])

        # 阶段 B: 处于某道题 -> 记录作答并决策
        question = self.question_plan[self._qidx]
        score = self._score_answer(user_text, question)
        self._last_eval = self._eval_comment(score, question.dimension)
        self.answer_records.append({
            "question": question.text,
            "dimension": question.dimension,
            "answer": user_text,
            "score": score,
            "metrics": metrics or {},
            "eval": self._last_eval,
        })

        # B1. 回答过短 -> 追问展开
        if len(user_text) < settings.MIN_ANSWER_LEN:
            content = "回答得比较简短，能具体展开一下吗？比如当时的情景、你采取了什么做法、结果如何。"
            return self._reply(content, qtype="followup", question=question)

        # B2. 还有预设追问 -> 继续深挖
        followups = question.followups or []
        if self._followup_idx < len(followups):
            template = followups[self._followup_idx]
            self._followup_idx += 1
            content = self._paraphrase(template, question, user_text)
            return self._reply(content, qtype="followup", question=question)

        # B3. 进入下一题
        self._qidx += 1
        self._followup_idx = 0
        if self._qidx >= len(self.question_plan):
            return self._finish()
        return self._ask_question(self.question_plan[self._qidx])

    def _current_dimension(self) -> str:
        if self._started_questions and self._qidx < len(self.question_plan):
            return self.question_plan[self._qidx].dimension
        return "开场"

    def _ask_question(self, question: Question) -> dict:
        self._asked_questions += 1
        content = f"【第 {self._asked_questions} 题 · {question.dimension}】\n{question.text}"
        self.transcript.append({"role": "assistant", "text": content, "dimension": question.dimension})
        out = {
            "type": "question",
            "content": content,
            "dimension": question.dimension,
            "round": self._asked_questions,
            "finished": False,
        }
        if self._last_eval:
            out["eval"] = self._last_eval
            self._last_eval = None
        return out

    def _reply(self, content: str, qtype: str, question: Question) -> dict:
        self.transcript.append({"role": "assistant", "text": content, "dimension": question.dimension})
        out = {
            "type": qtype,
            "content": content,
            "dimension": question.dimension,
            "round": self._asked_questions,
            "finished": False,
        }
        if self._last_eval:
            out["eval"] = self._last_eval
            self._last_eval = None
        return out

    # ------------------------------------------------------------------
    # 追问生成: 题库模板 -> LLM 自然化改写(可选)
    # ------------------------------------------------------------------
    def _paraphrase(self, template: str, question: Question, last_answer: str) -> str:
        """先给模板追问, LLM 可用时再做口语化改写; 失败回退模板"""
        try:
            messages = [
                Message("system", _build_system(
                    "【追问】",
                    job_name=self.job.name,
                    dimension=question.dimension,
                    extra=f"预设追问: {template}\n要求: 口语化、自然、有追问感, 只问一个问题, 不要重复原题。",
                )),
                Message("user", f"候选人的回答是: {last_answer}"),
            ]
            result = self.llm.chat(messages, temperature=0.7, max_tokens=120)
            content = result.content.strip()
            if content and content != last_answer and len(content) < 200:
                return content
        except Exception:  # noqa: BLE001 - LLM 失败时回退模板
            pass
        return template

    # ------------------------------------------------------------------
    # 作答打分(启发式, 供报告使用)
    # ------------------------------------------------------------------
    @staticmethod
    def _score_answer(answer: str, question: Question) -> float:
        text = answer.strip()
        score = 0.0
        if len(text) >= 20:
            score += 1.5
        if len(text) >= 60:
            score += 1.0
        if len(text) >= 120:
            score += 0.5
        if any(k in ("首先", "然后", "其次", "第一", "第二", "最后", "一、", "二、") for k in text):
            score += 0.8
        if re.search(r"\d+%|\d+人|\d+万|\d+次|\d+天|\d+倍", text):
            score += 0.8
        if any("我" + w in text for w in ("负责", "主导", "独立", "牵头", "完成", "设计")):
            score += 0.7
        if any(k.lower() in text.lower() for k in question.keywords):
            score += 0.7
        return round(min(5.0, score), 1)

    # ------------------------------------------------------------------
    # 逐题实时评估(参考程序: 每题给即时反馈)
    # ------------------------------------------------------------------
    @staticmethod
    def _eval_comment(score: float, dimension: str) -> dict:
        if score >= 4.0:
            level = "优秀"
            comment = "结构完整、有量化结果，对「" + dimension + "」把握很好"
        elif score >= 3.0:
            level = "良好"
            comment = "回答较具体，建议补充个人角色与量化成果，会更扎实"
        elif score >= 2.0:
            level = "一般"
            comment = "回答偏概念化，缺少细节与证据，建议结合项目实例展开"
        else:
            level = "较弱"
            comment = "作答较简短，深度不足，建议按 STAR 法则补充过程与结果"
        return {"score": score, "dimension": dimension, "level": level, "comment": comment}

    # 多模态数据汇总(语音/行为指标)
    def multimodal_summary(self) -> dict:
        metrics = [r.get("metrics") or {} for r in self.answer_records]
        vals = lambda k: [m[k] for m in metrics if m.get(k) not in (None, "", 0)]
        avg = lambda a: round(sum(a) / len(a), 1) if a else 0
        speech_rate = vals("speech_rate")
        pauses = vals("pause_count")
        durations = vals("duration_ms")
        return {
            "answers": len(self.answer_records),
            "avg_speech_rate": avg(speech_rate),
            "avg_pause_count": avg(pauses),
            "avg_duration_ms": avg(durations),
            "samples": [
                {"dimension": r["dimension"], "score": r["score"], "metrics": r.get("metrics") or {}}
                for r in self.answer_records
            ],
        }

    # ------------------------------------------------------------------
    # 收尾
    # ------------------------------------------------------------------
    def _finish(self) -> dict:
        self.finished = True
        self.closing_msg = (
            "面试到此结束，感谢你的配合！我正在根据本场多轮问答生成绩效评估报告，请稍候……"
        )
        self.transcript.append({"role": "assistant", "text": self.closing_msg, "dimension": "收尾"})
        return {"type": "end", "content": self.closing_msg, "finished": True}

    def to_dict(self) -> dict:
        return {
            "job_key": self.job.key,
            "job_name": self.job.name,
            "profile": self.profile,
            "transcript": self.transcript,
            "answer_records": self.answer_records,
            "per_question_eval": [
                {"dimension": r["dimension"], "score": r["score"], "eval": r.get("eval")}
                for r in self.answer_records
            ],
            "multimodal": self.multimodal_summary(),
            "finished": self.finished,
        }


def create_session(job_key: str, resume_text: str, llm=None) -> InterviewSession:
    profile = parse_resume_text(resume_text)
    return InterviewSession(job_key=job_key, profile=profile, llm=llm)


def create_session_with_job(job: JobModel, resume_text: str, llm=None) -> InterviewSession:
    """基于动态岗位模型（如 JD 解析结果）创建面试会话。"""
    from ..competency.model import JobModel as _JM
    profile = parse_resume_text(resume_text)
    return InterviewSession(job=job, profile=profile, llm=llm)
