"""大模型接口抽象。

所有接入的大模型(星火/其他)实现 `chat` 即可，业务层与具体厂商解耦。
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional

from ..config import settings


class LLMError(Exception):
    """大模型调用异常"""


@dataclass
class Message:
    role: str  # "system" | "user" | "assistant"
    content: str


@dataclass
class ChatResult:
    content: str = ""
    reasoning: str = ""
    raw: Optional[dict] = None


class BaseLLM(ABC):
    """大模型统一接口"""

    @abstractmethod
    def chat(
        self,
        messages: List[Message],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> ChatResult:
        """非流式对话，返回完整文本"""


def ensure_llm(force: bool = False) -> BaseLLM:
    """按配置返回可用的 LLM 实例。
    
    优先使用配置的大模型，未配置时返回MockLLM保证离线可演示。
    """
    from .openai_compat import OpenAICompatLLM
    
    # 优先检查讯飞星火配置
    if settings.SPARK_API_KEY and settings.SPARK_API_SECRET:
        try:
            from .spark import SparkLLM
            return SparkLLM()
        except Exception:
            pass
    
    # 检查OpenAI兼容接口配置
    if settings.LLM_API_KEY and settings.LLM_BASE_URL:
        try:
            return OpenAICompatLLM(
                api_key=settings.LLM_API_KEY,
                base_url=settings.LLM_BASE_URL,
                model=settings.LLM_MODEL,
                temperature=settings.LLM_TEMPERATURE,
                max_tokens=settings.LLM_MAX_TOKENS,
            )
        except Exception:
            pass
    
    if force:
        raise LLMError("未配置大模型，请在 config.py 或环境变量中设置 LLM_API_KEY")
    
    from .mock import MockLLM
    return MockLLM()
