"""大模型运行时配置存储 —— JSON 文件持久化, 支持界面/API 在线修改。

保存路径: data/llm_config.json (BASE_DIR/data, 与历史库同目录)。
支持两套配置:
- OpenAI 兼容接口: base_url / api_key / model
- 讯飞星火: app_id / api_key / api_secret / base_url / model
"""
import json
import threading
from pathlib import Path

from ..config import BASE_DIR

_PATH = BASE_DIR / "data" / "llm_config.json"
_LOCK = threading.Lock()
_FIELDS = ("base_url", "api_key", "model", "app_id", "api_secret")


def load_config() -> dict:
    with _LOCK:
        try:
            data = json.loads(_PATH.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return {}
    return {k: str(data.get(k) or "") for k in _FIELDS}


def save_config(cfg: dict) -> dict:
    clean = {k: str(cfg.get(k) or "").strip() for k in _FIELDS}
    _PATH.parent.mkdir(parents=True, exist_ok=True)
    with _LOCK:
        _PATH.write_text(json.dumps(clean, ensure_ascii=False, indent=2), encoding="utf-8")
    return clean


def masked_config(cfg: dict) -> dict:
    """脱敏后的配置(前端展示用, 不回传明文密钥)。"""
    key = cfg.get("api_key") or ""
    secret = cfg.get("api_secret") or ""
    return {
        "base_url": cfg.get("base_url") or "",
        "model": cfg.get("model") or "",
        "app_id": cfg.get("app_id") or "",
        "api_key_set": bool(key),
        "api_key_hint": (key[:4] + "****" + key[-4:]) if len(key) > 8 else ("****" if key else ""),
        "api_secret_set": bool(secret),
    }


__all__ = ["load_config", "save_config", "masked_config"]
