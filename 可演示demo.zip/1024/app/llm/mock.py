"""本地规则引擎 —— 离线兜底实现。

未配置讯飞星火 Key 时，用启发式规则模拟面试官与大模型，
保证整个 Demo 无网络、无 Key 也能端到端跑通。
规则与业务层的确定性逻辑保持一致（同为"数据来源"），
接入真实大模型后由 LLM 输出更自然、更个性化的内容。
"""
import json
import re

from .base import BaseLLM, ChatResult, Message

FOLLOWUP_PATTERNS = [
    (
        re.compile(r"关于|技术方案|实现|架构|设计"),
        "你提到了这方面的具体做法，能再展开讲讲当时是怎么做技术选型的、踩过哪些坑吗？",
    ),
    (
        re.compile(r"负责|参与了|完成"),
        "听起来这段经历主要靠团队协作完成，你能说清楚你在其中的具体分工和个人贡献吗？",
    ),
    (
        re.compile(r"学习|掌握|了解"),
        "很好。那如果让你现在独立负责一个相关模块，从 0 到 1 落地，你的实施步骤是怎样的？",
    ),
]

CLOSING_TIPS = [
    "结合岗位 JD 突出你最有竞争力的 1-2 个亮点，用数据说话会更有说服力。",
    "面试前复盘一遍最近项目的技术细节，追问往往是考察真伪与深度。",
    "回答问题时先给结论再给理由，逻辑清晰比面面俱到更重要。",
    "提前准备两三个向面试官反问的问题，体现你的主动性。",
]


class MockLLM(BaseLLM):
    """启发式规则 LLM，识别【追问】/【评估】/【报告】三类任务"""

    def chat(self, messages, temperature=None, max_tokens=None) -> ChatResult:
        if not messages:
            return ChatResult(content="")

        system = next((m.content for m in messages if m.role == "system"), "")
        user = next((m.content for m in messages if m.role == "user"), "")
        last_user = user

        if "【追问】" in system:
            return ChatResult(content=self._followup(last_user, system))
        if "【评估】" in system:
            return ChatResult(content=self._evaluate(last_user))
        if "【报告】" in system:
            return ChatResult(content=self._report(last_user))
        if "【助手】" in system:
            return ChatResult(content=self._assistant(last_user))
        # 通用兜底
        return ChatResult(content=last_user)

    # ---- AI 助手(离线演示兜底) ----
    @staticmethod
    def _assistant(question: str) -> str:
        q = question.strip()
        keyword = q[:40] + ("…" if len(q) > 40 else "")
        return (
            "【离线演示模式】当前未接入真实大模型，以下为规则引擎生成的通用建议。\n\n"
            f"关于你的问题「{keyword}」：\n"
            "1. 建议先明确目标：这个问题是为了求职决策、技术提升还是面试准备？目标不同，答案的侧重也不同。\n"
            "2. 求职类问题可回到「智能面试」用目标岗位 JD 跑一场模拟面试，用评估报告定位差距。\n"
            "3. 技术类问题建议结合官方文档与一个可动手的小实验验证，比只看结论记得更牢。\n\n"
            "接入真实大模型方法：点击右上角「模型设置」，填入任意 OpenAI 兼容服务"
            "（如 DeepSeek / Kimi / 通义 / GLM / 本地 Ollama 的 base_url、api_key、模型名），"
            "保存后本助手与智能面试都会切换为真实大模型回答。"
        )

    # ---- 追问 ----
    @staticmethod
    def _followup(answer: str, system: str = "") -> str:
        """优先返回题库预设追问(已按岗位/维度设计好), 保证质量与确定性"""
        m = re.search(r"预设追问[:：]\s*([^\n]+)", system)
        if m and m.group(1).strip():
            return m.group(1).strip()
        answer = answer.strip()
        if len(answer) < 8:
            return "你刚才的回答比较简短，能再具体一些吗？比如当时的情景、你做了什么、结果如何。"
        for pat, q in FOLLOWUP_PATTERNS:
            if pat.search(answer):
                return q
        return "回答得不错。结合这个场景再深入一层：如果条件受限、资源不足，你会如何保证落地效果？"

    # ---- 评估 ----
    @staticmethod
    def _evaluate(answer: str) -> str:
        text = answer.strip()
        length = len(text)
        has_structure = any(k in text for k in ("首先", "然后", "其次", "第一", "第二", "最后"))
        has_data = bool(re.search(r"\d+%|\d+人|\d+万|\d+次|\d+天", text))
        has_role = any(k in text for k in ("我负责", "我主导", "我独立", "本人", "牵头"))
        depth = 0.3
        if length >= 30:
            depth += 0.2
        if length >= 80:
            depth += 0.2
        if has_structure:
            depth += 0.1
        if has_data:
            depth += 0.1
        if has_role:
            depth += 0.1
        return json.dumps(
            {
                "score": round(min(5, depth * 5), 1),
                "evidence": [],
                "strengths": "表达较完整、有逻辑分层" if has_structure else "有一定信息量",
                "weaknesses": "缺少量化数据支撑" if not has_data else "可进一步突出个人角色",
            },
            ensure_ascii=False,
        )

    # ---- 报告 ----
    @staticmethod
    def _report(user: str) -> str:
        try:
            data = json.loads(user)
        except json.JSONDecodeError:
            return json.dumps(
                {
                    "summary": "候选人总体表现中等偏上，具备岗位所需基础能力。",
                    "strengths": ["学习能力强，知识面较广", "回答问题有基本的条理性"],
                    "weaknesses": ["项目经验深度不足，缺乏量化成果支撑", "部分回答停留在概念层面"],
                    "suggestions": ["补充一两个有数据支撑的项目实践", "提前准备岗位相关的高频面试题"],
                },
                ensure_ascii=False,
            )
        dims = data.get("dimensions", {})
        overall = round(float(data.get("overall", 0) or 0) or (
            sum(dims.values()) / max(len(dims), 1)), 1)
        strong = sorted(dims.items(), key=lambda kv: kv[1], reverse=True)[:2]
        weak = sorted(dims.items(), key=lambda kv: kv[1])[:2]
        if overall >= 4.0:
            level = "高度匹配"
        elif overall >= 3.0:
            level = "比较匹配"
        elif overall >= 2.0:
            level = "基本匹配，但需针对性加强"
        else:
            level = "存在明显差距，建议结合岗位要求强化训练"
        return json.dumps(
            {
                "summary": f"候选人对目标岗位{level}，整体胜任力得分 {overall}/5.0。",
                "strengths": [f"{k}维度表现较好（得分 {v:.1f}）" for k, v in strong if v >= 2.5]
                + ["回答问题具备基本的逻辑性与条理"],
                "weaknesses": [f"{k}维度得分偏低（{v:.1f}）" for k, v in weak if v < 3.0]
                + ["回答中量化数据与个人贡献的刻画不足，深度有待提升"],
                "suggestions": [f"针对「{k}」维度进行专项训练与项目沉淀" for k, _ in weak]
                + ["用 STAR 法则整理项目经历，突出个人角色与量化成果"],
            },
            ensure_ascii=False,
        )


__all__ = ["MockLLM"]
