"""OpenAI 兼容接口实现 —— 支持任意兼容大模型服务。

适用于 DeepSeek / Moonshot(Kimi) / 阿里通义(兼容模式) / 智谱GLM /
本地 Ollama / vLLM 等所有提供 OpenAI `/v1/chat/completions` 协议的服务。

配置优先级: 运行时配置(界面/API 写入, 见 store.py) > 环境变量。
环境变量:
    LLM_BASE_URL  例: https://api.deepseek.com/v1
    LLM_API_KEY   部分本地服务(如 Ollama)可留空
    LLM_MODEL     例: deepseek-chat
"""
import json
from typing import Iterator, List, Optional

import requests

from .base import BaseLLM, ChatResult, LLMError, Message

_TIMEOUT = 180


class OpenAICompatLLM(BaseLLM):
    """任意 OpenAI 兼容 /chat/completions 服务"""

    def __init__(self, base_url: str, api_key: str = "", model: str = "") -> None:
        self.base_url = (base_url or "").rstrip("/")
        self.api_key = (api_key or "").strip()
        self.model = (model or "").strip()
        if not self.base_url or not self.model:
            raise LLMError("OpenAI 兼容接口需要 base_url 与 model")

    @property
    def endpoint(self) -> str:
        return f"{self.base_url}/chat/completions"

    def _headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    @staticmethod
    def _payload(messages: List[Message], temperature: Optional[float], max_tokens: Optional[int], stream: bool) -> dict:
        payload = {
            "model": "",
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": temperature if temperature is not None else 0.6,
            "stream": stream,
        }
        return payload

    def chat(self, messages, temperature=None, max_tokens=None) -> ChatResult:
        payload = self._payload(messages, temperature, max_tokens, stream=False)
        payload["model"] = self.model
        if max_tokens:
            payload["max_tokens"] = max_tokens
        try:
            resp = requests.post(
                self.endpoint, headers=self._headers(), json=payload, timeout=_TIMEOUT
            )
        except Exception as exc:  # noqa: BLE001
            raise LLMError(f"大模型请求失败: {exc}") from exc
        if resp.status_code != 200:
            raise LLMError(f"大模型返回 {resp.status_code}: {resp.text[:200]}")
        try:
            data = resp.json()
            content = data["choices"][0]["message"].get("content") or ""
        except Exception as exc:  # noqa: BLE001
            raise LLMError(f"大模型响应解析失败: {exc}") from exc
        return ChatResult(content=content.strip())

    def chat_stream(self, messages, temperature=None, max_tokens=None) -> Iterator[str]:
        """流式对话, 逐段 yield 文本增量; 失败抛 LLMError。"""
        payload = self._payload(messages, temperature, max_tokens, stream=True)
        payload["model"] = self.model
        if max_tokens:
            payload["max_tokens"] = max_tokens
        try:
            resp = requests.post(
                self.endpoint,
                headers={**self._headers(), "Accept": "text/event-stream"},
                json=payload,
                timeout=_TIMEOUT,
                stream=True,
            )
        except Exception as exc:  # noqa: BLE001
            raise LLMError(f"大模型请求失败: {exc}") from exc
        if resp.status_code != 200:
            raise LLMError(f"大模型返回 {resp.status_code}: {resp.text[:200]}")
        try:
            for line in resp.iter_lines(decode_unicode=True):
                if not line or not str(line).startswith("data:"):
                    continue
                data = str(line)[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    obj = json.loads(data)
                except json.JSONDecodeError:
                    continue
                choices = obj.get("choices") or [{}]
                piece = (choices[0].get("delta") or {}).get("content")
                if piece:
                    yield piece
        except LLMError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise LLMError(f"大模型流式读取中断: {exc}") from exc
        finally:
            resp.close()


def effective_openai_config() -> dict:
    """运行时配置 > 环境变量, 返回 {base_url, api_key, model}。"""
    import os

    from .store import load_config

    cfg = load_config()
    return {
        "base_url": (cfg.get("base_url") or os.getenv("LLM_BASE_URL", "")).strip(),
        "api_key": (cfg.get("api_key") or os.getenv("LLM_API_KEY", "")).strip(),
        "model": (cfg.get("model") or os.getenv("LLM_MODEL", "")).strip(),
    }


__all__ = ["OpenAICompatLLM", "effective_openai_config"]
