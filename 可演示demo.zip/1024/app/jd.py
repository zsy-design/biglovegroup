"""模块1 · 任意岗位 JD 智能解析。

输入任意岗位 JD 文本 -> 自动拆解结构化胜任力模型：
  - 岗位类型识别（关键词命中 7 大内置岗位或自定义）
  - 核心技能 / 学历 / 经验年限 / 职责 / 加分项 抽取
  - 六维考察权重 + 九维评估权重
  - 难度等级评估
  - 生成个性化面试题库（内置岗位题库 or 通用题库兜底）

星火可用时用 LLM 语义提炼；离线时走确定性规则，均输出结构化 JSON。
"""
from __future__ import annotations

import re
from typing import List

from .competency.model import JOB_MAP, JobModel, Question
from .competency.nine import NINE_DIMENSIONS, nine_weights_from_six
from .llm import Message, ensure_llm

# 岗位类型识别规则（优先级从高到低）
TYPE_RULES = [
    ("网络安全工程师", re.compile(r"(网络安全|渗透测试|安全工程师|安全运营|应急响应|web安全|安全攻防)"), "security"),
    ("算法工程师", re.compile(r"(算法|机器学习|深度学习|自然语言|nlp|计算机视觉|cv|推荐系统|大模型|数据挖掘|人工智能)"), "algorithm"),
    ("AI/大模型应用工程师", re.compile(r"(大模型应用|llm应用|rag|agent|提示工程|模型微调|推理服务|vllm|tgi)"), "ai_engineer"),
    ("数据分析师", re.compile(r"(数据分析|商业分析|数仓|数据仓库|bi报表|数据运营|数据可视化|报表)"), "data"),
    ("大数据开发工程师", re.compile(r"(大数据|flink|spark|clickhouse|doris|数仓|实时计算|数据治理|湖仓)"), "bigdata"),
    ("Java开发工程师", re.compile(r"(java|spring|springboot|服务端开发|后端开发|微服务|高并发)"), "java"),
    ("Go开发工程师", re.compile(r"(golang|go语言|gin|gRPC|云原生|k8s|kubernetes)"), "go"),
    ("Python开发工程师", re.compile(r"(python|fastapi|django|flask|异步|数据管道|ai工程化)"), "python"),
    ("前端开发工程师", re.compile(r"(前端|web前端|h5|小程序|vue|react|切图)"), "frontend"),
    ("移动端开发工程师", re.compile(r"(移动端|ios|android|flutter|react native|swift|kotlin|app开发)"), "mobile"),
    ("测试开发工程师", re.compile(r"(测试开发|质量保障|自动化测试|测试工程师|qa|接口测试|性能测试)"), "qa"),
    ("DevOps/运维工程师", re.compile(r"(devops|运维|kubernetes|k8s|ci/cd|jenkins|prometheus|terraform|容器)"), "devops"),
    ("嵌入式软件工程师", re.compile(r"(嵌入式|rtos|freertos|linux驱动|单片机|物联网|iot|can|modbus)"), "embedded"),
    ("全栈工程师", re.compile(r"(全栈|全栈工程师|端到端|monorepo|typescript全栈)"), "fullstack"),
    ("系统架构师", re.compile(r"(架构师|系统架构|技术架构|领域驱动|ddd|分布式架构)"), "architect"),
    ("技术经理/总监", re.compile(r"(技术经理|技术总监|cto|研发管理|团队管理|工程效能)"), "tech_lead"),
    ("产品经理", re.compile(r"(产品经理|产品运营|需求分析|prd|用户调研|产品设计|项目管理)"), "pm"),
]

DEGREE_RULES = [
    (re.compile(r"博士"), "博士"),
    (re.compile(r"硕士|研究生"), "硕士"),
    (re.compile(r"本科"), "本科"),
    (re.compile(r"大专|专科"), "大专"),
]

# 通用六维权重（无匹配岗位时的兜底）
DEFAULT_SIX_WEIGHTS = {
    "专业知识": 0.24, "逻辑思维": 0.20, "解决问题": 0.20,
    "沟通协作": 0.12, "学习能力": 0.14, "职业素养": 0.10,
}

# 通用题库（自定义 JD 兜底，每个考察维度一问 + 追问）
GENERIC_QUESTIONS: List[Question] = [
    Question("专业知识", "请介绍一个你最满意的项目：它的背景、你的职责、采用的技术方案以及最终结果。",
             keywords=["项目", "负责", "技术"], followups=[
                 "项目中最难的技术点是什么？你是如何解决的？",
                 "如果重做一次，哪些设计你会调整？为什么？"]),
    Question("解决问题", "如果线上出现一个你从未遇到过的问题，你会按什么思路定位和解决？",
             keywords=["线上", "排查", "定位", "故障"], followups=[
                 "如果短时间内无法定位根因，你会如何先止损？"]),
    Question("逻辑思维", "请拆解一个复杂需求（例如做一个万人使用的功能），说明你的设计思路与步骤。",
             keywords=["拆解", "设计", "架构", "需求"], followups=[
                 "你会如何评估方案的可行性与风险？"]),
    Question("沟通协作", "描述一次你与同事/业务方在方案上意见不一致的经历，你是如何推进的？",
             keywords=["沟通", "协作", "分歧", "评审"], followups=[
                 "如果对方坚持己见，你如何权衡与决策？"]),
    Question("学习能力", "最近一年你主动学习了哪些新知识/新技术？如何应用到实践中？",
             keywords=["学习", "新技术", "实践"], followups=[
                 "你如何评估自己是否真正掌握了它？"]),
    Question("职业素养", "如果一项重要任务 deadline 临近而进度滞后，你会怎么决策与沟通？",
             keywords=["优先级", "质量", "沟通", "风险"], followups=[
                 "在质量与速度冲突时，你的判断依据是什么？"]),
]


def clean_jd(text: str) -> str:
    text = re.sub(r"\r\n", "\n", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def detect_type(text: str) -> tuple:
    """返回 (岗位名称, job_key, 是否内置)。"""
    for name, pattern, key in TYPE_RULES:
        if pattern.search(text):
            return name, key, key in JOB_MAP
    return "自定义岗位", "custom", False


def extract_requirements(text: str) -> dict:
    req = {
        "degree": "本科",
        "experience_years": 0.0,
        "responsibilities": [],
        "bonus_points": [],
    }
    for pattern, label in DEGREE_RULES:
        if pattern.search(text):
            req["degree"] = label
            break
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:年|年以上|年左右)[^\n]{0,6}经验", text)
    if not m:
        m = re.search(r"经验[^\n]{0,4}(\d+(?:\.\d+)?)\s*年", text)
    if m:
        req["experience_years"] = float(m.group(1))
    for seg in re.split(r"[;；。\n]", text):
        seg = seg.strip()
        if not seg:
            continue
        if any(k in seg for k in ("负责", "职责", "工作内容", "岗位要求")):
            req["responsibilities"].append(seg)
        elif any(k in seg for k in ("加分", "优先", "熟悉以下")):
            req["bonus_points"].append(seg)
    return req


def extract_core_skills(text: str) -> List[str]:
    from .resume.parser import SKILL_DICT
    skills: List[str] = []
    for label, keywords in SKILL_DICT.items():
        if any(re.search(rf"(?i){re.escape(kw)}", text) for kw in keywords):
            skills.append(label)
    return skills


def estimate_difficulty(req: dict, skills: List[str]) -> str:
    score = 0
    if req.get("experience_years", 0) >= 5:
        score += 2
    elif req.get("experience_years", 0) >= 3:
        score += 1
    if req.get("degree") in ("博士", "硕士"):
        score += 1
    if len(skills) >= 4:
        score += 1
    return "高" if score >= 3 else "中" if score >= 2 else "低"


def _custom_six_weights(type_key: str) -> dict:
    """按岗位类型给出六维权重；无匹配时用通用权重。"""
    base = JOB_MAP.get(type_key)
    if base:
        return base.weights
    return dict(DEFAULT_SIX_WEIGHTS)


def build_questions(type_key: str, text: str) -> List[Question]:
    """优先用内置岗位题库，否则用通用题库并尝试结合 JD 关键词定制。"""
    base = JOB_MAP.get(type_key)
    if base:
        return list(base.questions)
    return list(GENERIC_QUESTIONS)


def parse_jd(text: str) -> dict:
    """JD 智能解析主入口 -> 结构化胜任力模型。"""
    cleaned = clean_jd(text)
    if len(cleaned) < 10:
        raise ValueError("JD 内容过短，无法解析")
    name, type_key, builtin = detect_type(cleaned)
    req = extract_requirements(cleaned)
    skills = extract_core_skills(cleaned)
    six_weights = _custom_six_weights(type_key)
    nine_weights = nine_weights_from_six(six_weights)
    difficulty = estimate_difficulty(req, skills)
    questions = build_questions(type_key, cleaned)

    return {
        "job_name": name,
        "job_key": type_key,
        "builtin": builtin,
        "core_skills": skills,
        "requirements": req,
        "weights": six_weights,
        "nine_weights": nine_weights,
        "difficulty": difficulty,
        "questions": [{"dimension": q.dimension, "text": q.text, "followups": q.followups} for q in questions],
    }


def job_model_from_jd(parsed: dict) -> JobModel:
    """把解析后的 JD 变成可直接驱动面试引擎的 JobModel。"""
    name = parsed["job_name"]
    key = f"jd_{parsed['job_key']}"
    questions = [Question(
        dimension=q["dimension"], text=q["text"], followups=list(q.get("followups") or []),
    ) for q in parsed["questions"]]
    return JobModel(
        key=key,
        name=name,
        desc=f"基于 JD 解析的动态岗位模型（难度：{parsed['difficulty']}）",
        core_skills=parsed["core_skills"] or ["通用"],
        weights=parsed["weights"],
        questions=questions,
    )
