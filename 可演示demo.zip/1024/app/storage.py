"""模块6 · 历史记录数据看板存储（SQLite）+ 用户账号。

持久化历次面试会话、评估报告与简历解析记录，供前端随时回看/重新生成/删除。
另含用户账号表（注册/登录），面试记录可按用户归属。
"""
from __future__ import annotations

import hashlib
import json
import secrets
import sqlite3
import time
import uuid
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "app.db"


def _conn() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with _conn() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS sessions(
                sid TEXT PRIMARY KEY,
                created_at REAL NOT NULL,
                job_key TEXT,
                job_name TEXT,
                candidate TEXT,
                match_score REAL,
                match_percent INTEGER,
                status TEXT,
                report_json TEXT,
                username TEXT
            );
            CREATE TABLE IF NOT EXISTS resumes(
                rid TEXT PRIMARY KEY,
                created_at REAL NOT NULL,
                source TEXT,
                text TEXT,
                profile_json TEXT,
                optimized_json TEXT,
                username TEXT
            );
            CREATE TABLE IF NOT EXISTS users(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                nickname TEXT,
                role TEXT DEFAULT 'student',
                school TEXT,
                salt TEXT NOT NULL,
                pw_hash TEXT NOT NULL,
                created_at REAL NOT NULL
            );
            """
        )
        _migrate(c)


def _migrate(c: sqlite3.Connection) -> None:
    """为已存在的 sessions 表补 username 列（旧库兼容）。"""
    cols = {r["name"] for r in c.execute("PRAGMA table_info(sessions)")}
    if "username" not in cols:
        c.execute("ALTER TABLE sessions ADD COLUMN username TEXT")
    # resumes 表迁移
    resume_cols = {r["name"] for r in c.execute("PRAGMA table_info(resumes)")}
    if "username" not in resume_cols:
        c.execute("ALTER TABLE resumes ADD COLUMN username TEXT")
    if "optimized_json" not in resume_cols:
        c.execute("ALTER TABLE resumes ADD COLUMN optimized_json TEXT")


def hash_password(password: str) -> tuple:
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 200000).hex()
    return salt, digest


def verify_password(password: str, salt: str, digest: str) -> bool:
    d = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 200000).hex()
    return secrets.compare_digest(d, digest)


def create_user(username: str, password: str, nickname: str = "", role: str = "student", school: str = "") -> dict:
    init_db()
    salt, digest = hash_password(password)
    with _conn() as c:
        try:
            cur = c.execute(
                "INSERT INTO users(username, nickname, role, school, salt, pw_hash, created_at) "
                "VALUES(?,?,?,?,?,?,?)",
                (username, nickname or username, role, school, salt, digest, time.time()),
            )
        except sqlite3.IntegrityError:
            raise ValueError("用户名已存在")
    return {"id": cur.lastrowid, "username": username, "nickname": nickname or username,
            "role": role, "school": school}


def get_user_by_username(username: str) -> dict | None:
    init_db()
    with _conn() as c:
        row = c.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    if not row:
        return None
    return {
        "id": row["id"], "username": row["username"], "nickname": row["nickname"],
        "role": row["role"], "school": row["school"], "salt": row["salt"], "pw_hash": row["pw_hash"],
    }


def public_user(u: dict | None) -> dict | None:
    if not u:
        return None
    return {"id": u["id"], "username": u["username"], "nickname": u["nickname"],
            "role": u["role"], "school": u["school"]}


ROLES = ("student", "enterprise", "admin")



def save_report(sid: str, report: dict, username: str = "") -> None:
    init_db()
    cand = report.get("candidate") or {}
    job = report.get("job") or {}
    with _conn() as c:
        c.execute(
            "INSERT OR REPLACE INTO sessions(sid, created_at, job_key, job_name, candidate, match_score, match_percent, status, report_json, username) "
            "VALUES(?,?,?,?,?,?,?,?,?,?)",
            (
                sid, time.time(), job.get("key", ""), job.get("name", ""),
                cand.get("name", "候选人"), report.get("match_score", 0),
                report.get("match_percent", 0), "completed",
                json.dumps(report, ensure_ascii=False), username or "",
            ),
        )


def list_sessions(username: str = "") -> list:
    init_db()
    with _conn() as c:
        if username:
            rows = c.execute(
                "SELECT sid, created_at, job_name, candidate, match_score, match_percent, status, username "
                "FROM sessions WHERE username=? ORDER BY created_at DESC LIMIT 200", (username,),
            ).fetchall()
        else:
            rows = c.execute(
                "SELECT sid, created_at, job_name, candidate, match_score, match_percent, status, username "
                "FROM sessions ORDER BY created_at DESC LIMIT 200",
            ).fetchall()
    return [
        {
            "sid": r["sid"], "created_at": r["created_at"],
            "job_name": r["job_name"], "candidate": r["candidate"],
            "match_score": r["match_score"], "match_percent": r["match_percent"],
            "status": r["status"], "username": r["username"] or "",
        }
        for r in rows
    ]


def get_report(sid: str, username: str = "") -> dict | None:
    init_db()
    with _conn() as c:
        if username:
            row = c.execute("SELECT report_json FROM sessions WHERE sid=? AND username=?", (sid, username)).fetchone()
        else:
            row = c.execute("SELECT report_json FROM sessions WHERE sid=?", (sid,)).fetchone()
    if not row or not row["report_json"]:
        return None
    return json.loads(row["report_json"])


def delete_session(sid: str, username: str = "") -> bool:
    init_db()
    with _conn() as c:
        if username:
            cur = c.execute("DELETE FROM sessions WHERE sid=? AND (username=? OR username='')", (sid, username))
        else:
            cur = c.execute("DELETE FROM sessions WHERE sid=?", (sid,))
    return cur.rowcount > 0


def save_resume(source: str, text: str, profile: dict, username: str = "") -> str:
    init_db()
    rid = uuid.uuid4().hex[:12]
    with _conn() as c:
        c.execute(
            "INSERT INTO resumes(rid, created_at, source, text, profile_json, username) VALUES(?,?,?,?,?,?)",
            (rid, time.time(), source, text[:4000], json.dumps(profile, ensure_ascii=False), username or ""),
        )
    return rid


def list_resumes(limit: int = 50) -> list:
    init_db()
    with _conn() as c:
        rows = c.execute(
            "SELECT rid, created_at, source, profile_json FROM resumes ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
    out = []
    for r in rows:
        try:
            profile = json.loads(r["profile_json"])
        except Exception:  # noqa: BLE001
            profile = {}
        out.append({
            "rid": r["rid"], "created_at": r["created_at"], "source": r["source"],
            "name": profile.get("name", "候选人"),
            "skills": profile.get("skills", []),
            "recommended": "",
        })
    return out


def list_resumes_by_user(username: str, limit: int = 50) -> list:
    """获取指定用户的简历列表"""
    init_db()
    with _conn() as c:
        rows = c.execute(
            "SELECT rid, created_at, source, text, profile_json, optimized_json FROM resumes WHERE username=? ORDER BY created_at DESC LIMIT ?",
            (username, limit),
        ).fetchall()
    out = []
    for r in rows:
        try:
            profile = json.loads(r["profile_json"])
        except Exception:  # noqa: BLE001
            profile = {}
        try:
            optimized = json.loads(r["optimized_json"]) if r["optimized_json"] else None
        except Exception:
            optimized = None
        out.append({
            "rid": r["rid"], "created_at": r["created_at"], "source": r["source"],
            "text": r["text"][:200] + "..." if len(r["text"]) > 200 else r["text"],
            "name": profile.get("name", "候选人"),
            "skills": profile.get("skills", []),
            "projects": profile.get("projects", []),
            "degree": profile.get("degree", ""),
            "major": profile.get("major", ""),
            "school": profile.get("school", ""),
            "optimized": optimized is not None,
        })
    return out


def get_resume(rid: str, username: str) -> dict | None:
    """获取指定简历详情"""
    init_db()
    with _conn() as c:
        row = c.execute(
            "SELECT rid, created_at, source, text, profile_json, optimized_json FROM resumes WHERE rid=? AND username=?",
            (rid, username),
        ).fetchone()
    if not row:
        return None
    try:
        profile = json.loads(row["profile_json"])
    except Exception:
        profile = {}
    try:
        optimized = json.loads(row["optimized_json"]) if row["optimized_json"] else None
    except Exception:
        optimized = None
    return {
        "rid": row["rid"], "created_at": row["created_at"], "source": row["source"],
        "text": row["text"],
        "profile": profile,
        "optimized": optimized,
    }


def update_resume_optimized(rid: str, username: str, optimized_text: str) -> bool:
    """保存优化后的简历版本"""
    init_db()
    import time
    with _conn() as c:
        cur = c.execute(
            "UPDATE resumes SET optimized_json=? WHERE rid=? AND username=?",
            (json.dumps({"text": optimized_text, "updated_at": time.time()}, ensure_ascii=False), rid, username),
        )
    return cur.rowcount > 0


def delete_resume(rid: str, username: str) -> bool:
    """删除简历"""
    init_db()
    with _conn() as c:
        cur = c.execute("DELETE FROM resumes WHERE rid=? AND username=?", (rid, username))
    return cur.rowcount > 0
