"""FastAPI 服务入口 —— 岗位胜任力多轮问询与评估报告生成（讯飞1024应用赛）。

接口:
  GET    /api/health                         健康检查
  POST   /api/auth/register|login|logout     账号注册/登录/登出
  GET    /api/auth/me                        当前用户
  GET    /api/jobs                           内置岗位列表
  POST   /api/jd/parse                       模块1: 任意岗位 JD 智能解析
  POST   /api/resume/parse                   简历解析 -> 画像 + 岗位匹配建议
  POST   /api/resume/upload                  简历文件上传解析 (txt/md/pdf/docx)
  POST   /api/resume/optimize                模块2: AI 简历优化(STAR/量化/JD适配)
  POST   /api/resume/analyze                 简历风险检测
  GET    /api/resume/templates               简历模板库
  POST   /api/resume/apply-template          一键套用模板
  POST   /api/interview/start                登录 创建面试(内置岗位 或 自定义 JD)
  POST   /api/interview/respond              登录 发送回答 -> 追问/下一题/结束
  POST   /api/interview/{sid}/stop           登录 手动停止面试
  GET    /api/interview/{sid}/report         登录 模块4/5: 九维评估报告(JSON)
  GET    /api/interview/{sid}/report.pdf     登录 模块5: 评估报告 PDF 导出
  GET    /api/history                        登录 模块6: 历史记录看板(按账号)
  GET    /api/history/{sid}                  登录 单份历史报告
  DELETE /api/history/{sid}                  登录 删除历史记录
  GET    /api/assistant/status               模块7: AI 助手引擎状态
  POST   /api/assistant/chat                 模块7: AI 助手问答(整段)
  POST   /api/assistant/chat/stream          模块7: AI 助手问答(SSE 流式)
  GET    /api/llm/config                     查看大模型配置(脱敏)
  POST   /api/llm/config                     修改大模型配置(OpenAI 兼容, 热生效)
  POST   /api/llm/test                       测试大模型连通性
  GET    /                                   前端页面(登录 + 多视图工作台)

启动: uvicorn app.main:app --host 0.0.0.0 --port 8010
"""
from __future__ import annotations

import json
import threading
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .competency.model import get_job_model, list_job_names
from .config import settings
from .interview.engine import (
    InterviewSession,
    create_session,
    create_session_with_job,
)
from .jd import job_model_from_jd, parse_jd
from .llm import (
    LLMError,
    Message,
    effective_openai_config,
    ensure_llm,
    masked_config,
    save_config,
)
from .report import build_report_pdf, generate_report
from .resume.extractor import extract_text_from_file
from .resume.optimizer import analyze_resume, optimize_resume
from .resume.parser import match_best_job, parse_resume_text
from .resume.templates import apply_template, list_templates
from .storage import (
    ROLES,
    create_user,
    delete_session,
    get_report,
    get_user_by_username,
    init_db,
    list_resumes,
    list_sessions,
    public_user,
    save_report,
    save_resume,
    verify_password,
)
from .tts import synthesize, tts_available

app = FastAPI(
    title="岗位胜任力多轮问询与评估报告生成",
    version="2.0.0",
    description="基于大模型的面试智能体: JD解析 -> 简历画像 -> 多轮情景化问询 -> 九维胜任力评估报告",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 会话存储(内存; 演示够用, 生产可换 Redis) + 历史记录(SQLite)
_sessions: Dict[str, InterviewSession] = {}
_lock = threading.Lock()
_llm_holder = {"llm": ensure_llm()}


def current_llm():
    """当前大模型实例(可在运行时通过 /api/llm/config 热切换)。"""
    return _llm_holder["llm"]


def provider_name() -> str:
    from .llm.mock import MockLLM
    from .llm.openai_compat import OpenAICompatLLM
    from .llm.spark import SparkLLM

    llm = current_llm()
    if isinstance(llm, OpenAICompatLLM):
        return "openai"
    if isinstance(llm, SparkLLM):
        return "spark"
    if isinstance(llm, MockLLM):
        return "mock"
    return "unknown"


init_db()

# 用户令牌(内存; 演示用, 生产可换 JWT/Redis)
_tokens: Dict[str, dict] = {}  # token -> user(public)


def _current_user(authorization: Optional[str] = Header(default=None)) -> Optional[dict]:
    if not authorization:
        return None
    token = authorization.replace("Bearer", "").strip()
    if not token:
        return None
    return _tokens.get(token)


def require_user(user: Optional[dict] = Depends(_current_user)) -> dict:
    if not user:
        raise HTTPException(status_code=401, detail="未登录或登录已过期")
    return user


def issue_token(user: dict) -> str:
    import uuid as _uuid
    token = _uuid.uuid4().hex
    _tokens[token] = user
    return token



@app.middleware("http")
async def no_cache(request, call_next):
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


# ----------------------------------------------------------------------
# 请求模型
# ----------------------------------------------------------------------
class RegisterIn(BaseModel):
    username: str = Field(min_length=2, max_length=32)
    password: str = Field(min_length=4, max_length=64)
    nickname: str = Field(default="", max_length=32)
    role: str = Field(default="student", pattern="^(student|enterprise|admin)$")
    school: str = Field(default="", max_length=64)


class LoginIn(BaseModel):
    username: str
    password: str


class ResumeIn(BaseModel):
    text: str = Field(min_length=20, description="简历文本")


class JDIn(BaseModel):
    text: str = Field(min_length=10, description="岗位 JD 文本")


class InterviewStartIn(BaseModel):
    job_key: Optional[str] = Field(default=None, description="内置岗位 key")
    jd: Optional[str] = Field(default=None, description="自定义岗位 JD（优先于 job_key）")
    resume_text: str = Field(min_length=20, description="简历文本")


class InterviewRespondIn(BaseModel):
    answer: str = Field(min_length=1, description="候选人的回答")
    metrics: Optional[Dict[str, Any]] = Field(default=None, description="语音/行为多模态指标: speech_rate, pause_count, duration_ms 等")


class TTSIn(BaseModel):
    text: str = Field(max_length=500, description="需要朗读的文本")
    voice: str = Field(default="x4_yezi", description="音色: x4_yezi, x4_xiaomei, x4_xiaofeng, x4_chaozhuo")


class LLMConfigIn(BaseModel):
    base_url: str = Field(default="", max_length=300, description="接口地址, 例 https://api.deepseek.com/v1 或 wss://spark-api.xf-yun.com/v4.0/chat")
    api_key: str = Field(default="", max_length=300, description="API Key; 传空字符串表示清除")
    model: str = Field(default="", max_length=120, description="模型名, 例 deepseek-chat / x1")
    app_id: str = Field(default="", max_length=100, description="讯飞 APP ID (仅讯飞需要)")
    api_secret: str = Field(default="", max_length=300, description="讯飞 API Secret (仅讯飞需要)")


class AssistantChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=4000, description="用户提问")
    history: List[Dict[str, str]] = Field(default_factory=list, description="最近对话 [{role, content}]")
    mode: str = Field(default="career", pattern="^(career|tech|resume|interview)$")


class OptimizeIn(BaseModel):
    text: str = Field(min_length=20)
    job_name: str = Field(default="")


class TemplateIn(BaseModel):
    template_key: str
    text: str = Field(min_length=20)


# ----------------------------------------------------------------------
# 健康 / TTS
# ----------------------------------------------------------------------
@app.get("/api/health")
def health():
    provider = provider_name()
    return {
        "status": "ok",
        "llm": provider,
        "llm_enabled": settings.llm_enabled,
        "tts": "edge" if True else "browser",
    }


@app.post("/api/tts")
def text_to_speech(body: TTSIn):
    import base64
    audio = synthesize(body.text, body.voice)
    if audio is None:
        return {"source": "browser"}
    # 返回spark格式，前端统一处理
    return {"source": "spark", "format": "mp3", "audio": base64.b64encode(audio).decode()}


# ----------------------------------------------------------------------
# 模块7: AI 助手(自由问答) + 大模型运行时配置
# ----------------------------------------------------------------------
ASSISTANT_MODES = {
    "career": (
        "你是「智聘」求职助手，一位资深 HR 总监兼职业规划师，熟悉校招/社招全流程。"
        "回答务实、结构化：先给结论，再分点展开，结合当前招聘市场行情给出可执行建议。"
        "涉及 offer 对比、时间规划时给出具体步骤和时间线。控制在 400 字以内。"
    ),
    "tech": (
        "你是「智聘」技术答疑助手，一位资深一线大厂工程师。"
        "面向校招/初级工程师解释技术概念与实战问题：先一句话点透本质，"
        "再分层展开原理与典型场景，必要时给出简短代码示例。控制在 500 字以内。"
    ),
    "resume": (
        "你是「智聘」简历优化专家，精通 STAR 法则与量化表达。"
        "用户会粘贴简历片段或描述经历，你指出问题并直接给出改写后的版本，"
        "改写要突出个人角色、动作与量化结果。用「问题→改写建议→示例」的结构回答。"
    ),
    "interview": (
        "你是「智聘」面试辅导教练，擅长目标岗位的面试题拆解与回答教练。"
        "用户给出问题或场景，你给出：考察点分析→参考回答框架→高分要点→常见踩坑。"
        "回答要具体可背诵，不要空话。控制在 500 字以内。"
    ),
}


@app.get("/api/assistant/status")
def assistant_status():
    cfg = effective_openai_config()
    provider = provider_name()
    model = cfg["model"] if provider == "openai" else ("spark-4.0-ultra" if provider == "spark" else "rule-engine")
    return {"provider": provider, "model": model, "live": provider != "mock"}


class LLMTestIn(BaseModel):
    base_url: str = Field(default="", max_length=300)
    api_key: str = Field(default="", max_length=300)
    model: str = Field(default="", max_length=120)
    app_id: str = Field(default="", max_length=100)
    api_secret: str = Field(default="", max_length=300)


@app.post("/api/llm/config")
def set_llm_config(body: LLMConfigIn):
    from .llm.store import load_config
    existing = load_config()
    api_key = body.api_key if body.api_key != "__KEEP__" else existing.get("api_key", "")
    api_secret = body.api_secret if body.api_secret != "__KEEP__" else existing.get("api_secret", "")
    app_id = body.app_id if body.app_id != "__KEEP__" else existing.get("app_id", "")
    clean = save_config({
        "base_url": body.base_url,
        "api_key": api_key,
        "model": body.model,
        "app_id": app_id,
        "api_secret": api_secret,
    })
    _llm_holder["llm"] = ensure_llm()
    provider = provider_name()
    return {"message": "配置已保存并生效", "provider": provider, "config": masked_config(clean)}


@app.get("/api/llm/config")
def get_llm_config():
    from .llm.store import load_config
    return {"provider": provider_name(), "config": masked_config(load_config())}


@app.post("/api/llm/test")
def test_llm(body: Optional[LLMTestIn] = None):
    """body 为空时测当前已保存配置; 传了 base_url+model 则测表单值(api_key 支持 __KEEP__)。"""
    llm = current_llm()
    if body and body.base_url.strip() and body.model.strip():
        from .llm import OpenAICompatLLM, SparkLLM
        from .llm.store import load_config
        api_key = body.api_key
        if api_key == "__KEEP__":
            api_key = load_config().get("api_key", "")
        # 讯飞地址或 wss:// 走 SparkLLM（专用鉴权）
        if body.base_url.startswith("wss://") or "xf-yun.com" in body.base_url:
            api_secret = getattr(body, "api_secret", "") or ""
            app_id = getattr(body, "app_id", "") or ""
            if api_secret == "__KEEP__":
                api_secret = load_config().get("api_secret", "")
            if app_id == "__KEEP__":
                app_id = load_config().get("app_id", "")
            # 临时写入 store 供 SparkLLM 读取
            if api_secret or app_id:
                from .llm.store import save_config as _save
                existing = load_config()
                _save({**existing, "api_key": api_key, "api_secret": api_secret or existing.get("api_secret", ""), "app_id": app_id or existing.get("app_id", "")})
            try:
                llm = SparkLLM()
            except LLMError as exc:
                return {"ok": False, "provider": "spark", "error": str(exc)}
        else:
            try:
                llm = OpenAICompatLLM(body.base_url, api_key, body.model)
            except LLMError as exc:
                return {"ok": False, "provider": "openai", "error": str(exc)}
    try:
        r = llm.chat(
            [Message(role="user", content="收到请只回复四个字：连接成功")],
            temperature=0.1,
            max_tokens=512,
        )
        return {"ok": True, "provider": provider_name(), "reply": r.content[:120]}
    except LLMError as exc:
        return {"ok": False, "provider": provider_name(), "error": str(exc)}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "provider": provider_name(), "error": f"{type(exc).__name__}: {exc}"}


def _assistant_messages(body: AssistantChatIn) -> List[Message]:
    system = ASSISTANT_MODES.get(body.mode, ASSISTANT_MODES["career"])
    if provider_name() == "mock":
        system = "【助手】" + system
    msgs = [Message(role="system", content=system)]
    for h in body.history[-12:]:
        role, content = h.get("role"), (h.get("content") or "")[:2000]
        if role in ("user", "assistant") and content:
            msgs.append(Message(role=role, content=content))
    msgs.append(Message(role="user", content=body.message))
    return msgs


@app.post("/api/assistant/chat")
def assistant_chat(body: AssistantChatIn):
    try:
        r = current_llm().chat(_assistant_messages(body))
        return {"reply": r.content, "provider": provider_name()}
    except LLMError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.post("/api/assistant/chat/stream")
async def assistant_chat_stream(body: AssistantChatIn):
    """SSE 流式问答; 无流式能力的引擎自动降级为整段返回。"""
    llm = current_llm()

    def sse(obj: dict) -> str:
        return f"data: {json.dumps(obj, ensure_ascii=False)}\n\n"

    def gen():
        stream_fn = getattr(llm, "chat_stream", None)
        if callable(stream_fn):
            try:
                for piece in stream_fn(_assistant_messages(body)):
                    yield sse({"delta": piece})
                yield sse({"done": True, "provider": provider_name()})
                return
            except LLMError as exc:
                yield sse({"error": str(exc)})
                return
        try:
            r = llm.chat(_assistant_messages(body))
            yield sse({"delta": r.content})
            yield sse({"done": True, "provider": provider_name()})
        except LLMError as exc:
            yield sse({"error": str(exc)})

    return StreamingResponse(
        gen(),
        media_type="text/event-stream; charset=utf-8",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ----------------------------------------------------------------------
# 认证: 注册 / 登录 / 登出 / 当前用户
# ----------------------------------------------------------------------
@app.get("/api/auth/roles")
def auth_roles():
    return {"roles": list(ROLES)}


@app.post("/api/auth/register")
def auth_register(body: RegisterIn):
    try:
        user = create_user(body.username, body.password, body.nickname, body.role, body.school)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"message": "注册成功", "user": public_user(user), "token": issue_token(public_user(user))}


@app.post("/api/auth/login")
def auth_login(body: LoginIn):
    u = get_user_by_username(body.username)
    if not u or not verify_password(body.password, u["salt"], u["pw_hash"]):
        raise HTTPException(status_code=401, detail="用户名或密码错误")
    return {"message": "登录成功", "user": public_user(u), "token": issue_token(public_user(u))}


@app.post("/api/auth/logout")
def auth_logout(authorization: Optional[str] = Header(default=None)):
    if authorization:
        _tokens.pop(authorization.replace("Bearer", "").strip(), None)
    return {"message": "已登出"}


@app.get("/api/auth/me")
def auth_me(user: Optional[dict] = Depends(_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="未登录")
    return {"user": user}


# ----------------------------------------------------------------------
# 模块1: 岗位 JD 智能解析
# ----------------------------------------------------------------------
@app.post("/api/jd/parse")
def jd_parse(body: JDIn):
    try:
        return parse_jd(body.text)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=f"JD 解析失败: {exc}")


# ----------------------------------------------------------------------
# 岗位 / 简历
# ----------------------------------------------------------------------
@app.get("/api/jobs")
def jobs():
    return [
        {"key": job.key, "name": job.name, "desc": job.desc, "core_skills": job.core_skills}
        for job in [get_job_model(k) for k in _job_keys()]
    ]


def _job_keys():
    from .competency.model import JOB_MODELS
    return [j.key for j in JOB_MODELS]


@app.post("/api/resume/parse")
def parse_resume(body: ResumeIn, user: dict = Depends(require_user)):
    try:
        profile = parse_resume_text(body.text)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=f"简历解析失败: {exc}")
    best_key, best_score, ranking = match_best_job(profile)
    save_resume("粘贴", body.text, profile, user["username"])
    return {
        "profile": profile,
        "recommended_job": best_key,
        "recommended_score": best_score,
        "ranking": ranking,
    }


@app.post("/api/resume/upload")
async def resume_upload(file: UploadFile = File(...), filename: str = Form(""), user: dict = Depends(require_user)):
    data = await file.read()
    name = filename or file.filename or "resume.txt"
    try:
        text = extract_text_from_file(name, data)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=str(exc))
    profile = parse_resume_text(text)
    best_key, best_score, ranking = match_best_job(profile)
    save_resume(name, text, profile, user["username"])
    return {
        "filename": name,
        "text": text,
        "profile": profile,
        "recommended_job": best_key,
        "recommended_score": best_score,
        "ranking": ranking,
    }


@app.post("/api/resume/optimize")
def resume_optimize(body: OptimizeIn):
    try:
        return optimize_resume(body.text, body.job_name)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=f"简历优化失败: {exc}")


@app.post("/api/resume/analyze")
def resume_analyze(body: ResumeIn):
    try:
        return analyze_resume(body.text)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=f"简历检测失败: {exc}")


@app.get("/api/resume/templates")
def resume_templates():
    return {"templates": list_templates()}


@app.post("/api/resume/apply-template")
def resume_apply_template(body: TemplateIn):
    try:
        return apply_template(body.template_key, body.text)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=str(exc))


# ----------------------------------------------------------------------
# 简历库管理
# ----------------------------------------------------------------------
class ResumeOptimizeSaveIn(BaseModel):
    optimized: str = Field(min_length=20, description="优化后的简历文本")


@app.get("/api/resume/list")
def resume_list(user: dict = Depends(require_user)):
    """获取当前用户的简历列表"""
    from .storage import list_resumes_by_user
    return {"resumes": list_resumes_by_user(user["username"])}


@app.get("/api/resume/{rid}")
def resume_get(rid: str, user: dict = Depends(require_user)):
    """获取指定简历详情"""
    from .storage import get_resume
    resume = get_resume(rid, user["username"])
    if not resume:
        raise HTTPException(status_code=404, detail="简历不存在")
    return resume


@app.post("/api/resume/{rid}/optimize")
def resume_save_optimized(rid: str, body: ResumeOptimizeSaveIn, user: dict = Depends(require_user)):
    """保存优化后的简历版本"""
    from .storage import update_resume_optimized
    ok = update_resume_optimized(rid, user["username"], body.optimized)
    if not ok:
        raise HTTPException(status_code=404, detail="简历不存在或无权限")
    return {"message": "优化版本已保存"}


@app.delete("/api/resume/{rid}")
def resume_delete(rid: str, user: dict = Depends(require_user)):
    """删除简历"""
    from .storage import delete_resume
    ok = delete_resume(rid, user["username"])
    if not ok:
        raise HTTPException(status_code=404, detail="简历不存在或无权限")
    return {"deleted": True}


@app.get("/api/jobs/categories")
def jobs_categories():
    """获取岗位分类"""
    from .competency.model import get_job_categories
    return get_job_categories()


@app.get("/api/jobs/real-data")
def get_real_job_data(job_key: str = "", city: str = "", limit: int = 50):
    """获取真实招聘数据（多源聚合）"""
    from .job_scraper import fetch_real_job_data
    try:
        return fetch_real_job_data(job_key, city, limit)
    except Exception as e:
        return {"error": str(e), "salary_distribution": [], "top_skills": [], "city_comparison": []}


# ----------------------------------------------------------------------
# 模块3: 多轮面试
# ----------------------------------------------------------------------
@app.post("/api/interview/start")
def start_interview(body: InterviewStartIn, user: dict = Depends(require_user)):
    try:
        if body.jd and len(body.jd.strip()) >= 10:
            parsed = parse_jd(body.jd)
            session = create_session_with_job(job_model_from_jd(parsed), body.resume_text, llm=current_llm())
        else:
            if not body.job_key or body.job_key not in _job_keys():
                raise HTTPException(status_code=404, detail="请选择有效岗位或提供 JD")
            session = create_session(body.job_key, body.resume_text, llm=current_llm())
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=f"创建面试失败: {exc}")
    session.username = user["username"]
    sid = _new_sid(session)
    opening = session.start()
    return {"session_id": sid, **opening}


@app.post("/api/interview/respond")
def respond(body: InterviewRespondIn, session_id: str, user: dict = Depends(require_user)):
    session = _get_session(session_id)
    result = session.respond(body.answer, body.metrics)
    if result["type"] == "end":
        _sessions[session_id].finished = True
    return result


@app.post("/api/interview/{sid}/stop")
def stop_interview(sid: str, user: dict = Depends(require_user)):
    """手动停止面试"""
    session = _get_session(sid)
    if session.finished:
        return {"message": "面试已结束", "finished": True}
    result = session._finish()
    _sessions[sid].finished = True
    return result


@app.get("/api/interview/{sid}/report")
def get_report(sid: str, user: dict = Depends(require_user)):
    session = _get_session(sid)
    if not session.finished:
        raise HTTPException(status_code=400, detail="面试尚未结束，无法生成报告")
    report = generate_report(session)
    save_report(sid, report, getattr(session, "username", ""))
    return report


@app.get("/api/interview/{sid}/report.pdf")
def get_report_pdf(sid: str, user: dict = Depends(require_user)):
    session = _get_session(sid)
    if not session.finished:
        raise HTTPException(status_code=400, detail="面试尚未结束，无法生成报告")
    report = generate_report(session)
    save_report(sid, report, getattr(session, "username", ""))
    try:
        pdf = build_report_pdf(report)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"PDF 生成失败: {exc}")
    return Response(
        content=pdf,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="report_{sid}.pdf"'},
    )


# ----------------------------------------------------------------------
# 模块6: 历史记录
# ----------------------------------------------------------------------
@app.get("/api/history")
def history(user: dict = Depends(require_user)):
    uname = user["username"]
    sessions = list_sessions(uname)
    return {
        "sessions": sessions,
        "resumes": list_resumes(),
        "total_sessions": len(sessions),
        "total_resumes": len(list_resumes()),
    }


@app.get("/api/history/{sid}")
def history_detail(sid: str, user: dict = Depends(require_user)):
    report = get_report_from_store(sid, user["username"])
    if report is None:
        raise HTTPException(status_code=404, detail="历史记录不存在")
    return report


@app.delete("/api/history/{sid}")
def history_delete(sid: str, user: dict = Depends(require_user)):
    ok = delete_session(sid, user["username"])
    if not ok:
        raise HTTPException(status_code=404, detail="历史记录不存在")
    return {"deleted": True}


def get_report_from_store(sid: str, username: str = ""):
    from .storage import get_report
    return get_report(sid, username)


# ----------------------------------------------------------------------
# 会话管理
# ----------------------------------------------------------------------
def _new_sid(session: InterviewSession) -> str:
    import uuid
    sid = uuid.uuid4().hex[:12]
    with _lock:
        _sessions[sid] = session
    return sid


def _get_session(sid: str) -> InterviewSession:
    with _lock:
        session = _sessions.get(sid)
    if not session:
        raise HTTPException(status_code=404, detail="会话不存在或已过期")
    return session


# ----------------------------------------------------------------------
# 静态页面
# ----------------------------------------------------------------------
app.mount("/static", StaticFiles(directory=str(settings.STATIC_DIR), html=True), name="static")


@app.get("/")
def index():
    html = (settings.STATIC_DIR / "index.html").read_text(encoding="utf-8")
    css = (settings.STATIC_DIR / "style.css").read_text(encoding="utf-8")
    js = (settings.STATIC_DIR / "app.js").read_text(encoding="utf-8")
    html = html.replace(
        '<link rel="stylesheet" href="/static/style.css" />',
        f"<style>\n{css}\n</style>",
    )
    html = html.replace(
        '<script src="/static/app.js"></script>',
        f"<script>\n{js}\n</script>",
    )
    return HTMLResponse(html)