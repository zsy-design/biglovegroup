"""简历解析与胜任力画像构建。

输入: 简历文本（txt/md 粘贴或上传）。
输出: 候选人画像 - 姓名/院校/学历/技能标签/项目经历/初步岗位匹配建议。
基于规则 + 技能词典抽取，可离线运行；接入大模型后可进一步做语义提炼。
"""
from __future__ import annotations

import re
from typing import List, Tuple

from ..competency.model import JOB_MODELS

# 通用技能词典（用于打能力标签）
SKILL_DICT = {
    "java": ["java", "spring", "springboot", "mybatis", "jvm", "dubbo", "微服务", "高并发"],
    "python": ["python", "pandas", "numpy", "django", "flask", "fastapi", "爬虫"],
    "算法": ["深度学习", "机器学习", "pytorch", "tensorflow", "nlp", "自然语言", "计算机视觉", "cv",
             "推荐系统", "大模型", "llm", "xgboost", "神经网络", "bert", "transformer"],
    "前端": ["html", "css", "javascript", "vue", "react", "webpack", "小程序", "typescript", "echarts"],
    "后端": ["mysql", "redis", "kafka", "数据库", "linux", "docker", "k8s", "go", "后端"],
    "数据": ["sql", "数据分析", "数据挖掘", "可视化", "excel", "bi", "报表", "数仓", "tableau", "powerbi"],
    "测试": ["测试", "自动化", "接口测试", "selenium", "pytest", "jmeter", "用例", "bug"],
    "产品": ["产品", "需求", "prd", "原型", "axure", "用户调研", "竞品", "运营"],
    "安全": ["安全", "渗透", "漏洞", "web安全", "加密", "防火墙", "ctf", "应急响应"],
}

DEGREE_KEYWORDS = ["博士", "硕士", "研究生", "本科", "学士", "大专", "专科"]
STOP_KEYWORDS = ["姓名", "性别", "年龄", "电话", "邮箱", "籍贯", "民族", "政治面貌"]


def _clean(text: str) -> str:
    text = re.sub(r"\r\n", "\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


class ResumeParser:
    """规则式简历解析器"""

    def __init__(self, text: str) -> None:
        self.raw = _clean(text)

    # ---------- 抽取 ----------
    def extract_name(self) -> str:
        for line in self.raw.splitlines()[:6]:
            line = line.strip().strip("|").strip()
            if not line or any(k in line for k in STOP_KEYWORDS):
                continue
            # 名字一般是第一行且不含数字/标点
            if 2 <= len(line) <= 4 and not re.search(r"[\d\s:：@，。、()（）]|学校|大学|求职|岗位|专业", line):
                return line
        return "候选人"

    def extract_education(self) -> str:
        for kw in DEGREE_KEYWORDS:
            if kw in self.raw:
                return kw
        return "本科"

    def extract_school(self) -> str:
        match = re.search(r"([\u4e00-\u9fa5]{2,}(?:大学|学院|学校|职业技术学院))", self.raw)
        return match.group(1) if match else ""

    def extract_major(self) -> str:
        match = re.search(r"(?:专业|主修)[:：]?\s*([\u4e00-\u9fa5A-Za-z]{2,20})", self.raw)
        if match:
            return match.group(1)
        match = re.search(r"([\u4e00-\u9fa5A-Za-z]{2,20}(?:工程|科学|技术|管理|设计|学))", self.raw)
        return match.group(1) if match else ""

    def extract_skills(self) -> List[str]:
        found: List[str] = []
        for label, keywords in SKILL_DICT.items():
            hit = any(re.search(rf"(?i){re.escape(kw)}", self.raw) for kw in keywords)
            if hit:
                found.append(label)
        return found

    def extract_projects(self) -> List[Tuple[str, str]]:
        """抽取项目经历: (项目名, 描述)"""
        projects = []
        for m in re.finditer(
            r"(?:项目|课题|作品|毕设)[:：]?\s*([^\n，。；]{2,30})", self.raw
        ):
            name = m.group(1).strip()
            if name and name not in [p[0] for p in projects]:
                projects.append((name, self._nearby(m.start())))
        return projects

    def _nearby(self, start: int, radius: int = 60) -> str:
        seg = self.raw[start: start + radius]
        return re.sub(r"\s+", " ", seg).strip()[:60]

    def extract_experience_years(self) -> float:
        match = re.search(r"(\d+)\s*(?:年|年)经验", self.raw)
        return float(match.group(1)) if match else 0.0

    def build_profile(self) -> dict:
        skills = self.extract_skills()
        return {
            "name": self.extract_name(),
            "school": self.extract_school(),
            "degree": self.extract_education(),
            "major": self.extract_major(),
            "skills": skills,
            "projects": self.extract_projects(),
            "raw": self.raw,
        }


def parse_resume_text(text: str) -> dict:
    return ResumeParser(text).build_profile()


def match_best_job(profile: dict) -> Tuple[str, float, List[Tuple[str, float]]]:
    """基于技能标签 + 简历原文中的核心技能命中，计算各岗位匹配度，返回最佳岗位。

    评分公式: raw = 命中核心技能数 / 核心技能总数
              adjusted = raw * 0.7 + 0.3 * 岗位"专业知识"权重归一化
    """
    tags = [s.lower() for s in profile.get("skills", [])]
    raw_lower = (profile.get("raw") or "").lower()
    scores = []
    for job in JOB_MODELS:
        core = [c.lower() for c in job.core_skills]
        hit = 0
        for c in core:
            parts = [p for p in re.split(r"[/、\s]", c) if p]
            matched = any(tag in c or c in tag for tag in tags) or any(
                p and p in raw_lower for p in parts
            )
            if matched:
                hit += 1
        raw = hit / max(len(core), 1)
        skill_bonus = job.weight("专业知识") / 0.28  # 0~1 归一化
        adjusted = min(1.0, raw * 0.7 + 0.3 * skill_bonus)
        scores.append((job.key, round(adjusted, 2)))
    scores.sort(key=lambda kv: kv[1], reverse=True)
    return scores[0][0], scores[0][1], scores
