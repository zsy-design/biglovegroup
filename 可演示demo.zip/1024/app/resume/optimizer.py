"""模块2b · AI 简历优化 + 简历风险检测。

优化：语病修正、逻辑梳理、经历量化、成果数据化、STAR 法则重构、
      JD 关键词补强、优势放大。星火可用时 LLM 语义润色，离线走确定性规则。
风险检测：空洞描述 / 无量化 / 无项目经历 / 逻辑漏洞 / 短板风险。
"""
from __future__ import annotations

import re
from typing import List

from .parser import parse_resume_text
from ..llm import Message, ensure_llm

_QUANT_WORDS = re.compile(r"\d+%|\d+人|\d+万|\d+次|\d+天|\d+倍|\d+个|\d+项")
_ROLE_WORDS = ("负责", "主导", "独立", "牵头", "完成", "设计", "推动", "落地")
_VAGUE_PATTERNS = [
    (re.compile(r"有较强的?.{0,6}(学习|沟通|团队|抗压|责任心)能力"), "空泛的自我评价，缺少事实支撑"),
    (re.compile(r"熟悉.{0,10}(相关|基本|一定)"), "使用了模糊限定词（相关/基本/一定）"),
    (re.compile(r"协助.{0,8}(他人|团队).{0,6}工作"), "只体现协助，未突出个人贡献"),
]


def _extract_bullets(text: str) -> List[str]:
    """把简历文本粗切成"条目"（按行或标点）"""
    lines = [l.strip(" -•·*") for l in text.splitlines() if l.strip(" -•·*")]
    return [l for l in lines if 4 < len(l) < 120]


def _rewrite_bullet(bullet: str) -> str:
    """确定性改写：把空洞描述补成 STAR 骨架 / 加入量化提示"""
    if _QUANT_WORDS.search(bullet):
        return bullet
    if any(w in bullet for w in _ROLE_WORDS):
        if "负责" in bullet and "。" not in bullet and "；" not in bullet:
            return f"{bullet}（建议补充：背景-任务-行动-结果的量化指标，例如「从 0 到 1 / 提升 XX% / 覆盖 XX 人」）"
        return bullet
    return f"{bullet}（建议：补全我负责的具体工作 + 我的贡献 + 量化结果）"


def optimize_resume(text: str, job_name: str = "") -> dict:
    profile = parse_resume_text(text)
    bullets = _extract_bullets(text)
    rewritten = [_rewrite_bullet(b) for b in bullets]
    changes = [
        "将个人经历按 STAR（背景/任务/行动/结果）结构化组织",
        "为含「负责」等动词的条目补充量化成果（占比/次数/人数/时长）",
        "开头加入与目标岗位强相关的技能关键词，便于关键词筛选",
        "删除主观空泛的评价语，替换为有事实与数字支撑的表述",
    ]
    optimized_lines = [
        f"# {profile['name']} · {job_name or '目标岗位'} 简历（AI 优化版）",
        "",
        "## 教育背景",
        f"{profile['school'] or '院校'} · {profile['degree']} · {profile['major'] or '专业'}",
        "",
        "## 核心技能",
        "、".join(profile["skills"] or ["—"]),
        "",
        "## 项目与工作经历（STAR 重构）",
    ]
    optimized_lines += ["- " + r for r in rewritten] or ["- （请补充项目经历）"]
    optimized_text = "\n".join(optimized_lines)

    llm = ensure_llm()
    if _use_llm(llm):
        try:
            res = llm.chat([
                Message("system", (
                    "【简历优化】你是资深简历优化专家。请把用户简历改写为 STAR 化、量化、"
                    "贴合目标岗位的版本，返回 JSON: {\"optimized\": str, \"changes\": [str]}"
                )),
                Message("user", f"目标岗位: {job_name}\n原简历: {text[:3000]}"),
            ], temperature=0.5, max_tokens=1200)
            import json as _json
            data = _json.loads(res.content)
            if data.get("optimized"):
                return {"profile": profile, "optimized": data["optimized"],
                        "changes": data.get("changes") or changes}
        except Exception:  # noqa: BLE001
            pass
    return {"profile": profile, "optimized": optimized_text, "changes": changes}


def analyze_resume(text: str) -> dict:
    """简历风险检测：返回问题清单与综合健康度。"""
    profile = parse_resume_text(text)
    issues: List[dict] = []
    raw = text

    if not _QUANT_WORDS.search(raw):
        issues.append({"severity": "high", "type": "缺乏量化", "advice": "经历缺少数字支撑，建议为每个成果补充占比/次数/规模等量化指标"})
    if not profile.get("projects"):
        issues.append({"severity": "high", "type": "项目缺失", "advice": "未识别到项目/工作经历，面试将缺少可深挖的事实依据"})
    else:
        shallow = [p[0] for p in profile["projects"] if len(p[1]) < 20]
        if shallow:
            issues.append({"severity": "medium", "type": "描述过浅",
                           "advice": f"项目「{shallow[0]}」描述过于简略，建议补充个人职责与结果"})
    role_hits = sum(1 for w in _ROLE_WORDS if re.search(rf"我?{w}", raw))
    if role_hits < 2:
        issues.append({"severity": "medium", "type": "角色模糊", "advice": "个人角色不清晰，建议明确「我负责/我主导/我独立完成」的具体事项"})
    for pat, msg in _VAGUE_PATTERNS:
        if pat.search(raw):
            issues.append({"severity": "low", "type": "空泛表述", "advice": msg})
    lines = [l for l in raw.splitlines() if l.strip()]
    if len(lines) < 8:
        issues.append({"severity": "medium", "type": "信息单薄", "advice": "简历篇幅较短，建议补充教育、技能、项目与自我评价模块"})

    score = max(0, 100 - sum({"high": 25, "medium": 12, "low": 5}.get(i["severity"], 0) for i in issues))
    return {
        "health": score,
        "level": "优秀" if score >= 85 else "良好" if score >= 70 else "待完善",
        "issues": issues,
        "profile": profile,
    }


def _use_llm(llm) -> bool:
    try:
        return bool(getattr(llm, "_use_llm", None)) or type(llm).__name__ == "SparkLLM"
    except Exception:  # noqa: BLE001
        return False
