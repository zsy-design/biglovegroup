"""模块2c · 简历模板库与一键套用。

内置多分类模板：应届生/校招/社招进阶/技术岗/产品运营/管理岗/国企公考。
套用时把解析出的候选人画像按模板章节结构自动填充。
"""
from __future__ import annotations

from .parser import parse_resume_text

TEMPLATES = {
    "graduate": {
        "name": "应届生清新模板",
        "category": "应届生",
        "style": "清爽、突出教育背景与校园实践",
        "sections": ["基本信息", "教育背景", "专业技能", "实习与项目经历", "校园经历", "自我评价"],
    },
    "campus": {
        "name": "校招标准模板",
        "category": "校招",
        "style": "经典 HR 友好结构，突出潜质",
        "sections": ["基本信息", "教育背景", "技能清单", "项目经历(STAR)", "荣誉奖项", "个人优势"],
    },
    "social": {
        "name": "社招进阶模板",
        "category": "社招",
        "style": "突出工作业绩与量化成果",
        "sections": ["基本信息", "个人摘要", "工作经历(业绩量化)", "项目案例", "技能栈", "教育背景"],
    },
    "tech": {
        "name": "技术岗模板",
        "category": "技术岗",
        "style": "突出技术栈/项目深度与开源",
        "sections": ["基本信息", "技术栈", "核心项目(架构/难点/成果)", "工作经历", "开源与社区", "教育背景"],
    },
    "product": {
        "name": "产品/运营模板",
        "category": "产品运营",
        "style": "突出用户洞察与数据结果",
        "sections": ["基本信息", "个人简介", "产品/运营经历(数据导向)", "项目复盘", "方法论", "教育背景"],
    },
    "manager": {
        "name": "管理岗模板",
        "category": "管理层",
        "style": "突出团队管理、结果与影响力",
        "sections": ["基本信息", "核心优势", "管理经历(团队规模/成果)", "关键项目", "荣誉与证书", "教育背景"],
    },
    "civil": {
        "name": "国企/公考模板",
        "category": "国企公考",
        "style": "稳重规范，突出政治素养与稳定性",
        "sections": ["基本信息", "教育背景", "政治面貌与奖惩", "工作/实践经历", "资格证书", "自我评价"],
    },
}


def list_templates() -> list:
    return [
        {"key": k, "name": t["name"], "category": t["category"],
         "style": t["style"], "sections": t["sections"]}
        for k, t in TEMPLATES.items()
    ]


def _fill_basic(profile: dict) -> list:
    return [
        f"姓名：{profile['name']}",
        f"院校：{profile['school'] or '—'} ｜ 学历：{profile['degree']} ｜ 专业：{profile['major'] or '—'}",
    ]


def _fill_projects(profile: dict) -> list:
    if not profile.get("projects"):
        return ["- 请补充项目/工作经历（建议按 STAR：背景-任务-行动-结果，并附量化数据）"]
    out = []
    for name, desc in profile["projects"][:4]:
        out.append(f"### {name}")
        out.append(f"- {desc}")
    return out


def _fill_skills(profile: dict) -> list:
    skills = profile.get("skills") or []
    if not skills:
        return ["- 请补充技能标签（便于关键词匹配）"]
    return ["- " + "、".join(skills)]


def apply_template(template_key: str, resume_text: str) -> dict:
    if template_key not in TEMPLATES:
        raise ValueError(f"未知模板: {template_key}")
    tpl = TEMPLATES[template_key]
    profile = parse_resume_text(resume_text)
    sections = tpl["sections"]

    body: list = []
    for sec in sections:
        body.append(f"## {sec}")
        if sec in ("基本信息",):
            body += _fill_basic(profile)
        elif sec in ("专业技能", "技能清单", "技术栈", "技能栈"):
            body += _fill_skills(profile)
        elif sec in ("实习与项目经历", "项目经历(STAR)", "工作经历(业绩量化)",
                     "项目案例", "核心项目(架构/难点/成果)", "产品/运营经历(数据导向)",
                     "工作/实践经历", "管理经历(团队规模/成果)", "关键项目"):
            body += _fill_projects(profile)
        else:
            body.append("- 待填写")
        body.append("")

    text = "\n".join(body).rstrip()
    return {"template": tpl["name"], "category": tpl["category"], "optimized": text}
