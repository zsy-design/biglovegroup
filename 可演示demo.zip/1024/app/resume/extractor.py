"""简历文件解析（模块2a）。

支持 .txt / .md / .pdf / .docx 简历文件上传 -> 提取纯文本 + 清洗。
PDF 用 pypdf，Word 用 python-docx，均可离线运行。
"""
from __future__ import annotations

import io
import re

try:
    from pypdf import PdfReader
except Exception:  # pragma: no cover
    PdfReader = None

try:
    from docx import Document as DocxDocument
except Exception:  # pragma: no cover
    DocxDocument = None


def clean_text(text: str) -> str:
    text = re.sub(r"\r\n", "\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[\u0000-\u0008\u000b\u000c\u000e-\u001f]", "", text)
    return text.strip()


def _extract_txt(data: bytes) -> str:
    for enc in ("utf-8", "gbk", "utf-8-sig", "gb18030"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="ignore")


def _extract_pdf(data: bytes) -> str:
    if PdfReader is None:
        raise RuntimeError("缺少 pypdf 库，无法解析 PDF。请执行: pip install pypdf")
    reader = PdfReader(io.BytesIO(data))
    pages = []
    for page in reader.pages:
        try:
            pages.append(page.extract_text() or "")
        except Exception:  # noqa: BLE001 - 单页失败跳过
            continue
    return "\n".join(pages)


def _extract_docx(data: bytes) -> str:
    if DocxDocument is None:
        raise RuntimeError("缺少 python-docx 库，无法解析 Word。请执行: pip install python-docx")
    doc = DocxDocument(io.BytesIO(data))
    parts = []
    for para in doc.paragraphs:
        if para.text.strip():
            parts.append(para.text)
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            parts.append(" | ".join([c for c in cells if c]))
    return "\n".join(parts)


def extract_text_from_file(filename: str, data: bytes) -> str:
    """根据扩展名解析文件内容并清洗。"""
    ext = (filename or "").rsplit(".", 1)[-1].lower()
    if ext in ("txt", "md", "markdown", "text"):
        text = _extract_txt(data)
    elif ext == "pdf":
        text = _extract_pdf(data)
    elif ext in ("docx", "doc"):
        text = _extract_docx(data)
    else:
        raise ValueError(f"暂不支持的文件类型 .{ext}，请上传 txt / md / pdf / docx")
    if not text or len(text.strip()) < 10:
        raise ValueError("未能从文件中提取到有效文本，请检查文件内容或改用粘贴方式")
    return clean_text(text)
