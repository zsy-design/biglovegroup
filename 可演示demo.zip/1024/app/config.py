"""全局配置。

优先读取环境变量，其次使用默认值。
支持多种大模型：
1. 免费开源模型: 硅基流动(SiliconFlow) - 提供免费的Qwen、GLM等模型
2. 讯飞星火 - 需要付费API Key
3. 其他OpenAI兼容接口
"""
import json
import os
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent


def _load_llm_config_from_file() -> dict:
    """从 data/llm_config.json 加载配置"""
    config_path = BASE_DIR / "data" / "llm_config.json"
    try:
        return json.loads(config_path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


class Settings:
    def __init__(self) -> None:
        # 从配置文件加载
        file_cfg = _load_llm_config_from_file()
        
        # ---- 大模型配置 (OpenAI兼容格式) ----
        # 优先级: 环境变量 > 配置文件 > 默认值
        self.LLM_API_KEY = os.getenv("LLM_API_KEY") or file_cfg.get("api_key", "")
        self.LLM_BASE_URL = os.getenv("LLM_BASE_URL") or file_cfg.get("base_url", "https://api.siliconflow.cn/v1")
        self.LLM_MODEL = os.getenv("LLM_MODEL") or file_cfg.get("model", "Qwen/Qwen2.5-7B-Instruct")
        self.LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "2048"))
        self.LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.7"))
        
        # ---- 讯飞星火大模型 (兼容模式) ----
        self.SPARK_APP_ID = os.getenv("SPARK_APP_ID") or file_cfg.get("app_id", "")
        self.SPARK_API_KEY = os.getenv("SPARK_API_KEY") or file_cfg.get("api_key", "")
        self.SPARK_API_SECRET = os.getenv("SPARK_API_SECRET") or file_cfg.get("api_secret", "")
        self.SPARK_URL = os.getenv("SPARK_URL") or file_cfg.get("base_url", "")
        self.SPARK_DOMAIN = os.getenv("SPARK_DOMAIN") or file_cfg.get("model", "general")
        self.SPARK_MAX_TOKENS = int(os.getenv("SPARK_MAX_TOKENS", "4096"))
        self.SPARK_TEMPERATURE = float(os.getenv("SPARK_TEMPERATURE", "0.7"))

        # ---- 语音合成 (TTS) ----
        self.TTS_PROVIDER = os.getenv("TTS_PROVIDER", "edge")
        self.EDGE_TTS_VOICE = os.getenv("EDGE_TTS_VOICE", "zh-CN-XiaoxiaoNeural")

        # ---- 服务 ----
        self.HOST = os.getenv("HOST", "0.0.0.0")
        self.PORT = int(os.getenv("PORT", "8010"))
        self.STATIC_DIR = BASE_DIR / "static"

        # 面试配置
        self.MAX_INTERVIEW_ROUNDS = int(os.getenv("MAX_INTERVIEW_ROUNDS", "6"))
        self.MIN_ANSWER_LEN = int(os.getenv("MIN_ANSWER_LEN", "8"))

    @property
    def llm_enabled(self) -> bool:
        """检查是否有可用的大模型配置"""
        # 检查OpenAI兼容接口 (如硅基流动)
        if self.LLM_API_KEY and self.LLM_BASE_URL:
            return True
        # 检查讯飞星火
        if self.SPARK_API_KEY and self.SPARK_API_SECRET:
            return True
        return False


settings = Settings()