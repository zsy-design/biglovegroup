"""模块5 · 自动化评估报告生成。

输入: 面试会话(作答记录 + 画像 + 岗位模型)。
输出（全部结构化 JSON，适配前端渲染与 PDF 导出）：
  - 九维能力雷达图数据（专业能力/实操经验/学习能力/沟通表达/逻辑思维/
    抗压能力/岗位匹配度/职业稳定性/综合潜力）
  - 候选人画像 / 岗位匹配分析 / 优势亮点 / 短板风险 / 面试表现复盘
  - 胜任力评级(A/B/C/D) / 录用建议 / 改进提升方案 / 简历优化建议 / 备考建议
  - 反作弊与真实度风险识别
LLM 可用时润色文案，否则规则模板兜底，均保证结构化输出。
"""
from __future__ import annotations

import json
import re
from collections import defaultdict
from typing import Dict, List

from ..competency.model import COMPETENCY_DIMENSIONS, JobModel
from ..competency.nine import NINE_DIMENSIONS, SCORE_MAP, nine_weights_from_six
from ..config import settings
from ..interview.engine import InterviewSession
from ..llm import BaseLLM, Message
from ..resume.parser import match_best_job

MAX_DIM_SCORE = 5.0

_GENERIC_PLATITUDE = re.compile(
    r"(我觉得自己?很?(优秀|努力|负责|有责任心)|学习能力(比较|非常)*强|"
    r"我性格开朗|认真踏实|有较强的.{0,6}能力)"
)


class ReportBuilder:
    def __init__(self, session: InterviewSession) -> None:
        self.session = session
        self.job: JobModel = session.job
        self.profile: dict = session.profile
        self.records: List[dict] = session.answer_records

    # ------------------------------------------------------------------
    # 六维考察得分（来自作答记录）
    # ------------------------------------------------------------------
    def _dimension_scores(self) -> Dict[str, float]:
        grouped: Dict[str, list] = defaultdict(list)
        for rec in self.records:
            grouped[rec["dimension"]].append(rec["score"])
        scores = {}
        for dim in COMPETENCY_DIMENSIONS:
            values = grouped.get(dim) or [2.5]
            if len(values) > 1:
                values = sorted(values)[1:]
            scores[dim] = round(sum(values) / len(values), 2)
        return scores

    # ------------------------------------------------------------------
    # 九维评估得分
    # ------------------------------------------------------------------
    def _resume_job_match(self) -> float:
        _, _, ranking = match_best_job(self.profile)
        for key, score in ranking:
            if key == self.job.key:
                return round(float(score), 3)
        return 0.5

    def _nine_scores(self, six_scores: Dict[str, float]) -> Dict[str, float]:
        base = {SCORE_MAP[d]: six_scores[d] for d in SCORE_MAP if d in six_scores}
        six_overall = self._overall6(six_scores)
        # 岗位匹配度：简历匹配(0~1)*5 与面试综合表现加权
        match = self._resume_job_match()
        nine = {
            "专业能力": base.get("专业能力", 2.5),
            "实操经验": base.get("实操经验", 2.5),
            "学习能力": base.get("学习能力", 2.5),
            "沟通表达": base.get("沟通表达", 2.5),
            "逻辑思维": base.get("逻辑思维", 2.5),
            "抗压能力": base.get("抗压能力", 2.5),
            "岗位匹配度": round(match * 5 * 0.7 + six_overall * 0.3, 2),
            "职业稳定性": self._stability(),
            "综合潜力": round(six_scores.get("学习能力", 2.5) * 0.6 + six_overall * 0.4, 2),
        }
        return {k: round(min(MAX_DIM_SCORE, max(0.5, v)), 2) for k, v in nine.items()}

    def _stability(self) -> float:
        score = 3.2
        years = 0.0
        m = re.search(r"(\d+(?:\.\d+)?)\s*年(?:经验|工作经验)", self.profile.get("raw") or "")
        if m:
            years = float(m.group(1))
        if years >= 3:
            score += 1.0
        elif years >= 1:
            score += 0.6
        if self.profile.get("degree") in ("硕士", "博士"):
            score += 0.4
        if self.profile.get("projects"):
            score += 0.4
        return round(min(5.0, score), 2)

    def _overall6(self, six_scores: Dict[str, float]) -> float:
        total_w = sum(self.job.weights.values()) or 1.0
        return round(
            sum(six_scores[d] * self.job.weight(d) for d in COMPETENCY_DIMENSIONS) / total_w, 2
        )

    def _nine_weights(self) -> Dict[str, float]:
        return nine_weights_from_six(self.job.weights)

    def _overall(self, nine_scores: Dict[str, float], nine_weights: Dict[str, float]) -> float:
        return round(
            sum(nine_scores[d] * nine_weights[d] for d in NINE_DIMENSIONS), 2
        )

    def _completeness(self) -> float:
        asked = len(self.records)
        return round(min(1.0, asked / max(settings.MAX_INTERVIEW_ROUNDS, 1)), 2)

    # ------------------------------------------------------------------
    # 反作弊 / 真实度判别
    # ------------------------------------------------------------------
    def _risk_analysis(self, six_scores: Dict[str, float]) -> List[str]:
        risk: List[str] = []
        thin = [r for r in self.records if len(r["answer"]) < 20]
        if thin:
            risk.append(f"有 {len(thin)} 道题回答过于简短，真实性存疑，建议追问核实")
        platitude = [r["question"][:20] for r in self.records if _GENERIC_PLATITUDE.search(r["answer"])]
        if platitude:
            risk.append("个别回答使用套话/主观评价（如「学习能力强」），缺少事实与数据支撑")
        no_evidence = [r for r in self.records
                       if len(r["answer"]) >= 30 and not re.search(r"\d+%|\d+人|\d+万|其次|首先|负责|主导", r["answer"])]
        if no_evidence:
            risk.append("部分回答停留在概念层面，未给出具体做法、个人角色或量化结果，存在「信息注水」风险")
        if self.records and max(r["score"] for r in self.records) < 3.0:
            risk.append("整体作答深度偏低，简历与口头表达可能存在差距")
        return risk or ["未发现明显失实风险，作答与履历较一致"]

    # ------------------------------------------------------------------
    # 文本报告
    # ------------------------------------------------------------------
    def _text_report(self, nine_scores: Dict[str, float], six_scores: Dict[str, float],
                     overall: float, risk: List[str]) -> dict:
        strong = sorted(nine_scores.items(), key=lambda kv: kv[1], reverse=True)[:2]
        weak = sorted(nine_scores.items(), key=lambda kv: kv[1])[:2]

        strengths = [
            f"{k}表现突出（得分 {v:.1f}/5）" for k, v in strong if v >= 3.0
        ] or ["各维度发挥均衡，无明显短板"]
        strengths.append("对岗位核心问题基本能给出生动、有结构的回答")

        weaknesses = [
            f"{k}仍需加强（得分 {v:.1f}/5）" for k, v in weak if v < 3.5
        ] or ["整体表现中规中矩，缺乏亮点"]
        if six_scores.get("专业知识", 5) < 4:
            weaknesses.append("专业细节深度不足，追问下暴露出知识体系的不完整")

        level = "高度匹配" if overall >= 4.0 else "比较匹配" if overall >= 3.0 else "存在差距"

        # 面试表现复盘
        dims_covered = len(set(r["dimension"] for r in self.records if r["dimension"] not in ("开场",)))
        review = [
            f"完成 {len(self.records)} 轮结构化问答，覆盖 {dims_covered} 个考察维度",
            "回答总体结构完整，能围绕项目/经历展开" if any(len(r['answer']) >= 60 for r in self.records)
            else "多数回答较简短，建议展开细节与过程",
        ]
        if risk and "未发现" not in risk[0]:
            review.append("存在少量需进一步核实的作答，已在风险提示中标注")

        # 评级与录用建议
        rating = "A" if overall >= 4.4 else "B" if overall >= 3.6 else "C" if overall >= 2.6 else "D"
        decision = "建议录用" if overall >= 4.0 else "待定，需对比其他候选人" if overall >= 3.0 else "不建议录用"

        return {
            "summary": (
                f"候选人对「{self.job.name}」岗位{level}，综合胜任力得分 {overall:.1f}/5.0，"
                f"评级 {rating}。简历与岗位关键词的匹配度较高，面试中在 {strong[0][0] if strong else '综合'} 维度表现最好。"
            ),
            "strengths": strengths,
            "weaknesses": weaknesses,
            "suggestions": [
                f"针对「{weak[0][0]}」维度进行专项训练与案例沉淀",
                "将项目经历按 STAR 法则整理，突出个人角色与量化成果",
                "提前演练岗位高频面试题与压力追问，提升临场表达",
            ],
            "review": review,
            "risk": risk,
            "resume_advice": [
                "为每段经历补充 1-2 个量化指标（占比/次数/规模/收益）",
                "在简历头部增加与岗位强相关的关键词，提升筛选命中",
                "删除空泛自我评价，替换为可验证的事实表述",
            ],
            "prep_advice": [
                "围绕岗位核心技能准备 3 个深度项目案例，每个能讲清难点与结果",
                "复习专业知识深挖点，避免停留在概念层面",
                "准备 2 个向面试官反问的问题，体现主动性与思考深度",
            ],
            "decision": decision,
            "rating": rating,
            "level": level,
        }

    def _llm_polish(self, text_data: dict, scores: Dict[str, float], overall: float) -> dict:
        llm: BaseLLM = self.session.llm
        payload = {
            "job": self.job.name,
            "dimensions": scores,
            "overall": overall,
            "base": {k: text_data[k] for k in ("summary", "strengths", "weaknesses", "suggestions")},
        }
        try:
            result = llm.chat(
                [
                    Message("system", (
                        "【报告】你是资深 HR 与岗位胜任力专家。根据候选人的量化得分与基础结论，"
                        "生成一份专业评估报告文案，必须返回 JSON: "
                        '{"summary": str, "strengths": [str], "weaknesses": [str], "suggestions": [str]}'
                    )),
                    Message("user", json.dumps(payload, ensure_ascii=False)),
                ],
                temperature=0.5,
                max_tokens=600,
            )
            data = json.loads(result.content)
            if all(k in data for k in ("summary", "strengths", "weaknesses", "suggestions")):
                text_data = {**text_data, **data}
        except Exception:  # noqa: BLE001 - 失败回退规则模板
            pass
        return text_data

    # ------------------------------------------------------------------
    # 多模态面试数据(语音/行为分析) —— 参考程序"多模态分析"移植
    # ------------------------------------------------------------------
    def _multimodal(self) -> dict:
        mm = getattr(self.session, "multimodal_summary", lambda: {})()
        samples = mm.get("samples", [])
        avg_rate = mm.get("avg_speech_rate") or 0
        avg_pause = mm.get("avg_pause_count") or 0
        avg_dur = mm.get("avg_duration_ms") or 0

        notes = []
        if avg_rate >= 180:
            notes.append("语速偏快（约 {} 字/分），建议放缓节奏、突出重点".format(avg_rate))
        elif avg_rate and avg_rate < 100:
            notes.append("语速偏慢（约 {} 字/分），可能与对内容不够熟练相关".format(avg_rate))
        elif avg_rate:
            notes.append("语速适中（约 {} 字/分），表达流畅".format(avg_rate))
        if avg_pause:
            notes.append(
                "每答平均停顿 {} 次，停顿偏多可能反映思路组织紧张".format(avg_pause)
                if avg_pause > 3 else "停顿次数正常（平均 {} 次）".format(avg_pause)
            )
        if avg_dur:
            notes.append("平均每题回答约 {:.1f} 秒，{}".format(
                avg_dur / 1000.0, "信息量充足" if avg_dur >= 15000 else "信息量一般，可再充实"))
        notes.append("从文本深度看，{}".format(
            "能给出结构化、有量化结果的回答" if any(r["score"] >= 3 for r in self.records) else "回答以概念表述为主，建议补充细节"))

        return {
            "answer_count": mm.get("answers", len(self.records)),
            "avg_speech_rate": avg_rate,
            "avg_pause_count": avg_pause,
            "avg_duration_sec": round(avg_dur / 1000.0, 1),
            "notes": notes,
            "per_question": [
                {"dimension": s["dimension"], "score": s["score"],
                 "level": (s.get("metrics") or {}) and self._level(s["score"])}
                for s in samples
            ],
        }

    def _level(self, score: float) -> str:
        return "优秀" if score >= 4 else "良好" if score >= 3 else "一般" if score >= 2 else "较弱"

    # ------------------------------------------------------------------
    # 对外入口
    # ------------------------------------------------------------------
    def build(self) -> dict:
        six_scores = self._dimension_scores()
        nine_scores = self._nine_scores(six_scores)
        nine_weights = self._nine_weights()
        risk = self._risk_analysis(six_scores)
        text_data = self._text_report(nine_scores, six_scores, self._overall(nine_scores, nine_weights), risk)
        text_data = self._llm_polish(text_data, nine_scores, self._overall(nine_scores, nine_weights))

        overall = self._overall(nine_scores, nine_weights)
        text_data["multimodal"] = self._multimodal()
        return {
            "candidate": {
                "name": self.profile.get("name", "候选人"),
                "school": self.profile.get("school", ""),
                "degree": self.profile.get("degree", ""),
                "major": self.profile.get("major", ""),
                "skills": self.profile.get("skills", []),
                "projects": self.profile.get("projects", []),
            },
            "job": {"key": self.job.key, "name": self.job.name},
            "radar": {
                "dimensions": NINE_DIMENSIONS,
                "scores": [nine_scores[d] for d in NINE_DIMENSIONS],
            },
            "nine_scores": [
                {"dimension": d, "score": nine_scores[d], "weight": round(nine_weights[d], 3)}
                for d in NINE_DIMENSIONS
            ],
            "match_score": overall,
            "match_percent": round(overall / MAX_DIM_SCORE * 100),
            "completeness": self._completeness(),
            "question_count": len(self.records),
            "rating": text_data["rating"],
            "decision": text_data["decision"],
            "report": text_data,
        }


def generate_report(session: InterviewSession) -> dict:
    return ReportBuilder(session).build()