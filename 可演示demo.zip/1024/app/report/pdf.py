"""模块5 · 评估报告 PDF 导出。

用 reportlab 生成可直接用于商业交付的专业评估报告（中文 + 雷达图 + 评分表）。
无需外部字体文件（内置 STSong-Light CID 中文字体）。
"""
from __future__ import annotations

import io
import math

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.platypus import (
    Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
)
from reportlab.graphics import renderPDF
from reportlab.graphics.shapes import Drawing, Line, Polygon, Circle

pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))

BLUE = colors.HexColor("#1f3a8a")
LIGHT = colors.HexColor("#eaf1ff")
GREY = colors.HexColor("#6b7280")


class RadarDrawing(Drawing):
    """在 PDF 中绘制九维雷达图"""

    def __init__(self, dims, scores, width=280, height=250):
        super().__init__(width, height)
        n = len(dims)
        maxv = 5
        cx, cy, R = width / 2, height / 2, min(width, height) / 2 - 30
        self.add(Circle(cx, cy, R, strokeColor=BLUE, strokeWidth=0.8, fillColor=None))

        def pt(i, r):
            ang = -math.pi / 2 + 2 * math.pi * i / n
            return (cx + r * math.cos(ang), cy + r * math.sin(ang))

        # 网格环
        for ring in range(1, maxv + 1):
            pts = []
            for i in range(n):
                x, y = pt(i, R * ring / maxv)
                pts.extend([x, y])
            self.add(Polygon(pts, strokeColor=LIGHT, strokeWidth=0.5, fillColor=None))
        # 轴线 + 标签
        for i in range(n):
            x1, y1 = pt(i, R)
            self.add(Line(cx, cy, x1, y1, strokeColor=LIGHT, strokeWidth=0.8))
            lx, ly = pt(i, R + 22)
            from reportlab.graphics.shapes import String
            self.add(String(lx, ly, dims[i], fontSize=8, fillColor=GREY,
                            textAnchor="middle", fontName="STSong-Light"))
        # 得分多边形
        pts = []
        for i in range(n):
            x, y = pt(i, R * max(0.1, scores[i]) / maxv)
            pts.extend([x, y])
        self.add(Polygon(pts, strokeColor=BLUE, strokeWidth=1.6, fillColor=colors.HexColor("#2563eb22")))
        for i in range(n):
            x, y = pt(i, R * max(0.1, scores[i]) / maxv)
            self.add(Circle(x, y, 2.6, fillColor=BLUE, strokeColor=colors.white, strokeWidth=1))


def build_report_pdf(report: dict) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=20 * mm, rightMargin=20 * mm,
                            topMargin=18 * mm, bottomMargin=18 * mm,
                            title="岗位胜任力评估报告")
    styles = getSampleStyleSheet()
    H1 = ParagraphStyle("H1", parent=styles["Title"], fontName="STSong-Light",
                        fontSize=17, textColor=BLUE, spaceAfter=2)
    H2 = ParagraphStyle("H2", parent=styles["Heading2"], fontName="STSong-Light",
                        fontSize=12, textColor=BLUE, spaceBefore=10, spaceAfter=4)
    BODY = ParagraphStyle("BODY", parent=styles["BodyText"], fontName="STSong-Light",
                          fontSize=10, leading=16, textColor=colors.HexColor("#1f2937"))
    META = ParagraphStyle("META", parent=BODY, fontSize=8.5, textColor=GREY)
    kv = report.get("candidate", {})
    job = report.get("job", {})
    rpt = report.get("report", {})

    story = []
    story.append(Paragraph("岗位胜任力评估报告", H1))
    story.append(Paragraph(f"目标岗位：{job.get('name', '')} ｜ 生成系统：讯飞1024 · AI人才测评", META))
    story.append(Spacer(1, 6))

    # 候选人信息
    cand_rows = [
        ["候选人", kv.get("name", ""), "学历", kv.get("degree", ""), "院校", kv.get("school", "")],
        ["专业", kv.get("major", ""), "技能标签", "、".join(kv.get("skills", [])) or "—", "项目数", f"{len(kv.get('projects', []))} 项"],
    ]
    t = Table(cand_rows, colWidths=[42, 88, 42, 88, 42, 82])
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "STSong-Light"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("BACKGROUND", (0, 0), (0, -1), LIGHT),
        ("BACKGROUND", (2, 0), (2, -1), LIGHT),
        ("BACKGROUND", (4, 0), (4, -1), LIGHT),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#d3ddef")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(t)

    story.append(Paragraph("一、评估结论", H2))
    story.append(Paragraph(
        f"{rpt.get('summary', '')} <br/>胜任力评级：<b>{rpt.get('rating', '')}</b> ｜ "
        f"录用建议：<b>{rpt.get('decision', '')}</b> ｜ "
        f"整体得分：{report.get('match_score', 0):.1f}/5.0（匹配度 {report.get('match_percent', 0)}%）",
        BODY,
    ))

    # 九维雷达 + 评分表
    story.append(Paragraph("二、九维胜任力评估", H2))
    radar = report.get("radar", {})
    dims = radar.get("dimensions", [])
    scores = radar.get("scores", [])
    if dims and scores:
        story.append(RadarDrawing(dims, scores))
    story.append(Spacer(1, 4))
    nine = report.get("nine_scores", [])
    ns_rows = [["维度", "得分(/5)", "星级", "权重", "维度", "得分(/5)", "星级", "权重"]]
    for i in range(0, len(nine), 2):
        row = []
        for item in nine[i:i + 2]:
            stars = "★" * max(1, round(item["score"])) + "☆" * max(0, 5 - round(item["score"]))
            row += [item["dimension"], f"{item['score']:.1f}", stars, f"{item['weight']:.0%}"]
        while len(row) < 8:
            row += ["", "", "", ""]
        ns_rows.append(row)
    nt = Table(ns_rows, colWidths=[58, 46, 74, 44, 58, 46, 74, 44])
    nt.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "STSong-Light"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("BACKGROUND", (0, 0), (-1, 0), BLUE),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#d3ddef")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 1), (-1, -1), "CENTER"),
    ]))
    story.append(nt)

    def section(title, items):
        chain = [Paragraph(title, H2)]
        for it in (items or []):
            chain.append(Paragraph(f"• {it}", BODY))
        chain.append(Spacer(1, 2))
        return chain

    story += section("三、优势亮点", rpt.get("strengths"))
    story += section("四、短板与风险提示", rpt.get("weaknesses") + rpt.get("risk", []))
    story += section("五、面试表现复盘", rpt.get("review"))
    story += section("六、改进提升方案", rpt.get("suggestions"))
    story += section("七、简历优化建议", rpt.get("resume_advice"))
    story += section("八、面试备考建议", rpt.get("prep_advice"))

    story.append(Spacer(1, 8))
    story.append(Paragraph(
        "报告说明：本报告基于简历画像与多轮结构化面试自动生成，"
        "供人才测评与招聘参考。数据含「岗位匹配度 / 胜任力评级 / 录用建议」等维度，可作为商业交付材料。",
        META,
    ))

    doc.build(story)
    return buf.getvalue()