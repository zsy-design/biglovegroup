#!/usr/bin/env python3
"""
生成20页PPT演示文稿
岗位胜任力多轮问询与评估报告生成·面试智能体
"""
import os
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE


def set_slide_background(slide, color):
    """设置幻灯片背景色"""
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(*color)


def add_title_box(slide, text, left=Inches(0.5), top=Inches(0.3), width=Inches(9), height=Inches(0.8), font_size=28, bold=True, color=(21, 101, 192)):
    """添加标题文本框"""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.font.color.rgb = RGBColor(*color)
    p.font.name = '微软雅黑'
    return txBox


def add_content_box(slide, text, left=Inches(0.5), top=Inches(1.3), width=Inches(9), height=Inches(5.5), font_size=16, color=(51, 51, 51)):
    """添加内容文本框"""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.color.rgb = RGBColor(*color)
    p.font.name = '微软雅黑'
    p.line_spacing = Pt(24)
    return txBox


def add_bullet_points(slide, items, left=Inches(0.5), top=Inches(1.3), width=Inches(9), height=Inches(5.5), font_size=16, color=(51, 51, 51)):
    """添加项目符号列表"""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    
    for i, item in enumerate(items):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.text = f"• {item}"
        p.font.size = Pt(font_size)
        p.font.color.rgb = RGBColor(*color)
        p.font.name = '微软雅黑'
        p.line_spacing = Pt(28)
    
    return txBox


def add_shape_box(slide, left, top, width, height, fill_color, text="", font_size=12, font_color=(255, 255, 255)):
    """添加形状框"""
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = RGBColor(*fill_color)
    shape.line.fill.background()
    
    if text:
        tf = shape.text_frame
        tf.word_wrap = True
        tf.paragraphs[0].alignment = PP_ALIGN.CENTER
        tf.paragraphs[0].text = text
        tf.paragraphs[0].font.size = Pt(font_size)
        tf.paragraphs[0].font.color.rgb = RGBColor(*font_color)
        tf.paragraphs[0].font.name = '微软雅黑'
        tf.paragraphs[0].font.bold = True
    
    return shape


def create_ppt():
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)
    
    # ========== 第1页：封面 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # 空白布局
    set_slide_background(slide, (21, 101, 192))  # 深蓝色背景
    
    add_title_box(slide, "岗位胜任力多轮问询与评估报告生成", 
                  top=Inches(2), font_size=36, color=(255, 255, 255))
    add_title_box(slide, "面试智能体", 
                  top=Inches(3), font_size=40, color=(255, 255, 255))
    add_content_box(slide, "2026 iFLYTEK AI开发者大赛 工程开发赛道", 
                    top=Inches(4.5), font_size=20, color=(187, 222, 251))
    add_content_box(slide, "简历画像 → 多轮情景化问询 → 九维胜任力评估报告", 
                    top=Inches(5.2), font_size=16, color=(187, 222, 251))
    
    # ========== 第2页：国家政策背景 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "国家政策背景")
    
    items = [
        "《"十四五"就业促进规划》：推动人工智能在招聘领域的应用",
        "《关于推进"互联网+"人社建设的指导意见》：加快数字化转型",
        "《人工智能产业发展行动计划》：支持AI+招聘场景创新",
        "《高校毕业生就业创业工作通知》：提升就业服务质量",
        "教育部：鼓励高校开展智能化就业指导服务",
        "人社部：推进"智慧人社"建设，提升公共服务水平"
    ]
    add_bullet_points(slide, items)
    
    add_content_box(slide, "国家高度重视就业问题，鼓励AI技术在招聘领域的创新应用，为智能面试系统的发展提供了政策支持。", 
                    top=Inches(5.8), font_size=14, color=(100, 100, 100))
    
    # ========== 第3页：市场分析调研 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "市场分析调研")
    
    # 添加市场数据框
    add_shape_box(slide, Inches(0.5), Inches(1.3), Inches(2.8), Inches(1.5), 
                  (21, 101, 192), "市场规模\n2026年预计达500亿", 14)
    add_shape_box(slide, Inches(3.6), Inches(1.3), Inches(2.8), Inches(1.5), 
                  (46, 125, 50), "年增长率\n25%+", 14)
    add_shape_box(slide, Inches(6.7), Inches(1.3), Inches(2.8), Inches(1.5), 
                  (230, 81, 0), "企业需求\n85%企业希望使用", 14)
    
    items = [
        "全球AI面试市场规模：2025年达420亿美元",
        "中国市场：2024年规模约320亿元人民币",
        "增长率：年复合增长率超过25%",
        "企业需求：85%的企业表示愿意采用AI面试工具",
        "痛点：现有产品70%停留在单模态方案",
        "机会：多模态融合、个性化追问成为新趋势"
    ]
    add_bullet_points(slide, items, top=Inches(3.2))
    
    # ========== 第4页：痛点分析 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "痛点分析")
    
    # 传统面试痛点
    add_shape_box(slide, Inches(0.5), Inches(1.3), Inches(4.3), Inches(2.5), 
                  (211, 47, 47), "传统面试痛点", 16)
    items1 = [
        "主观性强：跨面试官评分差异达42%",
        "效率低下：单次面试耗时3.5人时",
        "标准不统一：缺乏科学评估体系",
        "信息不对称：供需双方认知差异大"
    ]
    add_bullet_points(slide, items1, left=Inches(0.7), top=Inches(2), width=Inches(4), height=Inches(2), font_size=13)
    
    # 现有AI面试痛点
    add_shape_box(slide, Inches(5.2), Inches(1.3), Inches(4.3), Inches(2.5), 
                  (230, 81, 0), "现有AI面试痛点", 16)
    items2 = [
        "单模态：仅支持文本或语音",
        "固定题库：缺乏个性化追问",
        "评估单一：维度不够全面",
        "中文支持差：国际产品本地化不足"
    ]
    add_bullet_points(slide, items2, left=Inches(5.4), top=Inches(2), width=Inches(4), height=Inches(2), font_size=13)
    
    add_content_box(slide, "结论：市场迫切需要一款支持多模态、个性化追问、九维评估的智能面试系统", 
                    top=Inches(5.5), font_size=16, color=(21, 101, 192))
    
    # ========== 第5页：项目介绍（解决方案） ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "解决方案 - 项目介绍")
    
    add_content_box(slide, "岗位胜任力多轮问询与评估报告生成·面试智能体", 
                    top=Inches(1.3), font_size=20, color=(21, 101, 192))
    
    items = [
        "全流程闭环：JD解析 → 简历处理 → 多轮面试 → 评估报告",
        "LLM驱动：基于大语言模型的智能追问引擎",
        "九维评估：基于冰山模型的科学评估框架",
        "拟人化面试官：3D数字人+语音合成技术",
        "离线可用：MockLLM本地规则引擎，无需网络",
        "多用户管理：学生/企业/管理员三种角色",
        "16+岗位覆盖：全行业胜任力模型"
    ]
    add_bullet_points(slide, items, top=Inches(2.2))
    
    # ========== 第6页：技术架构 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "技术架构")
    
    # 分层架构图
    layers = [
        ("前端展示层", "HTML/CSS/JavaScript + Three.js + Web Speech API", (187, 222, 251)),
        ("API网关层", "FastAPI RESTful Service (15+ API)", (200, 230, 201)),
        ("业务逻辑层", "JD解析 | 简历处理 | 面试引擎 | 九维评估 | 报告生成", (255, 224, 178)),
        ("AI服务层", "讯飞星火4.0 | OpenAI兼容 | MockLLM | TTS语音合成", (225, 190, 231)),
        ("数据存储层", "SQLite + JSON配置文件 + VRM模型文件", (189, 224, 229)),
    ]
    
    for i, (name, desc, color) in enumerate(layers):
        y = Inches(1.3 + i * 1.15)
        add_shape_box(slide, Inches(0.5), y, Inches(9), Inches(1), 
                      color, f"{name}: {desc}", 14, (0, 0, 0))
    
    # ========== 第7页：核心技术 - JD解析 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "核心技术 - 岗位JD智能解析")
    
    items = [
        "岗位类型识别：17个正则规则覆盖主流岗位",
        "需求抽取：学历、经验、职责、加分项自动提取",
        "核心技能抽取：9大类50+关键词匹配",
        "难度评估：基于经验年限、学历、技能数量综合评分",
        "面试题库生成：内置岗位使用结构化题库，自定义JD使用通用题库",
        "动态岗位模型：JD直接转化为JobModel，驱动面试引擎"
    ]
    add_bullet_points(slide, items)
    
    # ========== 第8页：核心技术 - 简历处理 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "核心技术 - 简历智能处理")
    
    items = [
        "多格式支持：PDF/Word/TXT/MD四种格式",
        "智能画像：规则+技能词典的混合解析",
        "岗位匹配：计算简历与每个内置岗位的匹配度",
        "AI简历优化：确定性优化+LLM优化",
        "风险检测：5类问题检测（缺乏量化/项目缺失/角色模糊/空泛表述/信息单薄）",
        "模板库：7类模板覆盖不同场景"
    ]
    add_bullet_points(slide, items)
    
    # ========== 第9页：核心技术 - 多轮面试 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "核心技术 - 多轮面试对话引擎")
    
    items = [
        "有限状态机：管理面试完整生命周期",
        "面试计划生成：按岗位权重排序维度，个性化选题",
        "智能追问机制：回答过短→追问展开 / 有预设追问→深挖 / 深度足够→换题",
        "LLM自然化改写：模板追问→LLM口语化改写",
        "作答打分：启发式评分（满分5.0），检测长度、结构、量化、角色词",
        "实时评估：每题即时反馈评分和评语"
    ]
    add_bullet_points(slide, items)
    
    # ========== 第10页：核心技术 - 九维评估 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "核心技术 - 九维胜任力评估")
    
    # 九维表格
    dimensions = [
        ("专业能力", "岗位核心技术能力"),
        ("实操经验", "实际问题处理与工程落地"),
        ("学习能力", "学习意愿与成长潜力"),
        ("沟通表达", "表达、协作与团队贡献"),
        ("逻辑思维", "结构化思考与问题拆解"),
        ("抗压能力", "责任心、抗压、自驱"),
        ("岗位匹配度", "简历+面试综合匹配"),
        ("职业稳定性", "稳定性评估"),
        ("综合潜力", "成长潜力"),
    ]
    
    for i, (dim, desc) in enumerate(dimensions):
        row = i // 3
        col = i % 3
        x = Inches(0.5 + col * 3.2)
        y = Inches(1.3 + row * 1.3)
        add_shape_box(slide, x, y, Inches(3), Inches(1.1), 
                      (21, 101, 192), f"{dim}\n{desc}", 12)
    
    # ========== 第11页：功能创新点1 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "功能创新点（一）")
    
    items = [
        "动态岗位模型：任意JD粘贴即可生成个性化面试",
        "LLM驱动追问：基于大语言模型的自然化追问",
        "离线可运行：MockLLM规则引擎，无网络无Key也能演示",
        "三级降级TTS：讯飞TTS→Edge TTS→浏览器Web Speech",
        "3D数字人：VRM模型+程序化驱动（眨眼/口型/皱眉/点头）",
        "反作弊检测：识别空洞回答、套话、无实例、信息注水"
    ]
    add_bullet_points(slide, items)
    
    # ========== 第12页：功能创新点2 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "功能创新点（二）")
    
    items = [
        "七类简历模板：应届生/校招/社招/技术岗/产品/管理/国企",
        "AI简历优化：STAR法则+量化指标检测",
        "多模态分析：语音/行为指标融入评估报告",
        "PDF商业交付：reportlab生成含雷达图的专业PDF",
        "三角色系统：学生/企业/管理员，数据按用户隔离",
        "16+岗位覆盖：从IT到机械到金融到医药"
    ]
    add_bullet_points(slide, items)
    
    # ========== 第13页：市场对比分析 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "市场对比分析")
    
    # 对比表格标题行
    add_shape_box(slide, Inches(0.3), Inches(1.3), Inches(1.8), Inches(0.6), 
                  (100, 100, 100), "特性", 12)
    add_shape_box(slide, Inches(2.2), Inches(1.3), Inches(1.6), Inches(0.6), 
                  (21, 101, 192), "本系统", 12)
    add_shape_box(slide, Inches(3.9), Inches(1.3), Inches(1.6), Inches(0.6), 
                  (100, 100, 100), "HireVue", 12)
    add_shape_box(slide, Inches(5.6), Inches(1.3), Inches(1.6), Inches(0.6), 
                  (100, 100, 100), "国内方案A", 12)
    add_shape_box(slide, Inches(7.3), Inches(1.3), Inches(1.6), Inches(0.6), 
                  (100, 100, 100), "国内方案B", 12)
    
    comparisons = [
        ("LLM追问", "支持", "不支持", "不支持", "不支持"),
        ("动态岗位", "支持", "不支持", "不支持", "不支持"),
        ("九维评估", "支持", "不支持", "支持", "不支持"),
        ("离线运行", "支持", "不支持", "不支持", "支持"),
        ("多用户", "支持", "支持", "支持", "支持"),
        ("反作弊", "支持", "支持", "不支持", "不支持"),
        ("中文优化", "支持", "不支持", "支持", "支持"),
    ]
    
    for i, (feat, *vals) in enumerate(comparisons):
        y = Inches(2 + i * 0.65)
        add_shape_box(slide, Inches(0.3), y, Inches(1.8), Inches(0.55), 
                      (240, 240, 240), feat, 11, (0, 0, 0))
        colors = [(200, 230, 201) if v == "支持" else (255, 205, 210) for v in vals]
        for j, (val, color) in enumerate(zip(vals, colors)):
            add_shape_box(slide, Inches(2.2 + j * 1.7), y, Inches(1.6), Inches(0.55), 
                          color, val, 11, (0, 0, 0))
    
    # ========== 第14页：系统优势总结 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "系统优势总结")
    
    items = [
        "全链路闭环：从JD解析到面试到报告，一条命令端到端演示",
        "智能化程度高：LLM驱动的个性化追问，深挖候选人能力",
        "评估科学全面：九维量化评估，基于冰山模型与能力素质词典",
        "部署简单便捷：离线可运行，无需复杂配置",
        "用户体验优秀：3D数字人+语音合成，拟人化面试体验",
        "安全可靠：反作弊检测+数据隔离+密码哈希"
    ]
    add_bullet_points(slide, items)
    
    # ========== 第15页：应用价值1 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "应用价值")
    
    # 价值卡片
    values = [
        ("企业价值", "降低招聘成本50%\n提升招聘效率3倍\n减少主观偏见", (21, 101, 192)),
        ("学生价值", "获得客观评估反馈\n提升面试技能\n了解岗位要求", (46, 125, 50)),
        ("社会价值", "促进就业公平\n推动数字化转型\n培养AI人才", (230, 81, 0)),
    ]
    
    for i, (title, desc, color) in enumerate(values):
        x = Inches(0.5 + i * 3.2)
        add_shape_box(slide, x, Inches(1.5), Inches(3), Inches(4), 
                      color, f"{title}\n\n{desc}", 16)
    
    # ========== 第16页：应用价值2 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "应用场景")
    
    items = [
        "校园招聘：大规模批量面试，提升招聘效率",
        "社会招聘：初筛面试，节省HR时间",
        "人才测评：岗位胜任力评估，科学选人",
        "培训辅导：面试技巧培训，提升求职能力",
        "教育科研：教学演示，AI面试研究",
        "远程面试：不受地域限制，随时随地面试"
    ]
    add_bullet_points(slide, items)
    
    # ========== 第17页：团队介绍 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "团队介绍")
    
    members = [
        ("项目负责人", "整体架构设计\n技术选型", (21, 101, 192)),
        ("后端开发", "FastAPI开发\nLLM集成", (46, 125, 50)),
        ("前端开发", "界面设计\n3D数字人", (230, 81, 0)),
        ("算法研究", "评估模型\nNLP算法", (156, 39, 176)),
    ]
    
    for i, (role, desc, color) in enumerate(members):
        x = Inches(0.3 + i * 2.5)
        add_shape_box(slide, x, Inches(1.5), Inches(2.3), Inches(3.5), 
                      color, f"{role}\n\n{desc}", 14)
    
    add_content_box(slide, "团队成员：具备AI、NLP、Web开发、产品设计等多领域专业知识", 
                    top=Inches(5.5), font_size=14, color=(100, 100, 100))
    
    # ========== 第18页：未来规划1 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "未来规划（近期）")
    
    items = [
        "完善多模态分析：集成视频分析能力，实现表情、动作识别",
        "优化评估模型：基于历史数据优化九维评估算法",
        "增强反作弊：引入更复杂的作弊检测算法",
        "扩展岗位库：增加更多行业的岗位模型",
        "移动端适配：开发移动端应用，支持随时随地面试"
    ]
    add_bullet_points(slide, items)
    
    add_content_box(slide, "规划周期：3-6个月", 
                    top=Inches(5.8), font_size=14, color=(100, 100, 100))
    
    # ========== 第19页：未来规划2 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title_box(slide, "未来规划（中长期）")
    
    items = [
        "生态链建设：与招聘平台对接，提供API服务",
        "企业定制：支持企业自定义评估维度和权重",
        "数据分析：提供招聘数据分析和洞察功能",
        "国际化：支持多语言面试，拓展国际市场",
        "AI原生：构建AI原生的招聘生态系统",
        "行业标准：推动智能面试行业标准的建立"
    ]
    add_bullet_points(slide, items)
    
    add_content_box(slide, "规划周期：6个月-3年", 
                    top=Inches(5.8), font_size=14, color=(100, 100, 100))
    
    # ========== 第20页：谢谢 ==========
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_background(slide, (21, 101, 192))  # 深蓝色背景
    
    add_title_box(slide, "感谢聆听", 
                  top=Inches(2.5), font_size=48, color=(255, 255, 255))
    add_content_box(slide, "岗位胜任力多轮问询与评估报告生成·面试智能体", 
                    top=Inches(4), font_size=20, color=(187, 222, 251))
    add_content_box(slide, "2026 iFLYTEK AI开发者大赛", 
                    top=Inches(5), font_size=16, color=(187, 222, 251))
    
    # 保存
    output_path = os.path.join(os.path.dirname(__file__), "演示文稿_岗位胜任力面试智能体.pptx")
    prs.save(output_path)
    print(f"PPT已生成: {output_path}")


if __name__ == "__main__":
    create_ppt()