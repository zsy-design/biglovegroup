"""生成一份演示面试单并写入数据库。"""
import json
import sys
import time
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.storage import init_db, save_report
from app.competency.nine import NINE_DIMENSIONS, nine_weights_from_six

# ── 候选人画像 ──────────────────────────────────────────
CANDIDATE = {
    "name": "张明远",
    "school": "华中科技大学",
    "degree": "硕士",
    "major": "计算机科学与技术",
    "skills": ["Java", "Spring Boot", "MySQL", "Redis", "微服务", "Docker", "Kafka"],
    "projects": [
        "智能订单中台 —— 负责订单核心模块设计与开发，日均处理 50 万+订单",
        "实时数据看板 —— 基于 Flink + ClickHouse 构建，支撑运营实时决策",
    ],
    "raw": "3年Java开发经验，硕士毕业于华中科技大学计算机专业，熟悉Spring生态、微服务架构与高并发系统设计。",
}

# ── 面试题 + 候选人作答 ──────────────────────────────────
QA_PAIRS = [
    {
        "dimension": "专业知识",
        "question": "介绍一个你最满意的项目，讲清楚它的架构、你负责的模块以及技术选型的原因。",
        "answer": (
            "我最满意的是去年主导的智能订单中台。整体采用 Spring Cloud 微服务架构，"
            "我负责订单核心模块，包括下单、支付回调、库存扣减三个子服务。"
            "技术选型上，用 RocketMQ 做异步解耦，Redis 做分布式锁防重复提交，"
            "MySQL 分库分表支撑日均 50 万订单。上线后核心链路 P99 从 800ms 降到 200ms，"
            "库存超卖率从 0.3% 降到 0。"
        ),
        "score": 4.6,
    },
    {
        "dimension": "专业知识",
        "question": "谈谈你对 Java 中线程池、内存模型或集合框架中某一个的深入理解。",
        "answer": (
            "我选线程池。我们生产环境用 ThreadPoolExecutor 自定义线程池，核心参数："
            "核心线程 20、最大线程 100、队列用有界 ArrayBlockingQueue(5000)、"
            "拒绝策略用 CallerRunsPolicy 保证不丢任务。我们遇到过一个问题："
            "使用 Executors.newFixedThreadPool 导致队列无界，OOM。"
            "后来通过 Arthas 定位到是队列堆积，改为有界队列 + 监控告警后解决。"
            "还做了一个线程池参数动态调整的方案，通过 Nacos 配置中心热更新。"
        ),
        "score": 4.3,
    },
    {
        "dimension": "解决问题",
        "question": "线上一个核心接口经常超时，你会如何定位问题并给出优化方案？",
        "answer": (
            "首先看监控，确认是偶发还是持续。如果是持续的，先看链路追踪定位耗时最长的 span。"
            "我们之前遇到过一个支付回调接口超时，通过 SkyWalking 发现是下游库存服务响应慢。"
            "排查后发现是库存服务的 Redis 连接池配置过小，高峰期连接不够用。"
            "优化方案：1) Redis 连接池从 50 调到 200；2) 增加本地缓存热点数据；"
            "3) 对库存服务做熔断降级，超时 500ms 直接返回库存充足，异步补偿。"
            "最终超时率从 5% 降到 0.1% 以下。"
        ),
        "score": 4.5,
    },
    {
        "dimension": "逻辑思维",
        "question": "如果让你从 0 到 1 设计一个万人使用的消息推送系统，你会怎么拆解需求并设计？",
        "answer": (
            "我会分四步：1) 需求拆解：推送类型(系统通知/营销/预警)、实时性要求、"
            "单用户触达渠道(APP/短信/邮件)；2) 架构设计：接入层做限流鉴权，"
            "消息队列做缓冲，路由层根据渠道分发，推送执行层对接各通道；"
            "3) 关键设计：幂等防重推、频控防骚扰、失败重试用死信队列；"
            "4) 可观测：推送到达率、打开率、用户退订率的实时看板。"
            "我们之前做过类似的系统，日均推送 200 万条，到达率 99.2%。"
        ),
        "score": 4.4,
    },
    {
        "dimension": "沟通协作",
        "question": "描述一次你和同事在技术方案上产生分歧的经历，你是如何处理的？",
        "answer": (
            "有一次关于缓存方案，同事建议用本地缓存 + Redis，我倾向于纯 Redis 集群。"
            "分歧在于一致性：本地缓存更新有延迟，可能导致数据不一致。"
            "我提议先各自准备方案对比文档，列出一致性、性能、运维复杂度三个维度的对比，"
            "然后拉上架构师一起评审。最终采用了混合方案：热点数据本地缓存 + Redis 主从，"
            "非热点数据纯 Redis。通过这件事，我认识到分歧不可怕，关键是用数据和事实说话。"
        ),
        "score": 4.0,
    },
    {
        "dimension": "学习能力",
        "question": "最近一年你主动学习了哪项新技术？是怎么学习并应用到实践中的？",
        "answer": (
            "最近一年我深入学习了云原生技术栈，主要是 Docker + Kubernetes。"
            "学习路径：先看 K8s 官方文档和《Kubernetes in Action》，"
            "然后搭了一个 3 节点的测试集群，把我们内部的 Java 服务容器化部署上去。"
            "实践中遇到过 Pod 调度失败、PV 挂载等问题，通过查文档和社区解决。"
            "目前我们已经有 3 个核心服务跑在 K8s 上，部署效率提升了 60%。"
        ),
        "score": 3.8,
    },
    {
        "dimension": "职业素养",
        "question": "如果你负责的功能上线前发现严重缺陷，距离上线只有两小时，你会怎么决策？",
        "answer": (
            "首先评估缺陷影响：1) 是否影响资金/数据安全？如果是，坚决不上线；"
            "2) 是否有临时规避方案？比如关闭开关、降级返回默认值。"
            "如果缺陷影响可控且有规避方案，跟产品经理和测试负责人同步风险，"
            "决策是否带方案上线。如果没有规避方案，就启动回滚预案，延期上线。"
            "关键是不隐瞒、不赌运气，让相关方知情后共同决策。"
            "我们之前遇到过一次支付模块的空指针，最后是加了开关兜底后上线，第二天热修复。"
        ),
        "score": 4.2,
    },
]

# ── 构建报告 ─────────────────────────────────────────────
def build_demo_report():
    sid = uuid.uuid4().hex[:16]

    # 六维分数
    six_scores = {}
    for qa in QA_PAIRS:
        dim = qa["dimension"]
        if dim not in six_scores:
            six_scores[dim] = []
        six_scores[dim].append(qa["score"])
    six_avg = {d: round(sum(v) / len(v), 2) for d, v in six_scores.items()}

    # 岗位权重 (Java开发)
    job_weights = {"专业知识": 0.25, "逻辑思维": 0.2, "解决问题": 0.2,
                   "沟通协作": 0.1, "学习能力": 0.15, "职业素养": 0.1}

    # 六维加权总分
    total_w = sum(job_weights.values())
    six_overall = round(sum(six_avg.get(d, 2.5) * job_weights.get(d, 0) for d in job_weights) / total_w, 2)

    # 九维分数
    nine_weights = nine_weights_from_six(job_weights)
    nine_scores = {
        "专业能力": round(six_avg.get("专业知识", 2.5), 2),
        "实操经验": round(six_avg.get("解决问题", 2.5) * 0.7 + six_avg.get("专业知识", 2.5) * 0.3, 2),
        "学习能力": round(six_avg.get("学习能力", 2.5), 2),
        "沟通表达": round(six_avg.get("沟通协作", 2.5), 2),
        "逻辑思维": round(six_avg.get("逻辑思维", 2.5), 2),
        "抗压能力": round(six_avg.get("职业素养", 2.5), 2),
        "岗位匹配度": round(0.68 * 5 * 0.7 + six_overall * 0.3, 2),
        "职业稳定性": 4.2,
        "综合潜力": round(six_avg.get("学习能力", 2.5) * 0.6 + six_overall * 0.4, 2),
    }
    # clamp
    nine_scores = {k: round(min(5.0, max(0.5, v)), 2) for k, v in nine_scores.items()}

    overall = round(sum(nine_scores[d] * nine_weights[d] for d in NINE_DIMENSIONS), 2)
    rating = "A" if overall >= 4.4 else "B" if overall >= 3.6 else "C" if overall >= 2.6 else "D"
    decision = "建议录用" if overall >= 4.0 else "待定" if overall >= 3.0 else "不建议录用"
    level = "高度匹配" if overall >= 4.0 else "比较匹配" if overall >= 3.0 else "存在差距"

    strong = sorted(nine_scores.items(), key=lambda kv: kv[1], reverse=True)[:2]
    weak = sorted(nine_scores.items(), key=lambda kv: kv[1])[:2]

    report = {
        "candidate": CANDIDATE,
        "job": {"key": "java", "name": "Java开发工程师"},
        "radar": {
            "dimensions": NINE_DIMENSIONS,
            "scores": [nine_scores[d] for d in NINE_DIMENSIONS],
        },
        "nine_scores": [
            {"dimension": d, "score": nine_scores[d], "weight": round(nine_weights[d], 3)}
            for d in NINE_DIMENSIONS
        ],
        "match_score": overall,
        "match_percent": round(overall / 5.0 * 100),
        "completeness": 1.0,
        "question_count": len(QA_PAIRS),
        "rating": rating,
        "decision": decision,
        "report": {
            "summary": (
                f"候选人对「Java开发工程师」岗位{level}，综合胜任力得分 {overall:.1f}/5.0，"
                f"评级 {rating}。简历与岗位关键词匹配度较高，面试中在 {strong[0][0]} 维度表现最好。"
            ),
            "strengths": [
                f"{k}表现突出（得分 {v:.1f}/5）" for k, v in strong if v >= 3.0
            ] or ["各维度发挥均衡"],
            "weaknesses": [
                f"{k}仍需加强（得分 {v:.1f}/5）" for k, v in weak if v < 4.0
            ] or ["整体表现中规中矩"],
            "suggestions": [
                f"针对「{weak[0][0]}」维度进行专项训练与案例沉淀",
                "将项目经历按 STAR 法则整理，突出个人角色与量化成果",
                "提前演练岗位高频面试题与压力追问，提升临场表达",
            ],
            "review": [
                f"完成 {len(QA_PAIRS)} 轮结构化问答，覆盖 6 个考察维度",
                "回答总体结构完整，能围绕项目经历展开，有量化数据支撑",
                "个别回答可进一步深化细节与个人角色",
            ],
            "risk": ["未发现明显失实风险，作答与履历较一致"],
            "resume_advice": [
                "为每段经历补充 1-2 个量化指标（占比/次数/规模/收益）",
                "在简历头部增加与岗位强相关的关键词，提升筛选命中",
                "删除空泛自我评价，替换为可验证的事实表述",
            ],
            "prep_advice": [
                "围绕 Java 核心技能准备 3 个深度项目案例，每个能讲清难点与结果",
                "复习 JVM 调优、并发编程等高频深挖点",
                "准备 2 个向面试官反问的问题，体现主动性与思考深度",
            ],
            "decision": decision,
            "rating": rating,
            "level": level,
            "multimodal": {
                "answer_count": len(QA_PAIRS),
                "avg_speech_rate": 155,
                "avg_pause_count": 1.8,
                "avg_duration_sec": 35.2,
                "notes": [
                    "语速适中（约 155 字/分），表达流畅",
                    "停顿次数正常（平均 1.8 次）",
                    "平均每题回答约 35.2 秒，信息量充足",
                    "从文本深度看，能给出结构化、有量化结果的回答",
                ],
            },
        },
        # 面试问答记录
        "qa_pairs": QA_PAIRS,
    }

    return sid, report


def main():
    init_db()
    sid, report = build_demo_report()

    # 写入数据库 (不绑定用户，所有人都能看)
    save_report(sid, report, username="demo")

    # 同时保存一份 JSON 文件方便查看
    out = Path(__file__).resolve().parent / "data" / "demo_interview.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print("[OK] Demo interview report generated")
    print(f"   Session ID: {sid}")
    print(f"   Candidate: {CANDIDATE['name']} ({CANDIDATE['school']} {CANDIDATE['degree']})")
    print(f"   Position: Java Developer")
    print(f"   Score: {report['match_score']}/5.0 ({report['match_percent']}%)")
    print(f"   Rating: {report['rating']}")
    print(f"   Decision: {report['decision']}")
    print(f"   JSON: {out}")
    print(f"\n   Open http://127.0.0.1:8000 and check 'My Reports'")


if __name__ == "__main__":
    main()
