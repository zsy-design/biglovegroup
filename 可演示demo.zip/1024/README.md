# 岗位胜任力多轮问询与评估报告生成 · 面试智能体

> 2026 iFLYTEK AI开发者大赛 工程开发赛道作品 Demo
> 面向新一代信息技术岗位的"简历画像 → 多轮情景化问询 → 胜任力评估报告"智能体

## 项目简介

高校毕业生就业压力大、企业招聘成本高，供需双方在岗位能力认知上存在严重的信息不对称。
本 Demo 基于大模型智能体技术，模拟资深 HR / 业务专家进行多轮情景化追问，深挖候选人能力，
并自动生成客观、全面的胜任力评估报告，助力学生提升就业竞争力、企业提升招聘效率。

### 六大功能模块（对标赛题规范全覆盖）

| 模块 | 功能 | 实现位置 |
| --- | --- | --- |
| **1 岗位 JD 智能解析** | 任意岗位 JD → 自动拆解胜任力模型（技能/学历/经验/九维权重重/难度/个性化题库），支持 JD 直聘面试 | `app/jd.py` |
| **2 简历智能处理生态** | PDF/Word/TXT 上传解析、AI 简历优化（STAR/量化/JD 适配）、风险检测、7 类模板库一键套用 | `app/resume/*` |
| **3 虚拟 AI 多轮面试** | **拟人 3D 模型**面试官（VRM 真人比例角色，眨眼/说话口型/思考皱眉/聆听点头程序化驱动），语音+文字双轨提问，JD+简历个性化动态多轮追问（非固定题库），全程留痕 | `app/interview/`、`static/three_avatar.js`、`static/models/hr.vrm` |
| **4 九维胜任力测评** | 专业能力/实操经验/学习能力/沟通表达/逻辑思维/抗压能力/岗位匹配度/职业稳定性/综合潜力，九维量化打分 + 雷达图 | `app/competency/nine.py`、`app/report/generator.py` |
| **5 智能评估报告** | 候选人画像/匹配分析/优势亮点/短板风险/面试复盘/反作弊风险/评级/录用建议/改进方案/简历与备考建议，支持 JSON + 富文本 + **PDF 导出** | `app/report/` |
| **6 数据看板与历史** | 历次面试报告与简历处理记录 SQLite 持久化，可回看/重新生成/删除 | `app/storage.py` |

### 岗位胜任力模型

内置 7 类新一代信息技术岗位，每个岗位按 **冰山模型 + 能力素质词典** 定义 6 个考察维度
（专业知识 / 逻辑思维 / 解决问题 / 沟通协作 / 学习能力 / 职业素养）、维度权重与结构化面试题库，
并自动映射为**九维评估维度**用于雷达图与报告：

Java开发工程师 · 算法工程师 · 数据分析师 · 前端开发工程师 · 测试开发工程师 · 产品经理 · 网络安全工程师

### 面试追问机制

- 回答过短 → 追问展开细节
- 回答达到一定深度 → 按岗位模型给出的"预设追问"继续深挖（每题最多 2 轮）
- 深度足够 → 自然换题
- 全程可随时回复「结束」或点击「结束面试」按钮提前收尾
- 支持「自定义 JD 直聘」：粘贴任意 JD 即可生成个性化面试，非固定题库

### 九维评估与反作弊

- 面试作答按考察维度打分，报告层映射为九维得分（岗位匹配度融合简历匹配 + 面试表现，职业稳定性/综合潜力按规则测算）
- 反作弊判别：识别空洞回答、套话、无实例、信息注水，逐条给出风险提示

### AI 虚拟面试官（晓雅）

- **拟人 3D 模型**（本地打包的 VRM1 角色模型，pixiv/three-vrm 官方样本，离线加载）：
  真人比例角色，程序驱动**眨眼**、说话**口型**（嘴形 A/I/U/E/O 循环）、**思考皱眉**歪头、
  **聆听点头**，常驻呼吸微动；支持鼠标拖拽旋转视角
- **语音播报**：配置讯飞星火密钥后走 **讯飞语音合成**（音质佳）；未配置时自动降级为
  **浏览器 Web Speech** 中文语音，离线也能出声
- **语音作答**：点「🎤 语音回答」按钮，用**浏览器语音识别**直接说话输入回答
  （Chrome / Edge 支持，需授权麦克风）
- 支持「语音：开/关」静音开关，提问/聆听/思考状态实时反馈；模型加载失败自动回退 2D 头像

## 快速开始

```bash
# 1. 安装依赖（Python 3.9+）
pip install -r requirements.txt
```

**一键启动（推荐演示用）**：Windows 下双击 `start.bat`，或执行

```bash
python run.py            # 启动后端并自动打开浏览器首页(默认 8010)
python run.py 9000       # 自定义端口
```

**手动启动**：

```bash
uvicorn app.main:app --reload --port 8010
```

浏览器访问首页（**先在登录页注册/登录**再进入应用）：

- `http://127.0.0.1:8010`（根路径）
- `http://127.0.0.1:8010/static/`（static 目录默认页，等同首页）

应用为**多视图工作台**：`首页/岗位库/智能面试/我的报告`，登录后按账号保存面试与报告（学生 / 企业 / 管理员 三种身份）。

> 重启前请先结束旧进程：`Get-CimInstance Win32_Process -Filter "Name='python.exe'" | Where-Object {$_.CommandLine -match 'uvicorn'} | Stop-Process -Force`

**开箱即用**：未配置讯飞星火 Key 时，自动使用本地规则引擎（`app/llm/mock.py`）离线演示，
全流程可跑通。

### 接入讯飞星火大模型（可选，体验更佳）

在环境变量中配置讯飞开放平台密钥：

```bash
set SPARK_APP_ID=你的AppID
set SPARK_API_KEY=你的APIKey
set SPARK_API_SECRET=你的APISecret
```

配置后自动切换为 Spark 4.0 Ultra 生成更自然的问题、追问与报告文案。

## 接口文档

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/health` | 健康检查 |
| GET | `/api/auth/roles` | 身份角色列表 |
| POST | `/api/auth/register` | 注册（学生/企业/管理员）并返回 token |
| POST | `/api/auth/login` | 登录，返回 token |
| POST | `/api/auth/logout` | 登出（失效 token） |
| GET | `/api/auth/me` | 当前登录用户 |
| GET | `/api/jobs` | 内置岗位列表 |
| POST | `/api/jd/parse` | 模块1：岗位 JD 智能解析 → 结构化胜任力模型 |
| POST | `/api/resume/parse` | 简历解析 → 画像 + 岗位匹配 |
| POST | `/api/resume/upload` | 简历文件上传解析（txt/md/pdf/docx，multipart） |
| POST | `/api/resume/optimize` | AI 简历优化（STAR/量化/JD 适配） |
| POST | `/api/resume/analyze` | 简历风险检测 |
| GET | `/api/resume/templates` | 简历模板库 |
| POST | `/api/resume/apply-template` | 一键套用模板 |
| POST | `/api/interview/start` | ⚠登录 创建面试（`job_key` 或 `jd` 二选一） |
| POST | `/api/interview/respond?session_id=` | ⚠登录 发送回答 → 追问/下一题/结束（可带语音指标） |
| GET | `/api/interview/{sid}/report` | ⚠登录 九维胜任力评估报告（JSON，含多模态分析） |
| GET | `/api/interview/{sid}/report.pdf` | ⚠登录 评估报告 PDF 导出 |
| GET | `/api/history` | ⚠登录 历史记录看板（按账号） |
| GET | `/api/history/{sid}` | ⚠登录 单份历史报告 |
| DELETE | `/api/history/{sid}` | ⚠登录 删除历史记录 |
| POST | `/api/tts` | 虚拟面试官语音合成（未配置密钥返回 browser 降级） |

> ⚠登录 = 需在请求头携带 `Authorization: Bearer <token>`。面试/报告/历史按账号归属。

启动后可访问 `http://127.0.0.1:8010/docs` 查看 Swagger 交互文档。

## 项目结构

```
.
├── app/
│   ├── main.py                # FastAPI 入口
│   ├── config.py              # 全局配置(环境变量)
│   ├── jd.py                  # 模块1: 岗位 JD 智能解析 -> 动态岗位模型
│   ├── storage.py             # 模块6: SQLite 历史记录存储
│   ├── llm/                   # 大模型接入层
│   │   ├── base.py            #   接口抽象
│   │   ├── spark.py           #   讯飞星火 4.0 实现
│   │   └── mock.py            #   本地规则引擎(离线兜底)
│   ├── tts.py                 # 讯飞语音合成(虚拟面试官播报)
│   ├── resume/
│   │   ├── parser.py          # 简历解析与画像构建
│   │   ├── extractor.py       # 模块2: PDF/Word/TXT 文件解析
│   │   ├── optimizer.py       # AI 简历优化 + 风险检测
│   │   └── templates.py       # 简历模板库与一键套用
│   ├── competency/
│   │   ├── model.py           # 岗位胜任力模型库
│   │   └── nine.py            # 九维评估框架(六维→九维映射)
│   ├── interview/engine.py    # 多轮面试对话引擎
│   └── report/
│       ├── generator.py       # 九维评估报告生成
│       └── pdf.py             # 报告 PDF 导出(reportlab)
├── static/                    # 前端页面(简历/JD/面试/雷达图/历史)
│   ├── models/hr.vrm          #   拟人 3D 面试官模型(VRM, 本地打包)
│   ├── vendor/                #   three.min.js + GLTFLoader(r128) + OrbitControls
│   └── three_avatar.js        #   VRM 数字人(眨眼/口型/皱眉/点头驱动)
├── samples/                   # 示例简历
├── scripts/smoke_test.py      # 端到端冒烟测试
├── run.py                     # 一键启动(后端 + 自动开浏览器)
├── start.bat                  # Windows 一键启动脚本
└── demo/
    ├── demo_script.md            # 3-5 分钟演示视频脚本
    └── interview_transcript.md   # 完整面试文稿(10 轮 Q&A，用于录屏/测试)
```

## 测试

```bash
python scripts/smoke_test.py
```

冒烟测试覆盖：健康检查 → 简历解析 → 多轮面试 → 九维评估报告 → JD 解析 →
JD 直聘面试 → 简历优化/检测/模板 → PDF 导出 → 历史记录的完整链路。
