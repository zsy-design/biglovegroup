@echo off
chcp 65001 >nul
title ZhiPin - AI Interview Platform

echo ============================================
echo  ZhiPin - AI Interview Platform
echo ============================================
echo.

echo [1/3] Checking Python...
"C:\Users\diaop\AppData\Local\Programs\Python\Python314\python.exe" --version
if %errorlevel% neq 0 (
    echo [ERROR] Python not found! Please install Python 3.9+
    pause
    exit /b 1
)
echo.

echo [2/3] Checking port 8010...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":8010.*LISTENING"') do (
    echo   Killing old process PID=%%a ...
    taskkill /PID %%a /F >nul 2>&1
)
echo   Port 8010 ready.
echo.

echo [3/3] Starting server...
echo Command: python run.py
"C:\Users\diaop\AppData\Local\Programs\Python\Python314\python.exe" run.py
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Server exited with code %errorlevel%
    echo.
    echo Troubleshooting:
    echo 1. Make sure you are in the correct directory
    echo 2. Try running: pip install -r requirements.txt
    echo 3. Try running: python run.py
    pause
)