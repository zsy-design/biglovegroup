import webbrowser
import threading
import time
from app.main import app
import uvicorn

def open_browser():
    time.sleep(2)
    webbrowser.open("http://127.0.0.1:8010")

if __name__ == "__main__":
    threading.Thread(target=open_browser, daemon=True).start()
    uvicorn.run(app, host="0.0.0.0", port=8010)
