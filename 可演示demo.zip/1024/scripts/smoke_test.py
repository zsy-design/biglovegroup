# -*- coding: utf-8 -*-
"""端到端冒烟测试: 简历解析 -> 面试 -> 报告"""
import json
import sys
import uuid

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)
H = {}


def login_headers():
    """注册/登录一个测试账号，返回带 Authorization 的请求头。"""
    uname = "smoke_" + uuid.uuid4().hex[:8]
    r = client.post("/api/auth/register", json={
        "username": uname, "password": "123456", "nickname": "冒烟", "role": "student", "school": "测试大学",
    })
    assert r.status_code == 200, r.text
    token = r.json()["token"]
    return {"Authorization": "Bearer " + token}


resume = open("samples/resume_java.txt", encoding="utf-8").read()


def main():
    global H
    print("== 0. 注册/登录 ==")
    H = login_headers()
    print("  已登录, 头:", list(H.keys()))

    print("== 1. 健康检查 ==")
    r = client.get("/api/health").json()
    print(r)

    print("\n== 2. 岗位列表 ==")
    jobs = client.get("/api/jobs").json()
    print([j["name"] for j in jobs])

    print("\n== 3. 简历解析 ==")
    r = client.post("/api/resume/parse", json={"text": resume}, headers=H).json()
    p = r["profile"]
    print("画像:", p["name"], p["school"], p["degree"], p["skills"])
    print("推荐岗位:", r["recommended_job"], r["recommended_score"])
    print("排序:", [(k, v) for k, v in r["ranking"]])

    print("\n== 4. 开始面试 ==")
    r = client.post("/api/interview/start", json={"job_key": "java", "resume_text": resume}, headers=H).json()
    sid = r["session_id"]
    print("session:", sid, "| 开场:", r["content"][:60], "...")

    answers = [
        "我叫张伟，合肥工业大学计算机专业本科生。我做过的项目主要是校园二手交易平台，负责后端订单模块的开发，用了Spring Boot和MySQL，解决了并发下单的库存超卖问题，把QPS提升了40%。另外我还搭过微服务的点餐系统，比较熟悉微服务架构和Redis缓存。",
        "我最满意的是校园二手交易平台这个项目。架构上采用前后端分离，后端是Spring Boot加MyBatis，数据库用MySQL，热点数据用Redis做缓存。我负责订单模块和支付回调，其中订单状态机是我独立设计的，避免了超卖问题。技术选型上用Spring生态是因为社区成熟、资料多，上手快也稳定。",
        "流量翻十倍的话，我会从几个层面优化：首先加一层Redis缓存，把热点商品信息缓存起来，减少数据库压力；其次对订单接口做限流和削峰，比如用消息队列异步处理下单；再有就是数据库层面加索引、分库分表，然后做压测验证瓶颈。",
        "如果线上接口超时，我会先看监控和日志，确认是哪个环节慢。如果是数据库慢查询，我会先看执行计划，找到没有走索引的SQL，优化索引或者改写SQL；如果还不够，就考虑加缓存或者读写分离。",
        "当时和同事在设计方案上有分歧，他觉得用单库就够了，我建议引入Redis缓存热点数据。我没有直接争论，而是先把两种方案的吞吐量数据算出来，再拉一个小会讨论，最后大家认可了缓存方案，效果也确实好。",
        "我最近主动学习了Spring Cloud Alibaba的微服务组件，主要是看官方文档和源码，然后在我们点餐系统项目里实际用起来。遇到问题就去社区查资料，再自己写demo验证，进步比较快。",
        "如果上线前发现严重缺陷，我会第一时间评估影响范围，如果是核心链路问题就先叫停上线，向上反馈并给出修复方案和新的时间点；如果只是边缘功能，可以带上临时开关上线再快速修复。",
        "如果让我设计消息推送系统，我会先拆需求：包括用户接入、消息投递、送达回执、失败重试、渠道管理。架构上会用消息队列解耦，生产者把消息投到队列，消费者按渠道下发，再配合幂等去重和重试机制保证可靠投递，最后用监控大盘跟踪送达率。",
        "最近学的是消息中间件RabbitMQ，我先把核心概念（交换机、队列、路由）和官方文档过了一遍，然后在点餐项目里用它的延迟队列实现了订单超时自动取消，遇到问题看源码和社区讨论，再写demo验证，现在已经能独立应用了。",
        "协作上，我在团队里会主动把技术方案整理成文档发到群里，遇到分歧先对齐目标再谈方案。之前在订单模块联调时，我主动和前端同学约了几次接口评审，把字段和异常约定清楚，联调一次通过，大家配合很顺畅。",
        "面试结束",
    ]
    for i, ans in enumerate(answers):
        resp = client.post(f"/api/interview/respond?session_id={sid}", json={"answer": ans}, headers=H)
        r = resp.json()
        if resp.status_code != 200:
            print(f"  [{i}] 响应异常: {r}")
            break
        print(f"  [{i}] {r['type']}: {r['content'][:56]}...")
        if r["type"] == "end":
            break

    print("\n== 5. 生成报告 ==")
    resp = client.get(f"/api/interview/{sid}/report", headers=H)
    print("  HTTP", resp.status_code)
    if resp.status_code != 200:
        print("  错误:", resp.json())
        return
    r = resp.json()
    print("匹配度:", r["match_percent"], "% 得分:", r["match_score"], "评级:", r["rating"], "录用:", r["decision"])
    print("雷达图(九维):", dict(zip(r["radar"]["dimensions"], r["radar"]["scores"])))
    print("摘要:", r["report"]["summary"])
    print("优势:", r["report"]["strengths"])
    print("待提升:", r["report"]["weaknesses"])
    print("复盘:", r["report"]["review"])
    print("风险:", r["report"]["risk"])

    print("\n== 6. JD 智能解析 ==")
    jd = client.post("/api/jd/parse", json={
        "text": "招聘 Java 后端开发工程师，本科及以上，3 年经验，熟悉 Spring/MySQL/Redis，高并发经验优先"
    }).json()
    print("岗位:", jd["job_name"], "| 难度:", jd["difficulty"], "| 技能:", jd["core_skills"],
          "| 题目数:", len(jd["questions"]))

    print("\n== 7. JD 直聘面试 ==")
    st = client.post("/api/interview/start", json={"jd": "招聘数据分析师，本科以上，熟悉 SQL/Python，负责指标体系搭建",
                                                   "resume_text": resume}, headers=H).json()
    sid2 = st["session_id"]
    for ans in ["我叫张伟，做过数据分析项目。", "我用 SQL 做漏斗分析，通过补全埋点把转化率提升 15%。", "面试结束"]:
        r = client.post(f"/api/interview/respond?session_id={sid2}", json={"answer": ans}, headers=H).json()
        if r["type"] == "end":
            break
    rep2 = client.get(f"/api/interview/{sid2}/report", headers=H).json()
    print("JD 报告岗位:", rep2["job"]["name"], "| 匹配度:", rep2["match_percent"], "%")

    print("\n== 8. 简历工具 ==")
    opt = client.post("/api/resume/optimize", json={"text": resume, "job_name": "Java开发"}, headers=H).json()
    print("优化:", len(opt["optimized"]), "字, 要点", len(opt["changes"]), "条")
    ana = client.post("/api/resume/analyze", json={"text": resume}, headers=H).json()
    print("风险检测:", ana["level"], ana["health"], "问题", len(ana["issues"]), "条")
    tpl = client.get("/api/resume/templates", headers=H).json()
    print("模板库:", [t["key"] for t in tpl["templates"]])

    print("\n== 9. PDF 导出 ==")
    pdf = client.get(f"/api/interview/{sid}/report.pdf", headers=H)
    print("  HTTP", pdf.status_code, "| type:", pdf.headers.get("content-type"), "| size:", len(pdf.content))

    print("\n== 10. 历史记录 ==")
    h = client.get("/api/history", headers=H).json()
    print("场次:", len(h["sessions"]), "| 简历处理:", len(h["resumes"]))

    print("\n== 全部通过 ==")


if __name__ == "__main__":
    main()
