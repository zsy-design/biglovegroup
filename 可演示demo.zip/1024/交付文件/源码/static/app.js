/* 智聘 · 智能面试评测智能体 - 前端逻辑 v4.0 */
"use strict";

const $ = (id) => document.getElementById(id);
const state = {
  token: null, user: null,
  sessionId: null, jobKey: null, jdText: null,
  resumeText: "", finished: false, radar: null,
};
const APP_VERSION = "v5.1";
const ROLE_NAMES = { student: "学生/求职者", enterprise: "企业/HR", admin: "管理员" };

/* ---------------- 工具 ---------------- */
async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (state.token) headers["Authorization"] = "Bearer " + state.token;
  const resp = await fetch(path, { ...options, headers });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(data.detail || `请求失败 ${resp.status}`);
  return data;
}

function escapeHtml(s) {
  const div = document.createElement("div");
  div.textContent = s || "";
  return div.innerHTML;
}
function fmtTime(ts) {
  if (!ts) return "";
  const d = new Date(ts * 1000);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
function jobName(key) {
  const jobs = window._jobs || [];
  const hit = jobs.find((j) => j.key === key);
  return hit ? hit.name : key;
}

/* ---------------- 轻提示 / 确认弹窗 ---------------- */
function toast(msg, type) {
  let wrap = document.querySelector(".toast-wrap");
  if (!wrap) {
    wrap = document.createElement("div");
    wrap.className = "toast-wrap";
    document.body.appendChild(wrap);
  }
  const el = document.createElement("div");
  el.className = "toast " + (type || "");
  el.textContent = msg;
  const close = () => {
    if (!el.isConnected) return;
    el.classList.add("out");
    setTimeout(() => el.remove(), 220);
  };
  el.addEventListener("click", close);
  wrap.appendChild(el);
  setTimeout(close, 4200);
}
function confirmDialog(title, text, okLabel) {
  return new Promise((resolve) => {
    const mask = document.createElement("div");
    mask.className = "modal-mask";
    mask.innerHTML = `
      <div class="modal">
        <h4>${escapeHtml(title)}</h4>
        <p>${escapeHtml(text)}</p>
        <div class="modal-actions">
          <button class="mini" data-act="cancel">取消</button>
          <button class="primary" data-act="ok">${escapeHtml(okLabel || "确定")}</button>
        </div>
      </div>`;
    const done = (v) => { mask.remove(); resolve(v); };
    mask.addEventListener("click", (e) => {
      if (e.target === mask) return done(false);
      const act = e.target.closest("[data-act]");
      if (act) done(act.dataset.act === "ok");
    });
    document.body.appendChild(mask);
  });
}
/* 求职平台配置 */
const JOB_PLATFORMS = [
  { name: "牛客网", url: "https://www.nowcoder.com", icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.21c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.95 2.25z"/></svg>', desc: "校招刷题/面经/内推首选" },
  { name: "BOSS直聘", url: "https://www.zhipin.com", icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>', desc: "直聊HR、回复快、社招主流" },
  { name: "拉勾招聘", url: "https://www.lagou.com", icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.26z"/></svg>', desc: "互联网垂直招聘平台" },
  { name: "应届生求职网", url: "https://www.yingjiesheng.com", icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 3L1 9l11 6 9-4.91V17h2V9L12 3z"/></svg>', desc: "校招大厂信息最全" },
  { name: "实习僧", url: "https://www.shixiseng.com", icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>', desc: "实习/校招专业平台" },
  { name: "前程无忧", url: "https://www.51job.com", icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.21c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.95 2.25z"/></svg>', desc: "老牌综合招聘网站" },
  { name: "智联招聘", url: "https://www.zhaopin.com", icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>', desc: "综合型招聘平台" },
  { name: "猎聘网", url: "https://www.liepin.com", icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>', desc: "中高端猎头/社招" },
];

/* 渲染求职平台卡片 */
function renderPlatforms() {
  const grid = $("platformGrid");
  if (!grid) return;
  grid.innerHTML = JOB_PLATFORMS.map((p) => `
    <a class="platform-card" href="${p.url}" target="_blank" rel="noopener noreferrer">
      <div class="platform-icon">${p.icon}</div>
      <div class="platform-name">${p.name}</div>
      <div class="platform-desc">${p.desc}</div>
    </a>`).join("");
}

/* 带图标的区块标题（内联 SVG，离线可用） */
const ICONS = {
  chart: '<svg class="ic" viewBox="0 0 24 24"><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/></svg>',
  spark: '<svg class="ic" viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
  user: '<svg class="ic" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
  target: '<svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
  file: '<svg class="ic" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
  shield: '<svg class="ic" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
  star: '<svg class="ic" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
  flag: '<svg class="ic" viewBox="0 0 24 24"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>',
  mic: '<svg class="ic" viewBox="0 0 24 24"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/></svg>',
  bulb: '<svg class="ic" viewBox="0 0 24 24"><path d="M9 18h6"/><path d="M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.4 1 2.3h6c0-.9.4-1.8 1-2.3A7 7 0 0 0 12 2z"/></svg>',
  book: '<svg class="ic" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
  grid: '<svg class="ic" viewBox="0 0 24 24"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
  layers: '<svg class="ic" viewBox="0 0 24 24"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
  video: '<svg class="ic" viewBox="0 0 24 24"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>',
  clipboard: '<svg class="ic" viewBox="0 0 24 24"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/></svg>',
  brain: '<svg class="ic" viewBox="0 0 24 24"><path d="M12 2a4 4 0 0 0-3.46 1.5A4.5 4.5 0 0 1 4 10c0 1.54.68 2.93 1.77 3.87A6 6 0 0 0 12 22a6 6 0 0 0 6.23-8.13c1.09-.94 1.77-2.33 1.77-3.87a4.5 4.5 0 0 1-2.77-6.5A4 4 0 0 0 12 2z"/></svg>',
  database: '<svg class="ic" viewBox="0 0 24 24"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0 0 18 0V5"/><path d="M3 12a9 3 0 0 0 18 0"/></svg>',
  robot: '<svg class="ic" viewBox="0 0 24 24"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M9 8h6"/><path d="M12 12v4"/><circle cx="8" cy="16" r="1"/><circle cx="16" cy="16" r="1"/><path d="M6 11h2"/><path d="M16 11h2"/></svg>',
  trending: '<svg class="ic" viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>',
  map: '<svg class="ic" viewBox="0 0 24 24"><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/></svg>',
};
function secTitle(icon, text) {
  return `<h3>${ICONS[icon] || ""}${escapeHtml(text)}</h3>`;
}

/* 页面标题（侧边栏布局的顶栏上下文） */
const VIEW_TITLES = {
  dashboard: ["工作台", "岗位胜任力多轮问询与评估报告生成"],
  jobs: ["岗位库", "内置 7 类岗位胜任力模型，选择后一键开始面试"],
  interview: ["智能面试", "JD 与简历 → 多轮情景化问询 → 九维评估报告"],
  "resume-analysis": ["简历分析", "AI 多维度解析简历，生成可视化能力画像与优化建议"],
  "resume-library": ["简历库", "云端管理简历版本，支持 AI 诊断、多版本对比、模板导出"],
  "digital-human": ["数字人面试官", "拟真 3D 数字人实时语音面试，多模态行为分析（开发中）"],
  assistant: ["AI 助手", "大模型驱动的求职咨询、技术答疑与面试辅导"],
  reports: ["我的报告", "历次面试评估报告，支持回看与 PDF 导出"],
};

/* ---------------- 页内错误诊断 ---------------- */
window.addEventListener("error", (e) => {
  const box = $("errBox");
  box.classList.remove("hidden");
  box.textContent = `[JS错误] ${e.message}\n${e.filename || ""}:${e.lineno || ""}`;
});
window.addEventListener("unhandledrejection", (e) => {
  const box = $("errBox");
  box.classList.remove("hidden");
  box.textContent = `[异步错误] ${e.reason && e.reason.message ? e.reason.message : e.reason}`;
});
$("errBox").addEventListener("click", () => $("errBox").classList.add("hidden"));

/* ---------------- 视图切换 ---------------- */
function showView(name) {
  document.querySelectorAll(".view").forEach((el) => el.classList.remove("active"));
  const target = $("view-" + name);
  if (target) target.classList.add("active");
  document.querySelectorAll(".nav-tab").forEach((b) => {
    b.classList.toggle("active", b.dataset.view === name);
  });
  const t = VIEW_TITLES[name];
  if (t) { $("pageTitle").textContent = t[0]; $("pageSub").textContent = t[1]; }
  if (name === "dashboard") renderDashboard();
  if (name === "jobs") renderJobCards();
  if (name === "resume-analysis") renderResumeAnalysis();
  if (name === "resume-library") renderResumeLibrary();
  if (name === "digital-human") renderDigitalHuman();
  if (name === "assistant") initAssistant();
  if (name === "reports") loadHistory();
  window.scrollTo({ top: 0, behavior: "smooth" });
}
function showPhase(name) {
  document.querySelectorAll(".phase").forEach((el) => el.classList.remove("active"));
  const target = $(name);
  if (target) target.classList.add("active");
  const stepMap = { "phase-resume": 1, "phase-interview": 2, "phase-report": 3 };
  const cur = stepMap[name] || 1;
  document.querySelectorAll(".stepper .step").forEach((el) => {
    const s = parseInt(el.dataset.step, 10);
    el.classList.toggle("active", s === cur);
    el.classList.toggle("done", s < cur);
  });
}

/* ---------------- 认证 ---------------- */
function showAuth(msg, ok) {
  const box = $("authMsg");
  box.className = "auth-msg " + (ok ? "ok" : "err");
  box.textContent = msg;
}
function enterApp(user, token) {
  state.user = user;
  state.token = token;
  try { localStorage.setItem("zp_token", token); } catch {}
  $("loginView").classList.add("hidden");
  $("appView").classList.remove("hidden");
  $("userName").textContent = user.nickname || user.username;
  $("userInitial").textContent = (user.nickname || user.username || "?").slice(0, 1).toUpperCase();
  $("userRole").textContent = ROLE_NAMES[user.role] || user.role;
  $("dashHello").textContent = `你好，${user.nickname || user.username}`;
  $("dashSub").textContent = user.role === "enterprise"
    ? "以企业视角管理候选人面试与评估，选择岗位开始 AI 面试。"
    : "选择岗位或粘贴 JD，一键开始多轮情景化分布式评估。";
  init();
  showView("dashboard");
}
function setAuthTab(login) {
  $("tabLogin").classList.toggle("active", login);
  $("tabRegister").classList.toggle("active", !login);
  $("loginForm").classList.toggle("hidden", !login);
  $("registerForm").classList.toggle("hidden", login);
}

async function doLogin(e) {
  e.preventDefault();
  try {
    const d = await api("/api/auth/login", { method: "POST", body: JSON.stringify({ username: $("loginUser").value.trim(), password: $("loginPwd").value }) });
    showAuth(d.message, true);
    enterApp(d.user, d.token);
  } catch (err) { showAuth(err.message, false); }
}
async function doRegister(e) {
  e.preventDefault();
  const username = $("regUser").value.trim();
  const password = $("regPwd").value;
  if (!username || username.length < 2) return showAuth("用户名至少 2 位", false);
  if (password.length < 4) return showAuth("密码至少 4 位", false);
  try {
    const d = await api("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ username, password, nickname: $("regNick").value.trim(), role: $("regRole").value, school: $("regSchool").value.trim() }),
    });
    showAuth(d.message, true);
    enterApp(d.user, d.token);
  } catch (err) { showAuth(err.message, false); }
}

async function doLogout() {
  try { await api("/api/auth/logout", { method: "POST" }); } catch {}
  try { localStorage.removeItem("zp_token"); } catch {}
  state.token = null; state.user = null; state.sessionId = null; state.finished = false;
  $("appView").classList.add("hidden");
  $("loginView").classList.remove("hidden");
  showAuth("", true);
  setAuthTab(true);
}

/* ---------------- 初始化 ---------------- */
async function init() {
  $("verTag").textContent = `· ${APP_VERSION}`;
  try {
    const h = await api("/api/health");
    const llmText = h.llm === "spark" ? "讯飞星火" : "本地规则(可离线)";
    $("llmBadge").innerHTML = `引擎：${llmText}`;
  } catch { $("llmBadge").textContent = "服务未连接"; }
}

/* ---------------- 仪表盘 ---------------- */
async function renderDashboard() {
  renderPlatforms();
  try {
    const h = await api("/api/history");
    const list = h.sessions || [];
    const avg = list.length ? Math.round(list.reduce((s, x) => s + (x.match_percent || 0), 0) / list.length) + "%" : "—";
    const cards = [
      ["layers", "岗位模型", (window._jobs || []).length, "内置胜任力模型"],
      ["video", "我的面试", h.total_sessions || 0, "已完成面试"],
      ["user", "简历处理", h.total_resumes || 0, "简历画像/优化"],
      ["target", "平均匹配度", avg, "综合面试表现"],
    ];
    const cardLinks = { "岗位模型": "jobs", "我的面试": "reports", "简历处理": "resume-library", "平均匹配度": "reports" };
    $("statCards").innerHTML = cards.map(([ic, l, n, sub]) =>
      `<div class="stat-card" data-nav="${cardLinks[l] || ""}" style="cursor:${cardLinks[l] ? 'pointer' : 'default'}"><div class="sc-top"><span class="sc-ic">${ICONS[ic] || ""}</span><span class="lbl">${l}</span></div><div class="num">${n}</div><div class="sub">${sub}</div></div>`).join("");
    document.querySelectorAll("#statCards .stat-card[data-nav]").forEach(c => {
      c.addEventListener("click", () => { if (c.dataset.nav) showView(c.dataset.nav); });
    });
    $("dashRecent").innerHTML = list.length ? list.slice(0, 6).map((s) => `
      <div class="recent-item">
        <div><div class="t">${escapeHtml(s.candidate)} · ${escapeHtml(s.job_name || "—")}</div>
        <div class="s">${fmtTime(s.created_at)} · 匹配度 ${s.match_percent || 0}% · 得分 ${(s.match_score || 0).toFixed(1)}/5</div></div>
        <div class="actions"><button class="mini" data-viewone="${s.sid}">报告</button></div>
      </div>`).join("")
      : "<p class='hint'>暂无面试记录，去「智能面试」开始第一场吧。</p>";
    document.querySelectorAll("[data-viewone]").forEach((b) => b.addEventListener("click", () => { showView("reports"); setTimeout(() => viewHistory(b.dataset.viewone), 30); }));
  } catch (e) {
    const isAuth = e.message.includes("401") || e.message.includes("未登录");
    $("dashRecent").innerHTML = isAuth
      ? `<p class='hint'>请先登录后查看面试记录。</p>`
      : `<p class='hint'>加载失败：${escapeHtml(e.message)}</p>`;
  }
  $("dashProfile").innerHTML = state.resumeText
    ? `<p class="muted">已绑定简历。完成面试后可在「我的报告」查看九维能力画像。</p>`
    : `<p class="muted">尚未提交简历。到「智能面试」上传简历以生成九维画像与岗位匹配建议。</p>`;
}

/* ---------------- 岗位库 ---------------- */
function renderJobCards() {
  if (!window._jobs) return;
  const cats = window._jobCategories || {};
  const container = $("jobCards");
  
  if (Object.keys(cats).length > 0) {
    let html = "";
    Object.entries(cats).forEach(([catName, keys]) => {
      html += `<div class="job-category"><h4>${escapeHtml(catName)}</h4></div>`;
      keys.forEach(k => {
        const job = (window._jobs || []).find(j => j.key === k);
        if (!job) return;
        html += `
          <div class="job-card" data-key="${job.key}">
            <div class="t">${escapeHtml(job.name)}</div>
            <div class="hint">${escapeHtml(job.desc)}</div>
            <div class="pill-row">${job.core_skills.slice(0,4).map(s => `<span class="mini-pill">${escapeHtml(s)}</span>`).join("")}</div>
            <div style="margin-top:auto;display:flex;gap:8px;justify-content:flex-end">
              <button class="mini ghost" data-view-market="${job.key}">市场数据</button>
              <button class="mini primary" data-start-job="${job.key}">开始面试</button>
            </div>
          </div>`;
      });
    });
    container.innerHTML = html;
  } else {
    // 简单列表模式
    container.innerHTML = (window._jobs || []).map(job => `
      <div class="job-card" data-key="${job.key}">
        <div class="t">${escapeHtml(job.name)}</div>
        <div class="hint">${escapeHtml(job.desc)}</div>
        <div class="pill-row">${job.core_skills.slice(0,4).map(s => `<span class="mini-pill">${escapeHtml(s)}</span>`).join("")}</div>
        <div style="margin-top:auto;display:flex;gap:8px;justify-content:flex-end">
          <button class="mini ghost" data-view-market="${job.key}">市场数据</button>
          <button class="mini primary" data-start-job="${job.key}">开始面试</button>
        </div>
      </div>`).join("");
  }

  // 绑定开始面试按钮
  container.querySelectorAll("[data-start-job]").forEach(btn => {
    btn.addEventListener("click", () => {
      state.jobKey = btn.dataset.startJob;
      if (!state.resumeText) {
        showView("interview");
        showPhase("phase-resume");
        return;
      }
      showView("interview");
      showPhase("phase-resume");
      setTimeout(() => { $("btnStart").click(); }, 100);
    });
  });
  
  // 绑定市场数据按钮
  container.querySelectorAll("[data-view-market]").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      const jobKey = btn.dataset.viewMarket;
      const job = (window._jobs || []).find(j => j.key === jobKey);
      if (!job) return;
      showJobMarketModal(jobKey, job.name);
    });
  });
}

/* ---------------- 岗位市场数据弹窗 ---------------- */
async function showJobMarketModal(jobKey, jobName) {
  const mask = document.createElement("div");
  mask.className = "modal-mask";
  mask.innerHTML = `
    <div class="modal" style="width:min(680px,95%);max-height:85vh;overflow-y:auto">
      <h4>${escapeHtml(jobName)} - 市场招聘数据</h4>
      <p class="hint">数据来源：BOSS直聘 / 拉勾网 / 智联招聘（实时采集）</p>
      <div id="marketDataContent" style="text-align:center;padding:40px;color:var(--muted)">
        <div style="font-size:24px;margin-bottom:8px">⏳</div>
        正在从多个招聘平台采集数据…
      </div>
      <div class="modal-actions">
        <button class="mini" data-act="close">关闭</button>
      </div>
    </div>`;
  mask.addEventListener("click", (e) => {
    if (e.target === mask || e.target.closest("[data-act='close']")) mask.remove();
  });
  document.body.appendChild(mask);
  
  try {
    const data = await api(`/api/jobs/real-data?job_key=${encodeURIComponent(jobKey)}&limit=100`);
    const content = mask.querySelector("#marketDataContent");
    
    if (data.error) {
      content.innerHTML = `<div style="color:var(--danger)">数据加载失败: ${escapeHtml(data.error)}</div>`;
      return;
    }

    const profile = data.job_profile || {};
    
    // 岗位职责
    const dutiesHTML = (profile.duties || []).length > 0 ? `
      <div style="margin-bottom:20px">
        <h5 style="margin:0 0 10px;font-size:14px">📋 岗位职责</h5>
        <ul style="margin:0;padding-left:20px;list-style:disc">
          ${profile.duties.map(d => `<li style="font-size:13px;line-height:1.8;color:var(--text-2)">${escapeHtml(d)}</li>`).join("")}
        </ul>
      </div>` : "";

    // 薪资分布
    const salaryHTML = data.salary_distribution.length > 0 ? `
      <div style="margin-bottom:20px">
        <h5 style="margin:0 0 10px;font-size:14px">💰 薪资分布</h5>
        <div style="display:flex;flex-wrap:wrap;gap:8px">
          ${data.salary_distribution.map(s => `
            <div style="background:var(--primary-soft);border:1px solid var(--primary);border-radius:8px;padding:8px 14px;text-align:center;min-width:80px">
              <div style="font-size:12px;color:var(--muted)">${escapeHtml(s.range)}</div>
              <div style="font-size:18px;font-weight:700;color:var(--primary)">${s.count}</div>
              <div style="font-size:11px;color:var(--muted)">个岗位</div>
            </div>
          `).join("")}
        </div>
      </div>` : "";
    
    // 技能详情（含等级与用途）
    const skillDetailsHTML = (profile.skill_details || []).length > 0 ? `
      <div style="margin-bottom:20px">
        <h5 style="margin:0 0 10px;font-size:14px">🛠️ 技能要求</h5>
        ${profile.skill_details.map(s => `
          <div style="display:flex;align-items:flex-start;gap:10px;padding:8px 0;border-bottom:1px solid var(--border)">
            <span style="font-weight:700;font-size:13px;min-width:110px;color:var(--text)">${escapeHtml(s.name)}</span>
            <span style="font-size:11px;padding:2px 8px;border-radius:4px;${s.level === '精通' ? 'background:#fef3c7;color:#92400e' : s.level === '熟练' ? 'background:#dbeafe;color:#1e40af' : 'background:#f3f4f6;color:#6b7280'}">${escapeHtml(s.level)}</span>
            <span style="font-size:12px;color:var(--text-2);flex:1">${escapeHtml(s.usage)}</span>
          </div>
        `).join("")}
      </div>` : "";
    
    // 技能热度（从招聘数据统计）
    const skillsHTML = data.top_skills.length > 0 ? `
      <div style="margin-bottom:20px">
        <h5 style="margin:0 0 10px;font-size:14px">🔥 招聘高频技能 TOP 10</h5>
        ${data.top_skills.slice(0, 10).map((s, i) => `
          <div style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--border)">
            <span style="width:20px;text-align:right;color:var(--muted);font-size:12px">${i+1}</span>
            <span style="width:100px;font-weight:600;font-size:13px">${escapeHtml(s.skill)}</span>
            <div style="flex:1;height:8px;background:#e8eaf5;border-radius:4px;overflow:hidden">
              <div style="height:100%;width:${Math.min(s.count/data.top_skills[0].count*100, 100)}%;background:linear-gradient(90deg,#818cf8,#7c3aed);border-radius:4px"></div>
            </div>
            <span style="width:40px;text-align:right;font-size:12px;color:var(--muted)">${s.count}</span>
          </div>
        `).join("")}
      </div>` : "";
    
    // 城市对比
    const citiesHTML = data.city_comparison.length > 0 ? `
      <div style="margin-bottom:20px">
        <h5 style="margin:0 0 10px;font-size:14px">🏙️ 城市薪资对比</h5>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px">
          ${data.city_comparison.slice(0, 8).map(c => `
            <div style="background:#f8f9fe;border:1px solid var(--border);border-radius:8px;padding:10px;text-align:center">
              <div style="font-weight:600;font-size:13px">${escapeHtml(c.city)}</div>
              <div style="font-size:16px;font-weight:700;color:var(--primary);margin:4px 0">${c.avg_salary}k</div>
              <div style="font-size:11px;color:var(--muted)">${c.count} 个岗位</div>
            </div>
          `).join("")}
        </div>
      </div>` : "";

    // 相关岗位推荐
    const relatedHTML = (profile.related_jobs || []).length > 0 ? `
      <div style="margin-bottom:12px">
        <h5 style="margin:0 0 10px;font-size:14px">🔗 相关岗位推荐</h5>
        <div style="display:flex;flex-wrap:wrap;gap:8px">
          ${profile.related_jobs.map(rk => {
            const rj = (window._jobs || []).find(j => j.key === rk);
            return rj ? `<button class="mini" onclick="this.closest('.modal-mask').remove();showJobMarketModal('${rk}','${escapeHtml(rj.name).replace(/'/g,"\\'")}')" style="font-size:12px">${escapeHtml(rj.name)}</button>` : "";
          }).join("")}
        </div>
      </div>` : "";
    
    content.innerHTML = `
      <div style="margin-bottom:12px;font-size:13px;color:var(--muted)">
        共采集 <b style="color:var(--primary)">${data.total_jobs}</b> 条真实岗位数据
        ${data.sources.length > 0 ? `（来源：${data.sources.join(" / ")}）` : ""}
      </div>
      ${dutiesHTML}${salaryHTML}${skillDetailsHTML}${skillsHTML}${citiesHTML}${relatedHTML}
    `;
  } catch (e) {
    const content = mask.querySelector("#marketDataContent");
    content.innerHTML = `<div style="color:var(--danger)">数据加载失败: ${escapeHtml(e.message)}</div>`;
  }
}
async function renderResumeAnalysis() {
  const input = $("raResumeInput");
  const fileInput = $("raResumeFile");
  const parseBtn = $("raBtnParse");
  const optimizeBtn = $("raBtnOptimize");
  const toolBox = $("raToolBox");
  const profileBox = $("raProfileBox");
  const profileGrid = $("raProfileGrid");
  const chartsArea = $("raChartsArea");
  const radarCanvas = $("raRadarCanvas");
  const skillBars = $("raSkillBars");
  const projectsDiv = $("raProjects");
  const salaryDiv = $("raSalary");

  // 同步简历数据：如果智能面试页面有简历，同步过来
  const interviewResume = $("resumeInput")?.value?.trim();
  if (interviewResume && interviewResume.length > 20 && !input.value.trim()) {
    input.value = interviewResume;
  }

  parseBtn.onclick = async () => {
    const text = input.value.trim();
    if (text.length < 20) return toast("请先粘贴至少 20 字以上的简历内容", "err");
    parseBtn.disabled = true; parseBtn.textContent = "解析中…";
    try {
      const data = await api("/api/resume/parse", { method: "POST", body: JSON.stringify({ text }) });
      renderResumeAnalysisProfile(data);
      // 同步到智能面试页面
      if ($("resumeInput")) $("resumeInput").value = text;
      state.resumeText = text;
      toolBox.classList.add("hidden");
      profileBox.style.display = "block";
      chartsArea.style.display = "grid";
    } catch (e) { toast(e.message, "err"); }
    finally { parseBtn.disabled = false; parseBtn.textContent = "解析并分析"; }
  };

  fileInput.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const fd = new FormData();
    fd.append("file", file);
    fd.append("filename", file.name);
    parseBtn.disabled = true; parseBtn.textContent = "上传解析中…";
    try {
      const resp = await fetch("/api/resume/upload", { method: "POST", headers: authHeaders(), body: fd });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.detail || "上传失败");
      input.value = data.text;
      renderResumeAnalysisProfile(data);
      toolBox.classList.add("hidden");
      profileBox.style.display = "block";
      chartsArea.style.display = "grid";
    } catch (err) { toast(err.message, "err"); }
    finally { parseBtn.disabled = false; parseBtn.textContent = "解析并分析"; e.target.value = ""; }
  };

  optimizeBtn.onclick = async () => {
    const text = input.value.trim();
    if (text.length < 20) return toast("请先粘贴简历内容", "err");
    const jobName = state.jdText ? (window._lastJD && window._lastJD.job_name) : (jobNameByKey());
    optimizeBtn.disabled = true; optimizeBtn.textContent = "分析中…";
    try {
      const d = await api("/api/resume/optimize", { method: "POST", body: JSON.stringify({ text, job_name: jobName || "目标岗位" }) });
      toolBox.innerHTML = `${secTitle("spark", "AI 简历优化建议")}<h4>优化要点</h4><ul>${(d.changes || []).map((c) => `<li>${escapeHtml(c)}</li>`).join("")}</ul><h4>优化后简历（可复制使用）</h4><pre class="resume-out">${escapeHtml(d.optimized)}</pre>`;
      toolBox.classList.remove("hidden");
      toolBox.scrollIntoView({ behavior: "smooth", block: "nearest" });
    } catch (e) { toast(e.message, "err"); }
    finally { optimizeBtn.disabled = false; optimizeBtn.textContent = "AI 优化建议"; }
  };

  function renderResumeAnalysisProfile(data) {
    const p = data.profile;
    const items = [
      ["姓名", p.name], ["院校", p.school || "-"], ["学历", p.degree], ["专业", p.major || "-"],
      ["技能标签", (p.skills || []).join("、") || "-"], ["项目经历", (p.projects || []).length + " 项"],
    ];
    profileGrid.innerHTML = items.map(([k, v]) => `<div class="kv" style="display:flex;flex-direction:column"><span class="hint">${escapeHtml(k)}</span><b>${escapeHtml(v)}</b></div>`).join("");

    /* 技能雷达图 - 基于实际技能数量计算 */
    const allSkills = p.skills || [];
    const skillCats = ["编程语言", "框架/库", "数据库", "中间件", "工具/平台", "软技能"];
    const skillKeywords = {
      "编程语言": ["java", "python", "javascript", "go", "c++", "typescript", "php", "ruby"],
      "框架/库": ["spring", "react", "vue", "angular", "node", "django", "flask", "fastapi"],
      "数据库": ["mysql", "redis", "mongodb", "postgresql", "oracle", "sql"],
      "中间件": ["kafka", "rabbitmq", "nginx", "docker", "k8s", "微服务"],
      "工具/平台": ["git", "linux", "aws", "阿里云", "jenkins", "maven"],
      "软技能": ["沟通", "团队", "管理", "领导", "协作"]
    };
    const skillScores = skillCats.map(cat => {
      const keywords = skillKeywords[cat] || [];
      const matches = allSkills.filter(s => 
        keywords.some(kw => s.toLowerCase().includes(kw))
      );
      return Math.min(5, 2 + matches.length * 0.8);
    });
    drawRadar(radarCanvas, skillCats, skillScores);

    /* 技能条形图 - 基于技能列表生成稳定分数 */
    skillBars.innerHTML = allSkills.slice(0, 12).map((s, i) => {
      // 基于技能名称生成稳定的分数（不是随机的）
      const hash = s.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
      const score = 40 + (hash % 50); // 40-90之间的稳定分数
      return `<div style="margin-bottom:10px"><div style="display:flex;justify-content:space-between;margin-bottom:4px"><span>${escapeHtml(s)}</span><span style="color:var(--primary);font-weight:600">${score}%</span></div><div class="bar" style="height:8px"><i style="width:${score}%"></i></div></div>`;
    }).join("") || "<p class='muted'>暂无技能数据</p>";

    /* 项目经历 */
    projectsDiv.innerHTML = (p.projects || []).map((proj, i) => `
      <div style="padding:12px;background:#f8f9fe;border:1px solid var(--border);border-radius:10px;margin-bottom:10px">
        <div style="font-weight:600;margin-bottom:4px">${escapeHtml(proj.name || `项目 ${i+1}`)}</div>
        <div style="font-size:13px;color:var(--text-2);margin-bottom:6px">${escapeHtml(proj.desc || "")}</div>
        <div class="pill-row">${(proj.tech || []).map(t => `<span class="mini-pill">${escapeHtml(t)}</span>`).join("")}</div>
      </div>`).join("") || "<p class='muted'>暂无项目经历</p>";

    /* 薪资预期 */
    const baseSalary = estimateSalary(p);
    salaryDiv.innerHTML = `
      <div class="kv" style="display:flex;flex-direction:column;align-items:center;text-align:center;padding:20px">
        <span class="hint">预估薪资区间 (年薪)</span>
        <b style="font-size:28px;color:var(--primary)">${baseSalary}k - ${baseSalary + 50}k</b>
      </div>
      <div style="margin-top:16px;padding:12px;background:#f8f9fe;border-radius:10px;font-size:13px;color:var(--text-2)">
        基于技能栈、项目经历、学历、岗位匹配度综合估算。实际薪资受公司规模、城市、面试表现等因素影响。
      </div>
    `;
  }

  function estimateSalary(profile) {
    let base = 15; // 万
    const degree = (profile.degree || "").toLowerCase();
    if (degree.includes("博士") || degree.includes("phd")) base += 15;
    else if (degree.includes("硕士") || degree.includes("master")) base += 8;
    else if (degree.includes("本科") || degree.includes("bachelor")) base += 3;
    const skills = profile.skills || [];
    const highValue = ["kubernetes", "spark", "flink", "kafka", "redis", "elasticsearch", "golang", "rust", "架构", "微服务", "高并发", "分布式"];
    skills.forEach(s => { if (highValue.some(h => s.toLowerCase().includes(h))) base += 3; });
    const projects = profile.projects || [];
    base += Math.min(projects.length * 2, 15);
    return Math.round(base);
  }
}

/* ---------------- 简历库管理 ---------------- */
async function renderResumeLibrary() {
  try {
    const data = await api("/api/resume/list");
    const resumes = data.resumes || [];
    $("rlStats").innerHTML = [
      ["database", "简历总数", resumes.length],
      ["file", "本月新增", resumes.filter(r => Date.now()/1000 - (r.created_at || 0) < 2592000).length],
      ["spark", "已优化", resumes.filter(r => r.optimized).length],
    ].map(([ic, l, n]) => `<div class="stat-card"><div class="sc-top"><span class="sc-ic">${ICONS[ic] || ""}</span><span class="lbl">${l}</span></div><div class="num">${n}</div></div>`).join("");

    $("rlList").innerHTML = resumes.length ? resumes.map((r) => `
      <div class="recent-item" data-rid="${r.rid}">
        <div>
          <div class="t">${escapeHtml(r.name || "候选人")} · ${escapeHtml(r.source || "上传")}</div>
          <div class="s">${fmtTime(r.created_at)} · 技能: ${(r.skills || []).slice(0, 5).join("、") || "—"}</div>
        </div>
        <div class="actions">
          <button class="mini" data-view-resume="${r.rid}">查看</button>
          <button class="mini" data-edit-resume="${r.rid}">编辑</button>
          <button class="mini" data-optimize-resume="${r.rid}">AI 优化</button>
          <button class="mini danger" data-del-resume="${r.rid}">删除</button>
        </div>
      </div>`).join("") : "<p class='hint'>暂无简历记录。去「简历分析」上传第一份简历吧。</p>";

    document.querySelectorAll("[data-view-resume]").forEach(b => b.addEventListener("click", () => viewResumeDetail(b.dataset.viewResume)));
    document.querySelectorAll("[data-edit-resume]").forEach(b => b.addEventListener("click", () => editResume(b.dataset.editResume)));
    document.querySelectorAll("[data-optimize-resume]").forEach(b => b.addEventListener("click", () => optimizeResumeInLibrary(b.dataset.optimizeResume)));
    document.querySelectorAll("[data-del-resume]").forEach(b => b.addEventListener("click", async () => {
      if (!(await confirmDialog("删除这份简历？", "删除后无法恢复。", "删除"))) return;
      try {
        await api(`/api/resume/${b.dataset.delResume}`, { method: "DELETE" });
        toast("已删除", "ok");
        renderResumeLibrary();
      } catch (e) { toast(e.message, "err"); }
    }));
  } catch (e) {
    const isAuth = e.message.includes("401") || e.message.includes("未登录");
    $("rlList").innerHTML = isAuth
      ? `<p class='hint'>请先登录后查看简历库。</p>`
      : `<p class='hint'>加载失败：${escapeHtml(e.message)}</p>`;
  }
}

async function viewResumeDetail(rid) {
  const detailBox = $("rlDetail");
  try {
    const data = await api(`/api/resume/${rid}`);
    const p = data.profile || {};
    detailBox.innerHTML = `
      <div class="grid-2">
        <div>
          <h3>${secTitle("user", "基础信息")}</h3>
          <div class="grid">${[
            ["姓名", p.name], ["院校", p.school || "-"], ["学历", p.degree], ["专业", p.major || "-"],
            ["技能", (p.skills || []).join("、") || "-"], ["项目数", (p.projects || []).length]
          ].map(([k, v]) => `<div class="kv"><span class="hint">${escapeHtml(k)}</span><b>${escapeHtml(v)}</b></div>`).join("")}</div>
        </div>
        <div>
          <h3>${secTitle("file", "项目经历")}</h3>
          <div class="panel-inner">${(p.projects || []).map((proj, i) => `
            <div style="margin-bottom:12px;padding:10px;background:#f8f9fe;border-radius:8px">
              <div style="font-weight:600">${escapeHtml(proj.name || `项目 ${i+1}`)}</div>
              <div style="font-size:13px;color:var(--text-2);margin:4px 0">${escapeHtml(proj.desc || "")}</div>
              <div class="pill-row">${(proj.tech || []).map(t => `<span class="mini-pill">${escapeHtml(t)}</span>`).join("")}</div>
            </div>`).join("") || "<p class='muted'>暂无</p>"}</div>
        </div>
      </div>
      <div class="row" style="margin-top:16px;justify-content:flex-end">
        <button class="mini" onclick="$('rlDetail').classList.add('hidden')">关闭</button>
        <button class="primary" onclick="editResume('${rid}');$('rlDetail').classList.add('hidden')">编辑优化</button>
      </div>`;
    detailBox.classList.remove("hidden");
    detailBox.scrollIntoView({ behavior: "smooth" });
  } catch (e) { toast(e.message, "err"); }
}

function editResume(rid) {
  showView("resume-analysis");
  setTimeout(async () => {
    try {
      const data = await api(`/api/resume/${rid}`);
      $("raResumeInput").value = data.text || "";
      $("raBtnParse").click();
    } catch (e) { toast(e.message, "err"); }
  }, 100);
}

async function optimizeResumeInLibrary(rid) {
  try {
    const data = await api(`/api/resume/${rid}`);
    const d = await api("/api/resume/optimize", { method: "POST", body: JSON.stringify({ text: data.text, job_name: "目标岗位" }) });
    await api(`/api/resume/${rid}/optimize`, { method: "POST", body: JSON.stringify({ optimized: d.optimized }) });
    toast("优化完成，已保存新版本", "ok");
    renderResumeLibrary();
  } catch (e) { toast(e.message, "err"); }
}

/* ---------------- 数字人面试官 ---------------- */
let avatarContainer = null;

function renderDigitalHuman() {
  if (!window._jobs) return;
  const jobSelect = $("dhJobSelect");
  const cats = window._jobCategories || {};
  const categorized = new Set();
  let html = '<option value="">请选择岗位</option>';
  for (const [cat, keys] of Object.entries(cats)) {
    const items = keys.map(k => window._jobs.find(j => j.key === k)).filter(Boolean);
    if (!items.length) continue;
    items.forEach(j => categorized.add(j.key));
    html += `<optgroup label="${escapeHtml(cat)}">${items.map(j => `<option value="${j.key}">${escapeHtml(j.name)}</option>`).join("")}</optgroup>`;
  }
  const uncategorized = (window._jobs || []).filter(j => !categorized.has(j.key));
  if (uncategorized.length) {
    html += `<optgroup label="其他">${uncategorized.map(j => `<option value="${j.key}">${escapeHtml(j.name)}</option>`).join("")}</optgroup>`;
  }
  jobSelect.innerHTML = html;

  const testVoiceBtn = $("dhBtnTestVoice");
  const startBtn = $("dhBtnStart");
  const voiceSelect = $("dhVoiceSelect");

  testVoiceBtn.onclick = testSparkTTS;
  startBtn.onclick = startDigitalHumanInterview;
  voiceSelect.onchange = () => { window._selectedVoice = voiceSelect.value; };
  
  // 选岗位时启用开始按钮
  jobSelect.onchange = () => { startBtn.disabled = !jobSelect.value; };
  
  // 初始状态
  startBtn.disabled = !jobSelect.value;

  // 直接加载头像
  loadAvatar();
}

function loadAvatar() {
  const container = $("live2dContainer");
  if (!container) return;
  avatarContainer = container;
  loadSimpleAvatar(container);
}

function loadSimpleAvatar(container) {
  container.innerHTML = `
    <div id="simpleAvatar" style="width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;position:relative;background:linear-gradient(135deg,#f0f0ff 0%,#e8eaff 100%);border-radius:20px;overflow:hidden">
      <div id="avatarHead" style="width:240px;height:280px;position:relative;border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(79,70,229,0.2)">
        <img src="/static/interviewer.png" alt="AI 虚拟面试官" style="width:100%;height:100%;object-fit:cover;object-position:center 15%;" />
      </div>
      <p style="margin-top:14px;color:var(--primary);font-size:14px;font-weight:700;letter-spacing:0.5px">AI 虚拟面试官</p>
      <p style="color:var(--muted);font-size:12px;margin-top:4px">支持语音交互 · 智能追问</p>
    </div>`;
}

/* ---------------- 讯飞星火 X2 语音合成 ---------------- */
async function testSparkTTS() {
  const btn = $("dhBtnTestVoice");
  const voice = window._selectedVoice || "x4_yezi";
  const text = "您好，我是智聘 AI 虚拟面试官，由讯飞星火 X2 驱动。很高兴为您进行模拟面试。";
  
  btn.disabled = true;
  btn.textContent = "合成中…";
  
  try {
    const audioData = await synthesizeSpeech(text, voice);
    if (audioData) {
      playAudio(audioData);
      toast("语音合成测试成功", "ok");
    } else {
      toast("语音合成失败，将使用浏览器内置语音", "warn");
      speakWithBrowser(text);
    }
  } catch (e) {
    console.error("TTS 测试失败:", e);
    toast("语音合成出错: " + e.message, "err");
    speakWithBrowser(text);
  } finally {
    btn.disabled = false;
    btn.textContent = "测试星火 X2 语音";
  }
}

async function synthesizeSpeech(text, voice = "x4_yezi") {
  try {
    const resp = await fetch("/api/tts", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify({ text, voice })
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.detail || "TTS 请求失败");
    if (data.source === "spark" && data.audio) {
      // base64 转 ArrayBuffer
      const binary = atob(data.audio);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      return bytes.buffer;
    }
    return null;
  } catch (e) {
    console.error("Spark TTS 失败:", e);
    return null;
  }
}

function playAudio(arrayBuffer) {
  const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  audioCtx.decodeAudioData(arrayBuffer, (buffer) => {
    const source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.connect(audioCtx.destination);
    source.start(0);
    // 触发唇形同步
    if (avatarContainer) triggerLipSync(buffer.duration);
  });
}

function triggerLipSync(duration) {
  if (!avatarContainer) return;
  const img = avatarContainer.querySelector("#avatarHead img");
  if (!img) return;
  // 照片模式：播放时添加呼吸光效
  img.style.transition = "filter 0.3s";
  img.style.filter = "brightness(1.05)";
  setTimeout(() => { img.style.filter = "brightness(1)"; }, duration * 1000);
}

function speakWithBrowser(text) {
  if (!window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "zh-CN";
  utterance.rate = 0.95;
  utterance.pitch = 1.0;
  utterance.volume = 1.0;
  // 优先选择中文语音中质量较好的
  const voices = window.speechSynthesis.getVoices();
  const preferred = ["Microsoft Xiaoxiao", "Microsoft Yunxi", "Google 普通话", "Google CN", "Xiaoxiao", "Yunxi", "Ting-Ting", "Zhiyu"];
  let chosen = null;
  for (const name of preferred) {
    const v = voices.find(v => v.name.includes(name) && v.lang.startsWith("zh"));
    if (v) { chosen = v; break; }
  }
  if (!chosen) chosen = voices.find(v => v.lang.startsWith("zh")) || null;
  if (chosen) utterance.voice = chosen;
  window.speechSynthesis.speak(utterance);
}

/* ---------------- 启动 AI 虚拟面试 ---------------- */
async function startDigitalHumanInterview() {
  const jobSelect = $("dhJobSelect");
  const jobKey = jobSelect.value;
  if (!jobKey) return toast("请先选择面试岗位", "err");
  
  if (!state.resumeText) {
    if (!(await confirmDialog("未检测到简历，是否前往「简历分析」上传？"))) return;
    showView("resume-analysis");
    return;
  }

  state.jobKey = jobKey;
  state.dhMode = $("dhModeSelect").value;
  state.dhDuration = parseInt($("dhDurationSelect").value);
  state.dhLang = $("dhLangSelect").value;
  state.dhVoice = window._selectedVoice || "x4_yezi";

  // 创建面试会话
  $("dhBtnStart").disabled = true;
  $("dhBtnStart").textContent = "创建面试中…";
  
  try {
    const data = await api("/api/interview/start", {
      method: "POST",
      body: JSON.stringify({ job_key: jobKey, resume_text: state.resumeText })
    });
    
    state.sessionId = data.session_id;
    state.finished = false;
    state.dhChatHistory = [];
    state.dhCurrentQuestion = data.content;
    
    // 切换到面试视图，但保持数字人显示
    showPhase("phase-interview");
    
    // 朗读第一个问题
    await speakQuestion(data.content);
    
    $("dhBtnStart").textContent = "面试进行中…";
    $("dhBtnStart").classList.add("danger");
    $("dhBtnStart").onclick = endDigitalHumanInterview;
    
  } catch (e) {
    toast(e.message, "err");
    $("dhBtnStart").disabled = false;
    $("dhBtnStart").textContent = "开始 AI 虚拟面试";
  }
}

async function speakQuestion(text) {
  const voice = state.dhVoice || "x4_yezi";
  const audioData = await synthesizeSpeech(text, voice);
  if (audioData) {
    playAudio(audioData);
  } else {
    speakWithBrowser(text);
  }
  
  // 显示在聊天区域
  appendMsg("ai", text, "AI 面试官");
}

async function endDigitalHumanInterview() {
  if (!(await confirmDialog("确定要结束面试吗？", "面试结束后将生成评估报告。", "确定结束"))) return;
  
  // 发送结束信号
  try {
    const data = await api("/api/interview/respond?session_id=" + state.sessionId, {
      method: "POST",
      body: JSON.stringify({ answer: "[面试结束]" })
    });
    
    if (data.type === "end") {
      state.finished = true;
      await generateReport();
      toast("面试结束，报告已生成", "ok");
    }
  } catch (e) {
    toast(e.message, "err");
  }
  
  $("dhBtnStart").textContent = "开始 AI 虚拟面试";
  $("dhBtnStart").classList.remove("danger");
  $("dhBtnStart").onclick = startDigitalHumanInterview;
  $("dhBtnStart").disabled = false;
}

/* ---------------- 候选人实时摄像头 ---------------- */
let camStream = null;
async function toggleCam() {
  const box = $("candCamBox"); const btn = $("btnCam");
  if (camStream) {
    camStream.getTracks().forEach((t) => t.stop());
    camStream = null; box.classList.add("hidden");
    btn.classList.remove("rec"); btn.textContent = "📷 打开摄像头";
    return;
  }
  try {
    camStream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: false });
    $("candCam").srcObject = camStream;
    box.classList.remove("hidden"); btn.classList.add("rec"); btn.textContent = "📷 关闭摄像头";
  } catch (e) { toast("无法开启摄像头：" + e.message + "（需 HTTPS 或 localhost，并授权摄像头权限）", "err"); }
}

/* ---------------- 岗位 JD 智能解析 ---------------- */
async function parseJD() {
  const text = $("jdInput").value.trim();
  if (text.length < 10) return toast("请先粘贴至少 10 字以上的岗位 JD", "err");
  $("btnParseJD").disabled = true; $("btnParseJD").textContent = "解析中…";
  try {
    const d = await api("/api/jd/parse", { method: "POST", body: JSON.stringify({ text }) });
    state.jdText = text;
    renderJD(d);
  } catch (e) { toast(e.message, "err"); }
  finally { $("btnParseJD").disabled = false; $("btnParseJD").textContent = "解析 JD"; }
}
function renderJD(d) {
  window._lastJD = d;
  const box = $("jdBox");
  const req = d.requirements || {};
  box.innerHTML = `
    <div class="kv" style="display:flex;gap:24px;flex-wrap:wrap"><span><b>岗位</b> ${escapeHtml(d.job_name)}</span><span><b>难度</b> ${escapeHtml(d.difficulty)}</span><span><b>学历</b> ${escapeHtml(req.degree || "—")}</span><span><b>经验</b> ${req.experience_years ? req.experience_years + " 年" : "—"}</span></div>
    <h4 style="margin:12px 0 6px">核心技能</h4><div class="pill-row">${(d.core_skills || []).map((s) => `<span class="mini-pill">${escapeHtml(s)}</span>`).join("") || "<span class='hint'>—</span>"}</div>
    <h4 style="margin:12px 0 6px">九维考察权重</h4><div class="pill-row">${Object.entries(d.nine_weights || {}).map(([k, v]) => `<span class="mini-pill">${escapeHtml(k)} ${Math.round(v * 100)}%</span>`).join("")}</div>
    <h4 style="margin:12px 0 6px">个性化面试题库（${(d.questions || []).length} 道）</h4>
    <div style="display:grid;gap:6px">${(d.questions || []).map((q, i) => `<div><b>Q${i + 1}·${escapeHtml(q.dimension)}</b> ${escapeHtml(q.text)}</div>`).join("")}</div>
    <div class="row" style="margin-top:14px"><button id="btnStartJD" class="primary">用此 JD 开始面试</button><button id="btnClearJD2" class="mini">清空 JD</button></div>`;
  box.classList.remove("hidden");
  $("btnStartJD").addEventListener("click", () => startInterview(true));
  $("btnClearJD2").addEventListener("click", () => { $("jdInput").value = ""; box.classList.add("hidden"); state.jdText = null; });
}
function clearJD() { $("jdInput").value = ""; $("jdBox").classList.add("hidden"); state.jdText = null; }

/* ---------------- 简历工具 ---------------- */
async function optimizeResume() {
  const text = $("resumeInput").value.trim();
  if (text.length < 20) return toast("请先粘贴简历内容", "err");
  const jobName = state.jdText ? (window._lastJD && window._lastJD.job_name) : (jobNameByKey());
  $("btnOptimize").disabled = true; $("btnOptimize").textContent = "优化中…";
  try {
    const d = await api("/api/resume/optimize", { method: "POST", body: JSON.stringify({ text, job_name: jobName || "目标岗位" }) });
    showToolBox(`${secTitle("spark", "AI 简历优化完成")}<h4>优化要点</h4><ul>${(d.changes || []).map((c) => `<li>${escapeHtml(c)}</li>`).join("")}</ul><h4>优化后简历（可复制使用）</h4><pre class="resume-out">${escapeHtml(d.optimized)}</pre>`);
  } catch (e) { toast(e.message, "err"); }
  finally { $("btnOptimize").disabled = false; $("btnOptimize").textContent = "AI 简历优化"; }
}
function jobNameByKey() { return ((window._jobs || []).find((j) => j.key === state.jobKey)?.name) || ""; }
async function analyzeResume() {
  const text = $("resumeInput").value.trim();
  if (text.length < 20) return toast("请先粘贴简历内容", "err");
  $("btnAnalyze").disabled = true; $("btnAnalyze").textContent = "检测中…";
  try {
    const d = await api("/api/resume/analyze", { method: "POST", body: JSON.stringify({ text }) });
    const color = d.level === "优秀" ? "green" : d.level === "良好" ? "" : "warn";
    showToolBox(`${secTitle("shield", "简历健康度")}<div class="pill-row" style="margin:2px 0 10px"><span class="badge ${color}" style="padding:5px 14px">${escapeHtml(d.level)} ${d.health}/100</span></div>${(d.issues || []).length ? `<ul>${d.issues.map((i) => `<li><b>[${escapeHtml(i.severity)}·${escapeHtml(i.type)}]</b> ${escapeHtml(i.advice)}</li>`).join("")}</ul>` : "<p style='margin-top:8px'>未发现明显风险，简历结构完整、表述清晰。</p>"}`);
  } catch (e) { toast(e.message, "err"); }
  finally { $("btnAnalyze").disabled = false; $("btnAnalyze").textContent = "简历风险检测"; }
}
async function showTemplates() {
  try {
    const d = await api("/api/resume/templates");
    showToolBox(`${secTitle("grid", "简历模板库")}<div class="job-grid" id="tplList">${(d.templates || []).map((t) => `
      <div class="job-card" data-key="${t.key}"><div class="t" style="font-weight:700">${escapeHtml(t.name)}</div><div class="hint">${escapeHtml(t.category)} · ${escapeHtml(t.style)}</div><div style="font-size:12px;color:var(--muted)">${escapeHtml(t.sections.join(" / "))}</div></div>`).join("")}</div>`);
    document.querySelectorAll("#tplList .job-card").forEach((card) => card.addEventListener("click", () => applyTemplate(card.dataset.key)));
  } catch (e) { toast(e.message, "err"); }
}
async function applyTemplate(key) {
  const text = $("resumeInput").value.trim();
  if (text.length < 20) return toast("请先在简历框粘贴简历内容，再选择模板", "err");
  try {
    const d = await api("/api/resume/apply-template", { method: "POST", body: JSON.stringify({ template_key: key, text }) });
    showToolBox(`${secTitle("file", "已套用模板：" + d.template)}<pre class="resume-out">${escapeHtml(d.optimized)}</pre>`);
  } catch (e) { toast(e.message, "err"); }
}
function showToolBox(html) { const box = $("resumeToolBox"); box.innerHTML = html; box.classList.remove("hidden"); box.scrollIntoView({ behavior: "smooth", block: "nearest" }); }

/* ---------------- 简历解析 / 画像 ---------------- */
async function parseResume() {
  const text = $("resumeInput").value.trim();
  if (text.length < 20) return toast("请先粘贴至少 20 字以上的简历内容", "err");
  state.resumeText = text;
  $("btnParse").disabled = true; $("btnParse").textContent = "解析中…";
  try {
    const data = await api("/api/resume/parse", { method: "POST", body: JSON.stringify({ text }) });
    renderProfile(data); renderRanking(data.ranking); renderJobs(data.recommended_job);
    // 同步到简历分析页面
    if ($("raResumeInput")) $("raResumeInput").value = text;
    $("profileBox").classList.remove("hidden");
    toast("简历解析成功！请在下方选择面试岗位", "ok");
  } catch (e) { toast(e.message, "err"); }
  finally { $("btnParse").disabled = false; $("btnParse").textContent = "解析简历"; }
}
function renderProfile(data) {
  const p = data.profile;
  const items = [
    ["姓名", p.name], ["院校", p.school || "-"], ["学历", p.degree], ["专业", p.major || "-"],
    ["技能标签", (p.skills || []).join("、") || "-"], ["项目经历", (p.projects || []).length + " 项"],
  ];
  $("profileGrid").innerHTML = items.map(([k, v]) => `<div class="kv" style="display:flex;flex-direction:column"><span class="hint">${escapeHtml(k)}</span><b>${escapeHtml(v)}</b></div>`).join("");
}
function renderRanking(ranking) {
  const max = ranking[0]?.[1] || 1;
  $("jobRanking").innerHTML = ranking.slice(0, 5).map(([key, score]) => `
    <div class="recent-item"><span style="width:110px">${escapeHtml(jobName(key))}</span>
    <div class="bar" style="flex:1"><i style="width:${(score / max) * 100}%"></i></div><span>${Math.round(score * 100)}%</span></div>`).join("");
}
function renderJobs(recommendedKey) {
  const jobs = window._jobs || [];
  const cats = window._jobCategories || {};
  const categorized = new Set();
  let html = "";
  for (const [cat, keys] of Object.entries(cats)) {
    const items = keys.map(k => jobs.find(j => j.key === k)).filter(Boolean);
    if (!items.length) continue;
    items.forEach(j => categorized.add(j.key));
    html += `<div class="job-cat-label">${escapeHtml(cat)}</div>`;
    html += items.map(j => `<div class="job-item" data-key="${j.key}">${escapeHtml(j.name)}${j.key === recommendedKey ? " · 推荐" : ""}</div>`).join("");
  }
  const rest = jobs.filter(j => !categorized.has(j.key));
  if (rest.length) {
    html += `<div class="job-cat-label">其他</div>`;
    html += rest.map(j => `<div class="job-item" data-key="${j.key}">${escapeHtml(j.name)}${j.key === recommendedKey ? " · 推荐" : ""}</div>`).join("");
  }
  $("jobList").innerHTML = html;
  document.querySelectorAll("#jobList .job-item").forEach((el) => {
    el.addEventListener("click", () => {
      document.querySelectorAll("#jobList .job-item").forEach((x) => x.classList.remove("selected"));
      el.classList.add("selected");
      state.jobKey = el.dataset.key;
      // 检查简历是否已上传
      if (!state.resumeText) {
        toast("请先在上方输入或上传简历", "err");
        $("btnStart").disabled = true;
      } else {
        $("btnStart").disabled = false;
      }
    });
  });
}

/* ---------------- 面试 ---------------- */
// 分析面板状态
let analysisVisible = true;

function updateAnalysisPanel(data) {
  if (!analysisVisible) return;
  
  // 更新当前问题
  const questionEl = $("currentQuestion");
  if (data.question) {
    questionEl.innerHTML = `<p style="font-weight:500;margin:0">${escapeHtml(data.question)}</p>`;
  }
  
  // 更新回答要点
  const keyPointsEl = $("answerKeyPoints");
  if (data.key_points && data.key_points.length > 0) {
    keyPointsEl.innerHTML = `<ul class="key-points-list">${data.key_points.map(kp => `<li>${escapeHtml(kp)}</li>`).join("")}</ul>`;
  }
  
  // 更新评估维度
  const dimensionEl = $("evaluationDimension");
  if (data.dimension) {
    dimensionEl.innerHTML = `<div class="dimension-tag">${escapeHtml(data.dimension)}</div>`;
  }
  
  // 更新追问方向
  const followUpEl = $("followUpDirection");
  if (data.follow_up) {
    followUpEl.innerHTML = `<p>${escapeHtml(data.follow_up)}</p>`;
  }
}

function updateAnswerQuality(score, hint) {
  const bar = $("qualityBar");
  const hintEl = $("qualityHint");
  if (bar) bar.style.width = `${Math.min(100, Math.max(0, score))}%`;
  if (hintEl) hintEl.textContent = hint || "等待回答...";
}

async function startInterview(useJD) {
  // 检查简历是否已上传
  if (!state.resumeText) {
    toast("请先在上方输入或上传简历内容", "err");
    return;
  }
  
  $("btnStart").disabled = true;
  const body = { resume_text: state.resumeText };
  if (useJD) {
    if (!state.jdText) { $("btnStart").disabled = false; return toast("请先解析 JD", "err"); }
    body.jd = state.jdText;
  } else {
    if (!state.jobKey) { $("btnStart").disabled = false; return toast("请先选择面试岗位", "err"); }
    body.job_key = state.jobKey;
  }
  try {
    const data = await api("/api/interview/start", { method: "POST", body: JSON.stringify(body) });
    state.sessionId = data.session_id; state.finished = false;
    const meta = useJD ? "自定义 JD 直聘面试" : (jobName(state.jobKey) || state.jobKey);
    $("interviewMeta").textContent = `岗位：${meta} · 请认真作答，系统将根据回答深度追问并评估九维胜任力`;
    $("chat").innerHTML = "";
    appendMsg("ai", data.content, "面试官");
    showPhase("phase-interview");
    
    // 初始化分析面板
    updateAnalysisPanel({
      question: "自我介绍",
      key_points: ["教育背景", "工作经历", "核心技能", "项目亮点", "职业目标"],
      dimension: "自我认知",
      follow_up: "根据自我介绍内容，可能会追问具体项目细节或技术栈深度"
    });
    updateAnswerQuality(0, "等待回答...");
    
    $("answerInput").focus();
  } catch (e) { toast(e.message, "err"); }
  finally { $("btnStart").disabled = false; }
}
function appendMsg(role, text, tag) {
  const box = $("chat");
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  if (tag) div.innerHTML = `<span class="tag">${escapeHtml(tag)}</span>${escapeHtml(text)}`;
  else div.textContent = text;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
  return div;
}
async function sendAnswer() {
  const input = $("answerInput");
  const text = input.value.trim();
  if (!text || state.finished) return;
  appendMsg("me", text);
  input.value = "";
  $("btnSend").disabled = true;
  
  // 评估回答质量
  const wordCount = text.length;
  const qualityScore = Math.min(100, Math.floor(wordCount / 5));
  updateAnswerQuality(qualityScore, wordCount < 20 ? "回答较简短，建议补充细节" : wordCount < 100 ? "回答长度适中" : "回答详细");
  
  const typing = appendMsg("ai", "", "面试官");
  typing.classList.add("typing");
  typing.innerHTML = `<span class="tag">面试官</span><i></i><i></i><i></i>`;
  try {
    const data = await api("/api/interview/respond?session_id=" + state.sessionId, { method: "POST", body: JSON.stringify({ answer: text }) });
    typing.remove();
    if (data.type === "end") {
      state.finished = true;
      appendMsg("ai", data.content, "面试官");
      $("btnReport").classList.remove("hidden"); $("btnReport").disabled = false;
      updateAnalysisPanel({
        question: "面试结束",
        key_points: ["请等待生成评估报告"],
        dimension: "综合评估",
        follow_up: "点击「生成评估报告」查看详细分析"
      });
    } else {
      appendMsg("ai", data.content, data.type === "followup" ? "面试官 · 追问" : `面试官 · 第 ${data.round} 题`);
      if (data.eval) appendMsg("meta", `【${data.eval.level}】${data.eval.comment}`, data.eval.score + " / 5");
      
      // 更新分析面板
      const nextQuestion = data.type === "followup" ? "追问" : `第 ${data.round} 题`;
      updateAnalysisPanel({
        question: data.content.substring(0, 50) + (data.content.length > 50 ? "..." : ""),
        key_points: getNextKeyPoints(data.round),
        dimension: getDimensionName(data.round),
        follow_up: data.type === "followup" ? "深入追问当前话题" : "准备下一个问题"
      });
      updateAnswerQuality(0, "等待回答...");
    }
  } catch (e) { typing.remove(); appendMsg("ai", "出错了：" + e.message, "系统"); }
  finally { $("btnSend").disabled = false; input.focus(); }
}

function getNextKeyPoints(round) {
  const points = {
    1: ["教育背景", "专业技能", "实习/项目经历", "职业规划"],
    2: ["技术深度", "项目细节", "问题解决能力", "团队协作"],
    3: ["系统设计", "架构思维", "技术选型", "性能优化"],
    4: ["沟通表达", "逻辑思维", "应变能力", "学习能力"],
    5: ["职业动机", "价值观", "稳定性", "发展规划"],
    6: ["综合评估", "岗位匹配", "潜力分析", "录用建议"]
  };
  return points[round] || ["待评估"];
}

function getDimensionName(round) {
  const dimensions = {
    1: "专业知识",
    2: "技术能力",
    3: "系统思维",
    4: "沟通协作",
    5: "职业素养",
    6: "综合评估"
  };
  return dimensions[round] || "待评估";
}

/* ---------------- 报告 ---------------- */
const stateRadar = { dims: [], scores: [] };
function drawRadar(canvas, dims, scores) {
  if (!canvas || !dims.length) return;
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth || 300, h = canvas.clientHeight || 320;
  canvas.width = w * dpr; canvas.height = h * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  const cx = w / 2, cy = h / 2;
  const R = Math.min(w, h) / 2 - 42;
  const n = dims.length, max = 5;
  const angle = (i) => (-Math.PI / 2) + (2 * Math.PI * i) / n;
  const pt = (i, r) => [cx + r * Math.cos(angle(i)), cy + r * Math.sin(angle(i))];
  for (let ring = 1; ring <= max; ring++) {
    ctx.beginPath();
    for (let i = 0; i < n; i++) { const [x, y] = pt(i, (R * ring) / max); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
    ctx.closePath();
    ctx.strokeStyle = ring === max ? "rgba(79,70,229,.4)" : "rgba(79,70,229,.14)"; ctx.lineWidth = 1; ctx.stroke();
  }
  for (let i = 0; i < n; i++) { const [x, y] = pt(i, R); ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(x, y); ctx.strokeStyle = "rgba(79,70,229,.14)"; ctx.stroke(); }
  ctx.font = "11px 'PingFang SC','Microsoft YaHei',sans-serif"; ctx.fillStyle = "#6b7690"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
  for (let i = 0; i < n; i++) { const [x, y] = pt(i, R + (n > 7 ? 30 : 24)); ctx.fillText(dims[i], x, y); }
  const data = scores.map((s) => Math.max(0, Math.min(max, s)));
  ctx.beginPath();
  for (let i = 0; i < n; i++) { const [x, y] = pt(i, (R * data[i]) / max); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
  ctx.closePath(); ctx.fillStyle = "rgba(79,70,229,.22)"; ctx.fill(); ctx.strokeStyle = "#4f46e5"; ctx.lineWidth = 2; ctx.stroke();
  for (let i = 0; i < n; i++) { const [x, y] = pt(i, (R * data[i]) / max); ctx.beginPath(); ctx.arc(x, y, 4, 0, Math.PI * 2); ctx.fillStyle = "#4f46e5"; ctx.fill(); ctx.strokeStyle = "#fff"; ctx.lineWidth = 1.5; ctx.stroke(); }
}
async function generateReport() {
  $("btnReport").disabled = true; $("btnReport").textContent = "报告中…";
  try {
    const data = await api(`/api/interview/${state.sessionId}/report`);
    renderReport(data);
    showPhase("phase-report");
  } catch (e) { toast(e.message, "err"); }
  finally { $("btnReport").textContent = "生成评估报告"; }
}
function renderReport(data) {
  const r = data.report;
  const ratingColor = data.rating === "A" ? "green" : data.rating === "B" ? "" : "warn";
  $("ratingBadge").textContent = `胜任力评级：${data.rating}`;
  $("ratingBadge").className = "badge " + ratingColor;
  $("decisionBadge").textContent = `录用建议：${r.decision}`;
  $("decisionBadge").className = "badge warn";
  $("reportSummary").innerHTML = `${secTitle("clipboard", "评估结论")}<p style="font-size:14px;line-height:1.8;margin-top:8px">${escapeHtml(r.summary)}</p>`;
  stateRadar.dims = data.radar.dimensions; stateRadar.scores = data.radar.scores;
  drawRadar($("radarCanvas"), stateRadar.dims, stateRadar.scores);
  $("matchPanel").innerHTML = `
    <div class="match-circle" style="--p:${data.match_percent}"><div class="ring"><div class="inner"><span class="num">${data.match_percent}%</span><span class="lbl">岗位匹配度</span></div></div></div>
    <div class="stat">综合胜任力得分 <b>${data.match_score.toFixed(1)} / 5.0</b></div>
    <div class="stat">有效作答 <b>${data.question_count}</b> 题 · 维度覆盖 <b>${Math.round(data.completeness * 100)}%</b></div>
    <div class="stat">目标岗位 <b>${escapeHtml(data.job.name)}</b></div>`;
  const nine = data.nine_scores || [];
  $("nineTableBox").innerHTML = `${secTitle("grid", "九维胜任力评分明细")}<table class="nine-table"><tr><th>维度</th><th>得分</th><th>分布</th><th>权重</th><th>维度</th><th>得分</th><th>分布</th><th>权重</th></tr>${(() => {
    const rows = [];
    for (let i = 0; i < nine.length; i += 2) {
      const cells = [];
      for (let j = i; j < Math.min(i + 2, nine.length); j++) {
        const it = nine[j];
        cells.push(`<td>${escapeHtml(it.dimension)}</td><td><b>${it.score.toFixed(1)}</b></td><td><div class="bar"><i style="width:${(it.score / 5) * 100}%"></i></div></td><td>${Math.round(it.weight * 100)}%</td>`);
      }
      while (cells.length < 8) cells.push("<td></td><td></td><td></td><td></td>");
      rows.push("<tr>" + cells.join("") + "</tr>");
    }
    return rows.join("");
  })()}</table>`;
  $("strengthBox").innerHTML = `${secTitle("star", "优势亮点")}<ul>${r.strengths.map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ul>`;
  $("weaknessBox").innerHTML = `${secTitle("flag", "短板风险")}<ul>${r.weaknesses.map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ul>`;
  $("reviewBox").innerHTML = `${secTitle("mic", "面试表现复盘")}<ul>${(r.review || []).map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ul>`;
  const mm = r.multimodal;
  if (mm) {
    const stat = (mm.avg_speech_rate || mm.avg_pause_count || mm.avg_duration_sec) ? `<div class="stat" style="margin:6px 0">语速 <b>${mm.avg_speech_rate || "—"}</b> 字/分 · 停顿 <b>${mm.avg_pause_count || "—"}</b> 次 · 均长 <b>${mm.avg_duration_sec || "—"}</b> 秒</div>` : "";
    const per = (mm.per_question || []).map((p) => `<span class="mini-pill">${escapeHtml(p.dimension)} ${p.score.toFixed(1)} · ${escapeHtml(p.level)}</span>`).join("");
    $("multimodalBox").innerHTML = `${secTitle("video", "多模态面试数据（语音/行为分析）")}${stat}<ul>${(mm.notes || []).map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ul>${per ? `<div class="pill-row">${per}</div>` : ""}`;
  } else $("multimodalBox").innerHTML = "";
  $("riskBox").innerHTML = `${secTitle("shield", "风险提示（防作弊识别）")}<ul>${(r.risk || []).map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ul>`;
  $("suggestBox").innerHTML = `${secTitle("bulb", "改进提升方案")}<ul>${r.suggestions.map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ul>`;
  $("resumeAdviceBox").innerHTML = `${secTitle("file", "简历优化建议")}<ul>${(r.resume_advice || []).map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ul>`;
  $("prepAdviceBox").innerHTML = `${secTitle("book", "面试备考建议")}<ul>${(r.prep_advice || []).map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ul>`;
  const pdfBtn = $("btnReportPDF");
  pdfBtn.onclick = async () => {
    pdfBtn.disabled = true; pdfBtn.textContent = "生成中…";
    try {
      const resp = await fetch(`/api/interview/${state.sessionId}/report.pdf`, { headers: authHeaders() });
      if (!resp.ok) throw new Error("导出失败");
      const blob = await resp.blob();
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
      a.download = `胜任力评估报告_${state.sessionId}.pdf`; a.click();
      URL.revokeObjectURL(a.href);
    } catch (e) { toast(e.message, "err"); }
    finally { pdfBtn.disabled = false; pdfBtn.textContent = "导出 PDF 报告"; }
  };
}

function authHeaders() { const h = {}; if (state.token) h["Authorization"] = "Bearer " + state.token; return h; }

/* ---------------- 我的报告 / 历史 ---------------- */
async function loadHistory() {
  try {
    const d = await api("/api/history");
    const list = d.sessions || [];
    const avg = list.length ? Math.round(list.reduce((s, x) => s + (x.match_percent || 0), 0) / list.length) + "%" : "—";
    const cards = [
      ["video", "总面试", d.total_sessions || 0],
      ["user", "简历处理", d.total_resumes || 0],
      ["target", "平均匹配度", avg],
    ];
    $("historyStats").innerHTML = cards.map(([ic, l, n]) => `<div class="stat-card"><div class="sc-top"><span class="sc-ic">${ICONS[ic] || ""}</span><span class="lbl">${l}</span></div><div class="num">${n}</div></div>`).join("");
    $("historyList").innerHTML = list.length ? list.map((s) => `
      <div class="recent-item">
        <div><div class="t">${escapeHtml(s.candidate)} · ${escapeHtml(s.job_name || "—")}</div><div class="s">${fmtTime(s.created_at)} · 匹配度 ${s.match_percent || 0}% · 得分 ${(s.match_score || 0).toFixed(1)}/5</div></div>
        <div class="actions"><button class="mini" data-viewone="${s.sid}">查看</button><button class="mini" data-delone="${s.sid}" style="background:#fee2e2;color:#b91c1c">删除</button></div>
      </div>`).join("") : "<p class='hint'>暂无面试记录。完成一次面试并生成报告后会按账号保存。</p>";
    document.querySelectorAll("[data-viewone]").forEach((b) => b.addEventListener("click", () => viewHistory(b.dataset.viewone)));
    document.querySelectorAll("[data-delone]").forEach((b) => b.addEventListener("click", async () => {
      if (!(await confirmDialog("删除这条面试记录？", "删除后该场面试的评估报告将无法恢复。", "删除"))) return;
      await api(`/api/history/${b.dataset.delone}`, { method: "DELETE" });
      toast("已删除该面试记录", "ok");
      loadHistory();
    }));
    $("historyDetail").classList.add("hidden");
  } catch (e) { $("historyList").innerHTML = `<p class='hint'>${escapeHtml(e.message)}</p>`; }
}
async function viewHistory(sid) {
  const box = $("historyDetail");
  try {
    const data = await api(`/api/history/${sid}`);
    renderReport(data);
    box.classList.remove("hidden");
    const src = $("reportBox");
    box.innerHTML = `<h3>历史报告回看</h3>` + src.innerHTML;
    /* innerHTML 克隆不保留 canvas 位图，回看视图需重绘雷达图 */
    const cloneCanvas = box.querySelector("#radarCanvas");
    if (cloneCanvas && data.radar) drawRadar(cloneCanvas, data.radar.dimensions, data.radar.scores);
    /* 克隆出的按钮不带事件，移除后使用下方专用的历史导出按钮 */
    box.querySelector(".report-actions")?.remove();
    const pdfBtn = document.createElement("button");
    pdfBtn.className = "primary"; pdfBtn.style.marginTop = "14px";
    pdfBtn.textContent = "导出此份 PDF 报告";
    pdfBtn.onclick = async () => {
      pdfBtn.disabled = true;
      const resp = await fetch(`/api/interview/${sid}/report.pdf`, { headers: authHeaders() });
      if (!resp.ok) return toast("导出失败", "err");
      const blob = await resp.blob();
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
      a.download = `胜任力评估报告_${sid}.pdf`; a.click();
      pdfBtn.disabled = false;
    };
    box.appendChild(pdfBtn);
    box.scrollIntoView({ behavior: "smooth" });
  } catch (e) { toast(e.message, "err"); }
}

/* ---------------- AI 助手（自由问答） ---------------- */
const AI_MODES = {
  career: {
    label: "求职咨询",
    welcome: "你好，我是你的求职顾问。offer 选择、秋招规划、行业与城市选择、谈薪策略，都可以直接问我。",
    prompts: ["计算机应届生怎么选 offer？", "秋招时间线应该怎么规划？", "小厂正式 offer 和大厂外包怎么选？"],
  },
  tech: {
    label: "技术答疑",
    welcome: "我是技术答疑助手。概念原理、八股文、实战排错都可以问，我会尽量讲透本质。",
    prompts: ["MySQL 索引失效的常见场景有哪些？", "Redis 缓存穿透、击穿、雪崩的区别？", "TCP 为什么是三次握手而不是两次？"],
  },
  resume: {
    label: "简历诊断",
    welcome: "把简历片段或项目经历贴给我，我会指出问题并直接给出改写后的版本。",
    prompts: ["这段项目经历怎么写更有亮点？", "应届生简历应该一页还是两页？", "没有实习经历，简历怎么写？"],
  },
  interview: {
    label: "面试准备",
    welcome: "告诉我目标岗位或你担心的面试题，我给你考察点分析、回答框架和高分要点。",
    prompts: ["面试自我介绍应该怎么说？", "被问「离职原因」怎么回答？", "讲讲 HashMap 的底层原理怎么答"],
  },
};
const AI = { history: [], mode: "career", busy: false };

function aiStorageKey() {
  return "zp_ai_" + (state.user ? state.user.username : "guest");
}
function aiSaveHistory() {
  try {
    localStorage.setItem(aiStorageKey(), JSON.stringify({ mode: AI.mode, history: AI.history.slice(-40) }));
  } catch {}
}
function aiLoadHistory() {
  try {
    const d = JSON.parse(localStorage.getItem(aiStorageKey()) || "{}");
    AI.mode = AI_MODES[d.mode] ? d.mode : "career";
    AI.history = Array.isArray(d.history) ? d.history.slice(-40) : [];
  } catch { AI.history = []; }
}
function initAssistant() {
  aiLoadHistory();
  renderAiMode();
  renderAiQuick();
  renderAiChat();
  refreshAiEngineBadge();
}
function renderAiMode() {
  document.querySelectorAll("#aiModeChips .chip").forEach((c) => c.classList.toggle("active", c.dataset.mode === AI.mode));
}
function renderAiQuick() {
  const conf = AI_MODES[AI.mode];
  $("aiQuick").innerHTML = (conf.prompts || [])
    .map((p) => `<button class="quick-pill">${escapeHtml(p)}</button>`).join("");
  document.querySelectorAll("#aiQuick .quick-pill").forEach((b) =>
    b.addEventListener("click", () => { $("aiInput").value = b.textContent; $("aiInput").focus(); }));
}
function aiAppendMsg(role, text) {
  const box = $("aiChat");
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  if (role === "meta") {
    div.textContent = text;
  } else {
    div.innerHTML = `<span class="tag">${role === "me" ? "我" : "AI 助手"}</span>`;
    const body = document.createElement("span");
    body.className = "msg-body";
    body.textContent = text;
    div.appendChild(body);
  }
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
  return div;
}
function renderAiChat() {
  const conf = AI_MODES[AI.mode];
  $("aiChat").innerHTML = "";
  if (!AI.history.length) {
    aiAppendMsg("ai", conf.welcome);
    return;
  }
  for (const m of AI.history) aiAppendMsg(m.role === "user" ? "me" : "ai", m.content);
}
function refreshAiEngineBadge() {
  const el = $("aiEngineBadge");
  api("/api/assistant/status").then((d) => {
    if (d.provider === "openai") { el.textContent = `引擎：${d.model}`; el.classList.add("live"); }
    else if (d.provider === "spark") { el.textContent = "引擎：讯飞星火"; el.classList.add("live"); }
    else { el.textContent = "离线演示模式 · 点「模型设置」接入大模型"; el.classList.remove("live"); }
  }).catch(() => { el.textContent = "服务未连接"; });
}
async function aiStream(payload, onDelta) {
  const headers = { "Content-Type": "application/json" };
  if (state.token) headers["Authorization"] = "Bearer " + state.token;
  const resp = await fetch("/api/assistant/chat/stream", { method: "POST", headers, body: JSON.stringify(payload) });
  if (!resp.ok || !resp.body) throw new Error("流式接口不可用");
  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const parts = buf.split("\n\n");
    buf = parts.pop();
    for (const part of parts) {
      const line = part.trim();
      if (!line.startsWith("data:")) continue;
      let obj;
      try { obj = JSON.parse(line.slice(5)); } catch { continue; }
      if (obj.delta) onDelta(obj.delta);
      if (obj.error) throw new Error(obj.error);
      if (obj.done) return;
    }
  }
}
async function aiSend() {
  const input = $("aiInput");
  const text = input.value.trim();
  if (!text || AI.busy) return;
  input.value = "";
  AI.history.push({ role: "user", content: text });
  aiAppendMsg("me", text);
  AI.busy = true;
  $("btnAiSend").disabled = true;
  const bubble = aiAppendMsg("ai", "");
  bubble.classList.add("typing");
  bubble.innerHTML = `<span class="tag">AI 助手</span><i></i><i></i><i></i>`;
  let answer = "";
  const write = (piece) => {
    if (!answer) {
      bubble.classList.remove("typing");
      bubble.innerHTML = `<span class="tag">AI 助手</span>`;
      const body = document.createElement("span");
      body.className = "msg-body";
      bubble.appendChild(body);
    }
    answer += piece;
    bubble.querySelector(".msg-body").textContent = answer;
    $("aiChat").scrollTop = $("aiChat").scrollHeight;
  };
  const payload = { message: text, history: AI.history.slice(0, -1).slice(-12), mode: AI.mode };
  try {
    await aiStream(payload, write);
  } catch (streamErr) {
    try {
      const d = await api("/api/assistant/chat", { method: "POST", body: JSON.stringify(payload) });
      write(d.reply || "(空回复)");
    } catch (e) {
      bubble.classList.remove("typing");
      bubble.innerHTML = `<span class="tag">AI 助手</span><span class="msg-body">出错了：${escapeHtml(e.message)}</span>`;
    }
  }
  if (answer) {
    AI.history.push({ role: "assistant", content: answer });
    aiSaveHistory();
  }
  AI.busy = false;
  $("btnAiSend").disabled = false;
  input.focus();
}
async function aiClear() {
  if (AI.history.length && !(await confirmDialog("清空当前对话？", "对话记录仅保存在本机浏览器，清空后不可恢复。", "清空"))) return;
  AI.history = [];
  aiSaveHistory();
  renderAiChat();
}
function aiSwitchMode(mode) {
  if (AI.busy || AI.mode === mode) return;
  AI.mode = mode;
  aiSaveHistory();
  renderAiMode();
  renderAiQuick();
  renderAiChat();
}
/* 模型设置弹窗 */
async function openAiSettings() {
  let cfg = { base_url: "", model: "", api_key_set: false, api_key_hint: "", api_secret_set: false, app_id: "" };
  try {
    const d = await api("/api/llm/config");
    if (d.config) cfg = d.config;
  } catch {}
  const mask = document.createElement("div");
  mask.className = "modal-mask";
  const isXf = (cfg.base_url || "").includes("xf-yun.com") || (cfg.base_url || "").startsWith("wss://");
  mask.innerHTML = `
    <div class="modal" style="width:min(520px,100%)">
      <h4>接入大模型</h4>
      <p>选择预设免费模型或自定义填入任意 OpenAI 兼容服务，保存后立即生效。</p>
      <div class="modal-form">
        <label>快速选择预设模型
          <select id="aiSetPreset" style="width:100%;padding:8px;border:1px solid var(--border);border-radius:6px;margin-top:4px">
            <option value="">-- 自定义配置 --</option>
            <option value="siliconflow">硅基流动 (免费14元额度，推荐)</option>
            <option value="deepseek">DeepSeek (500万token免费)</option>
            <option value="kimi">Moonshot Kimi (免费额度)</option>
            <option value="zhipu">智谱GLM (免费额度)</option>
            <option value="ollama">本地 Ollama (完全免费)</option>
          </select>
        </label>
        <label>接口地址 base_url
          <input id="aiSetBase" placeholder="https://api.siliconflow.cn/v1" value="${escapeHtml(cfg.base_url || "")}" />
        </label>
        <label>API Key${cfg.api_key_set ? `（已配置 ${escapeHtml(cfg.api_key_hint)}，留空表示保留）` : "（本地 Ollama 等可留空）"}
          <input id="aiSetKey" type="password" placeholder="${cfg.api_key_set ? "留空则继续使用已保存的 Key" : "sk-..."}" />
        </label>
        <label>模型名称
          <input id="aiSetModel" placeholder="Qwen/Qwen2.5-7B-Instruct" value="${escapeHtml(cfg.model || "")}" />
        </label>
        <div id="xfFields" style="display:${isXf ? "block" : "none"}">
          <label>讯飞 APP ID
            <input id="aiSetAppId" placeholder="9f38fc25" value="${escapeHtml(cfg.app_id || "")}" />
          </label>
          <label>讯飞 API Secret${cfg.api_secret_set ? "（已配置，留空表示保留）" : ""}
            <input id="aiSetApiSecret" type="password" placeholder="${cfg.api_secret_set ? "留空则继续使用" : "API Secret"}" />
          </label>
        </div>
      </div>
      <div class="ai-test-result" id="aiTestResult"></div>
      <div class="modal-actions">
        <button class="mini" data-act="cancel">关闭</button>
        <button class="mini" data-act="test">测试连接</button>
        <button class="primary" data-act="save">保存并使用</button>
      </div>
    </div>`;
  const baseInput = mask.querySelector("#aiSetBase");
  baseInput.addEventListener("input", () => {
    const v = baseInput.value.trim();
    const show = v.includes("xf-yun.com") || v.startsWith("wss://");
    mask.querySelector("#xfFields").style.display = show ? "block" : "none";
  });
  mask.addEventListener("click", async (e) => {
    if (e.target === mask) return mask.remove();
    const act = e.target.closest("[data-act]");
    if (!act) return;
    if (act.dataset.act === "cancel") return mask.remove();
    const base = mask.querySelector("#aiSetBase").value.trim();
    const key = mask.querySelector("#aiSetKey").value.trim();
    const model = mask.querySelector("#aiSetModel").value.trim();
    const appId = (mask.querySelector("#aiSetAppId") || {}).value || "";
    const apiSecret = (mask.querySelector("#aiSetApiSecret") || {}).value || "";
    const resultEl = mask.querySelector("#aiTestResult");
    function buildBody(keepKey) {
      const b = { base_url: base, model, api_key: keepKey ? "__KEEP__" : key };
      if (appId || apiSecret) {
        b.app_id = appId;
        b.api_secret = keepKey ? "__KEEP__" : apiSecret;
      }
      return b;
    }
    if (act.dataset.act === "test") {
      if (!base || !model) { resultEl.className = "ai-test-result err"; resultEl.textContent = "请先填写接口地址和模型名称"; return; }
      resultEl.className = "ai-test-result";
      resultEl.textContent = "连接测试中…";
      try {
        const body = buildBody(!key);
        const d = await api("/api/llm/test", { method: "POST", body: JSON.stringify(body) });
        if (d.ok) { resultEl.className = "ai-test-result ok"; resultEl.textContent = `连接成功：${d.reply || "(无回复)"}`; }
        else { resultEl.className = "ai-test-result err"; resultEl.textContent = "连接失败：" + d.error; }
      } catch (e) { resultEl.className = "ai-test-result err"; resultEl.textContent = "连接失败：" + e.message; }
      return;
    }
    if (act.dataset.act === "save") {
      if ((base || model) && !(base && model)) { resultEl.className = "ai-test-result err"; resultEl.textContent = "接口地址和模型名称需要同时填写（或都留空恢复离线模式）"; return; }
      act.disabled = true; act.textContent = "保存中…";
      try {
        const body = buildBody(!key);
        const d = await api("/api/llm/config", { method: "POST", body: JSON.stringify(body) });
        toast(d.message + "（当前引擎：" + d.provider + "）", "ok");
        mask.remove();
        refreshAiEngineBadge();
        $("llmBadge").textContent = d.provider === "openai" ? `引擎：${model}` : d.provider === "spark" ? "引擎：讯飞星火" : "引擎：本地规则(可离线)";
      } catch (e) {
        act.disabled = false; act.textContent = "保存并使用";
        resultEl.className = "ai-test-result err";
        resultEl.textContent = "保存失败：" + e.message;
      }
    }
  });
  document.body.appendChild(mask);
  
  // 预设模型选择
  const presets = {
    siliconflow: { base: "https://api.siliconflow.cn/v1", model: "Qwen/Qwen2.5-7B-Instruct", key: "" },
    deepseek: { base: "https://api.deepseek.com/v1", model: "deepseek-chat", key: "" },
    kimi: { base: "https://api.moonshot.cn/v1", model: "moonshot-v1-8k", key: "" },
    zhipu: { base: "https://open.bigmodel.cn/api/paas/v4", model: "glm-4-flash", key: "" },
    ollama: { base: "http://localhost:11434/v1", model: "qwen2.5:7b", key: "" },
  };
  mask.querySelector("#aiSetPreset").addEventListener("change", (e) => {
    const p = presets[e.target.value];
    if (p) {
      mask.querySelector("#aiSetBase").value = p.base;
      mask.querySelector("#aiSetModel").value = p.model;
      mask.querySelector("#aiSetKey").value = p.key;
      mask.querySelector("#aiSetKey").placeholder = p.key ? "输入API Key" : "本地模型可留空";
    }
  });
}

/* ---------------- 事件绑定 ---------------- */
$("tabLogin").addEventListener("click", () => setAuthTab(true));
$("tabRegister").addEventListener("click", () => setAuthTab(false));
$("toReg").addEventListener("click", (e) => { e.preventDefault(); setAuthTab(false); });
$("toLogin").addEventListener("click", (e) => { e.preventDefault(); setAuthTab(true); });
$("loginForm").addEventListener("submit", doLogin);
$("registerForm").addEventListener("submit", doRegister);
$("btnLogout").addEventListener("click", doLogout);
document.querySelectorAll(".nav-tab").forEach((b) => b.addEventListener("click", () => showView(b.dataset.view)));
$("dashQuickStart").addEventListener("click", () => showView("interview"));
$("dashGoJobs").addEventListener("click", () => showView("jobs"));

$("btnParseJD").addEventListener("click", parseJD);
$("btnClearJD").addEventListener("click", clearJD);
$("btnParse").addEventListener("click", parseResume);
$("btnOptimize").addEventListener("click", optimizeResume);
$("btnAnalyze").addEventListener("click", analyzeResume);
$("btnTemplates").addEventListener("click", showTemplates);
$("btnStart").addEventListener("click", () => startInterview(false));
$("btnSend").addEventListener("click", sendAnswer);
$("btnReport").addEventListener("click", generateReport);
$("btnRestart").addEventListener("click", () => { showPhase("phase-resume"); });
$("btnCam").addEventListener("click", toggleCam);
$("btnEndInterview").addEventListener("click", () => {
  if (!state.sessionId || state.finished) return;
  const input = $("answerInput");
  input.value = "面试结束";
  sendAnswer();
});

// 分析面板切换
$("btnToggleAnalysis").addEventListener("click", () => {
  analysisVisible = !analysisVisible;
  const panel = $("analysisPanel");
  if (panel) {
    panel.classList.toggle("hidden", !analysisVisible);
  }
  $("btnToggleAnalysis").textContent = analysisVisible ? "📊 隐藏分析" : "📊 显示分析";
});

$("resumeFile").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append("file", file);
  fd.append("filename", file.name);
  $("btnParse").disabled = true; $("btnParse").textContent = "上传解析中…";
  try {
    const resp = await fetch("/api/resume/upload", { method: "POST", headers: authHeaders(), body: fd });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.detail || "上传失败");
    $("resumeInput").value = data.text;
    state.resumeText = data.text;
    // 同步到简历分析页面
    if ($("raResumeInput")) $("raResumeInput").value = data.text;
    renderProfile(data); renderRanking(data.ranking); renderJobs(data.recommended_job);
    $("profileBox").classList.remove("hidden");
  } catch (err) { toast(err.message, "err"); }
  finally { $("btnParse").disabled = false; $("btnParse").textContent = "解析简历"; e.target.value = ""; }
});

$("answerInput").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendAnswer(); }
});
$("btnAiSend").addEventListener("click", aiSend);
$("btnAiClear").addEventListener("click", aiClear);
$("btnAiSettings").addEventListener("click", openAiSettings);
document.querySelectorAll("#aiModeChips .chip").forEach((c) =>
  c.addEventListener("click", () => aiSwitchMode(c.dataset.mode)));
$("aiInput").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); aiSend(); }
});
window.addEventListener("resize", () => { if (stateRadar.dims.length) drawRadar($("radarCanvas"), stateRadar.dims, stateRadar.scores); });

/* ---------------- 启动流程：检查登录 + 加载岗位 ---------------- */
(async () => {
  try {
    const jobs = await api("/api/jobs");
    window._jobs = jobs;
  } catch {}
  try {
    const cats = await api("/api/jobs/categories");
    window._jobCategories = cats;
  } catch {}
  const saved = localStorage.getItem("zp_token");
  if (saved) {
    state.token = saved;
    try {
      const me = await api("/api/auth/me");
      enterApp(me.user, saved);
      return;
    } catch { localStorage.removeItem("zp_token"); }
  }
  // 默认显示登录页
  $("loginView").classList.remove("hidden");
  setAuthTab(true);
})();

/* ---------------- 语音识别（麦克风输入） ---------------- */
let recognition = null;
let isRecording = false;

function initSpeechRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    console.warn("浏览器不支持语音识别");
    return null;
  }
  
  const rec = new SpeechRecognition();
  rec.lang = "zh-CN";
  rec.continuous = true;  // 持续识别
  rec.interimResults = true;  // 显示中间结果
  
  rec.onresult = (event) => {
    const input = $("answerInput");
    if (!input) return;
    
    let finalTranscript = "";
    let interimTranscript = "";
    
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const transcript = event.results[i][0].transcript;
      if (event.results[i].isFinal) {
        finalTranscript += transcript;
      } else {
        interimTranscript += transcript;
      }
    }
    
    // 如果有最终结果，追加到输入框
    if (finalTranscript) {
      input.value = (input.value + finalTranscript).trim();
    }
  };
  
  rec.onerror = (event) => {
    console.error("语音识别错误:", event.error);
    stopRecording();
    if (event.error === "not-allowed") {
      toast("请允许麦克风权限后重试", "err");
    } else if (event.error === "no-speech") {
      toast("未检测到语音，请重试", "err");
    }
  };
  
  rec.onend = () => {
    // 如果还在录音状态，重新开始（自动重启）
    if (isRecording) {
      try {
        rec.start();
      } catch (e) {
        console.error("重启语音识别失败:", e);
        stopRecording();
      }
    }
  };
  
  return rec;
}

function startRecording() {
  if (!recognition) {
    recognition = initSpeechRecognition();
  }
  if (!recognition) {
    toast("您的浏览器不支持语音识别，请使用Chrome或Edge浏览器", "err");
    return;
  }
  
  try {
    recognition.start();
    isRecording = true;
    const btn = $("btnMic");
    if (btn) {
      btn.classList.add("recording");
      btn.title = "点击停止语音输入";
    }
    toast("语音识别已开启，请开始说话...", "ok");
  } catch (e) {
    console.error("启动语音识别失败:", e);
    toast("启动语音识别失败: " + e.message, "err");
  }
}

function stopRecording() {
  if (recognition) {
    isRecording = false;
    try {
      recognition.stop();
    } catch (e) {}
  }
  const btn = $("btnMic");
  if (btn) {
    btn.classList.remove("recording");
    btn.title = "点击开始语音输入";
  }
}

function toggleRecording() {
  if (isRecording) {
    stopRecording();
    toast("语音识别已关闭", "ok");
  } else {
    startRecording();
  }
}

// 绑定麦克风按钮事件
document.addEventListener("DOMContentLoaded", () => {
  const micBtn = $("btnMic");
  if (micBtn) {
    micBtn.addEventListener("click", toggleRecording);
  }
});
