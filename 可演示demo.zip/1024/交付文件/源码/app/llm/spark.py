"""讯飞星火大模型实现。

支持两种模式：
1. WebSocket (v4.0/v3.5 等旧版): SPARK_URL=wss://...
2. OpenAI 兼容 REST (X2/X1.5 新版): SPARK_URL=https://...

环境变量:
    SPARK_APP_ID, SPARK_API_KEY, SPARK_API_SECRET
"""
import json
import time
import uuid
from typing import Iterator

import requests

from ..config import settings
from .base import BaseLLM, ChatResult, LLMError, Message


def _gen_ws_authorization(url: str, api_key: str, api_secret: str) -> str:
    """构造 WebSocket 握手所需的 Authorization（符合讯飞鉴权规范）"""
    import base64
    import hashlib
    import hmac
    import urllib.parse
    host = urllib.parse.urlparse(url).netloc
    path = urllib.parse.urlparse(url).path
    now = int(time.time())
    date = time.strftime("%a, %d %b %Y %H:%M:%S GMT", time.gmtime(now))
    origin = f"host: {host}\ndate: {date}\nGET {path} HTTP/1.1"
    signature_origin = hmac.new(
        api_secret.encode(), origin.encode(), digestmod=hashlib.sha256
    ).digest()
    signature = base64.b64encode(signature_origin).decode()
    authorization_origin = (
        f'api_key="{api_key}", algorithm="hmac-sha256", '
        f'headers="host date request-line", signature="{signature}"'
    )
    authorization = base64.b64encode(authorization_origin.encode()).decode()
    v = urllib.parse.urlencode({"authorization": authorization, "date": date, "host": host})
    return f"{url}?{v}"


class SparkLLM(BaseLLM):
    """讯飞星火大模型 (支持 WebSocket 和 OpenAI 兼容 REST)"""

    def __init__(self) -> None:
        from .store import load_config
        store = load_config()
        self._app_id = settings.SPARK_APP_ID or store.get("app_id", "")
        self._api_key = settings.SPARK_API_KEY or store.get("api_key", "")
        self._api_secret = settings.SPARK_API_SECRET or store.get("api_secret", "")
        self._url = settings.SPARK_URL or store.get("base_url", "")
        self._model = settings.SPARK_DOMAIN or store.get("model", "x1")
        self._max_tokens = settings.SPARK_MAX_TOKENS
        self._temperature = settings.SPARK_TEMPERATURE
        self._use_openai_compat = self._url.startswith("http")
        if not self._api_key and not self._api_secret:
            if not settings.llm_enabled:
                raise LLMError("未配置讯飞星火密钥")

    def chat(self, messages, temperature=None, max_tokens=None) -> ChatResult:
        if self._use_openai_compat:
            return self._chat_rest(messages, temperature, max_tokens)
        else:
            return self._chat_ws(messages, temperature, max_tokens)

    def chat_stream(self, messages, temperature=None, max_tokens=None) -> Iterator[str]:
        """流式对话 (仅 REST 模式支持, WS 模式降级为整段)"""
        if self._use_openai_compat:
            yield from self._chat_rest_stream(messages, temperature, max_tokens)
        else:
            result = self._chat_ws(messages, temperature, max_tokens)
            yield result.content

    def _chat_rest(self, messages, temperature=None, max_tokens=None) -> ChatResult:
        auth_token = f"{self._api_key}:{self._api_secret}"
        headers = {
            "Authorization": f"Bearer {auth_token}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self._model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": temperature or self._temperature,
            "max_tokens": max_tokens or self._max_tokens,
            "stream": False,
        }
        try:
            resp = requests.post(self._url, headers=headers, json=payload, timeout=120)
            data = resp.json()
        except Exception as exc:
            raise LLMError(f"星火请求失败: {exc}") from exc
        if resp.status_code != 200:
            error_msg = data.get("error", {}).get("message", f"HTTP {resp.status_code}")
            raise LLMError(f"星火返回错误: {error_msg}")
        choices = data.get("choices", [])
        if not choices:
            raise LLMError(f"星火返回空 choices: {data}")
        content = choices[0].get("message", {}).get("content", "")
        return ChatResult(content=content, raw=data)

    def _chat_rest_stream(self, messages, temperature=None, max_tokens=None) -> Iterator[str]:
        """OpenAI 兼容 REST 流式模式"""
        auth_token = f"{self._api_key}:{self._api_secret}"
        headers = {
            "Authorization": f"Bearer {auth_token}",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "text/event-stream",
        }
        payload = {
            "model": self._model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": temperature or self._temperature,
            "max_tokens": max_tokens or self._max_tokens,
            "stream": True,
        }
        try:
            resp = requests.post(self._url, headers=headers, json=payload, timeout=120, stream=True)
        except Exception as exc:
            raise LLMError(f"星火流式请求失败: {exc}") from exc
        if resp.status_code != 200:
            raise LLMError(f"星火返回 {resp.status_code}: {resp.text[:200]}")
        resp.encoding = "utf-8"
        try:
            for line in resp.iter_lines(decode_unicode=True):
                if not line:
                    continue
                line_str = str(line).strip()
                if not line_str.startswith("data:"):
                    continue
                data = line_str[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    obj = json.loads(data)
                except json.JSONDecodeError:
                    continue
                choices = obj.get("choices") or [{}]
                piece = (choices[0].get("delta") or {}).get("content")
                if piece:
                    yield piece
        except LLMError:
            raise
        except Exception as exc:
            raise LLMError(f"星火流式读取中断: {exc}") from exc
        finally:
            resp.close()

    def _chat_ws(self, messages, temperature=None, max_tokens=None) -> ChatResult:
        """WebSocket 模式 (v4.0/v3.5 旧版)"""
        url = _gen_ws_authorization(self._url, self._api_key, self._api_secret)
        payload = {
            "header": {
                "app_id": self._app_id,
                "uid": uuid.uuid4().hex,
            },
            "parameter": {
                "chat": {
                    "domain": self._model,
                    "temperature": temperature or self._temperature,
                    "max_tokens": max_tokens or self._max_tokens,
                }
            },
            "payload": {
                "message": {
                    "text": [{"role": m.role, "content": m.content} for m in messages]
                }
            },
        }
        try:
            resp = requests.post(url, json=payload, timeout=120)
            data = resp.json()
        except Exception as exc:
            raise LLMError(f"星火请求失败: {exc}") from exc
        header = data.get("header", {})
        code = header.get("code", -1)
        if code != 0:
            raise LLMError(f"星火返回错误 code={code}: {header.get('message')}")
        choices = data.get("payload", {}).get("choices", {}).get("text", [])
        content = "".join(item.get("content", "") for item in choices)
        return ChatResult(content=content, raw=data)