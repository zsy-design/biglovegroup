@echo off
chcp 65001 >nul
title ZhiPin - AI Interview Platform

echo ============================================
echo  ZhiPin - AI Interview Platform
echo ============================================
echo.

echo [1/2] Checking port 8010...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":8010.*LISTENING"') do (
    echo   Killing old process PID=%%a ...
    taskkill /PID %%a /F >nul 2>&1
)
echo   Port 8010 ready.
echo.

echo [2/2] Starting server...
python run.py %1
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Server exited with code %errorlevel%
    pause
)
