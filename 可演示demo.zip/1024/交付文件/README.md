# 岗位胜任力多轮问询与评估报告生成·面试智能体

## 项目简介

基于大语言模型智能体技术的全流程智能面试系统，支持JD解析、简历处理、多轮面试、九维评估、报告生成等功能。

## 交付内容

### 文档目录 (`文档/`)

| 文件名 | 说明 |
|--------|------|
| 作品设计实现方案_岗位胜任力面试智能体_v2.docx | 作品设计实现方案（含架构图） |
| 部署文档.md | 系统部署指南 |
| 测试文档.md | 功能测试文档 |
| 数据库设计文档.md | 数据库表结构设计 |
| API接口文档.md | RESTful API接口说明 |
| 用户操作手册.md | 用户使用指南 |

### 图片目录 (`图片/`)

| 文件名 | 说明 |
|--------|------|
| architecture.png | 系统整体架构图 |
| er_diagram.png | 数据库ER关系图 |
| module_diagram.png | 模块依赖关系图 |

### 源码目录 (`源码/`)

```
源码/
├── app/                    # 后端应用代码
│   ├── main.py            # FastAPI入口
│   ├── config.py          # 全局配置
│   ├── jd.py              # 岗位JD解析
│   ├── storage.py         # 数据存储
│   ├── tts.py             # 语音合成
│   ├── llm/               # 大模型接入
│   ├── resume/            # 简历处理
│   ├── competency/        # 胜任力评估
│   ├── interview/         # 面试引擎
│   └── report/            # 报告生成
├── static/                # 前端静态资源
├── data/                  # 数据库文件
├── run.py                 # 一键启动脚本
├── requirements.txt       # 依赖清单
└── README.md              # 项目说明
```

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 启动系统

```bash
python run.py
```

### 3. 访问系统

浏览器访问：http://127.0.0.1:8010

## 技术栈

- 后端：FastAPI + SQLite
- 前端：HTML/CSS/JavaScript + Three.js
- AI：讯飞星火4.0 / MockLLM
- 语音：讯飞TTS / Edge TTS / Web Speech

## 功能模块

1. 岗位JD智能解析
2. 简历智能处理
3. 虚拟AI多轮面试
4. 九维胜任力评估
5. 智能评估报告
6. 数据看板与历史

## 联系方式

如有问题，请联系项目负责人。